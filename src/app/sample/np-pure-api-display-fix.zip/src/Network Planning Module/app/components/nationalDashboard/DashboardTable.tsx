import { Fragment, useEffect, useMemo, useRef, useState } from "react";
import { ChevronsLeftIcon, ChevronsRightIcon } from "lucide-react";
import type { NavState } from "../../App";
import {
  type AggregatedComponent,
  type CBURow,
  isHighContributingType,
} from "../data";
import { componentGroupRows, mainCell, metaCell } from "./cellRenderers";
import { SortIndicator } from "./SortIndicator";
import {
  COVER_COL_TOOLTIPS,
  G,
  G_LABEL,
  W_SR,
  SR_NO_LABEL,
  noComponentDataMessage,
  UNIQUE_COMPONENTS_LABEL,
  FILTERED_BADGE_LABEL,
  HIGH_CONTRIBUTING_GROUP_LABEL,
  HIGH_CONTRIBUTING_EMPTY_MESSAGE,
} from "../../constants/nationalDashboard";
import { componentScopeLabel, computeGroupBoundaryColIds, coverResultFromDate, GROUP_BOUNDARY_HEADER_BORDER_COLOR, metaColLeft, stickyBody, stickyHead, subHdrStyle } from "./utils";
import type { ColDef, ColumnGroup, EffRmpm, SortDir, TypeFilter, UomFilter } from "./types";
import type { CbuRecalculateContributionType } from "./apiTypes";

// Extra room around the measured text for the cell's padding, contribution
// badge/icon button, and gaps — see the cbuDescription cell in cellRenderers.tsx.
const DESCRIPTION_CELL_CHROME_PX = 60;
const DESCRIPTION_COL_MAX_WIDTH_PX = 640;

let descriptionMeasureCtx: CanvasRenderingContext2D | null | undefined;
function measureTextWidth(text: string): number {
  if (descriptionMeasureCtx === undefined) {
    descriptionMeasureCtx =
      typeof document === "undefined"
        ? null
        : document.createElement("canvas").getContext("2d");
    if (descriptionMeasureCtx) {
      descriptionMeasureCtx.font = "12px -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif";
    }
  }
  return descriptionMeasureCtx
    ? descriptionMeasureCtx.measureText(text).width
    : text.length * 6.5;
}

/** cbuDescription's width normally sits at its configured minWidth; while any
 * row's description is expanded, it grows to fit the widest expanded value so
 * the full text is visible, then collapses back once nothing is expanded. */
function withExpandedDescriptionWidth(
  cols: ColDef[],
  expandedDescriptions: Set<number>,
  paginatedRows: CBURow[],
): ColDef[] {
  const descCol = cols.find((c) => c.id === "cbuDescription");
  if (!descCol || expandedDescriptions.size === 0) return cols;

  const expandedWidth = paginatedRows.reduce((max, row) => {
    if (!expandedDescriptions.has(row.srNo)) return max;
    const textWidth = measureTextWidth(row.cbuDescription) + DESCRIPTION_CELL_CHROME_PX;
    return Math.max(max, textWidth);
  }, descCol.minWidth);

  const clampedWidth = Math.min(expandedWidth, DESCRIPTION_COL_MAX_WIDTH_PX);
  if (clampedWidth <= descCol.minWidth) return cols;

  return cols.map((c) =>
    c.id === "cbuDescription" ? { ...c, minWidth: clampedWidth } : c,
  );
}

interface DashboardTableProps {
  orderedMetaCols: ColDef[];
  orderedDataCols: ColDef[];
  groupRuns: Array<{ group: ColumnGroup; count: number }>;
  tableMinWidth: number;
  stickyColCount: number;
  sortCol: string | null;
  sortDir: SortDir;
  onSort: (colId: string) => void;
  // Only used to reset scroll to the top on page navigation — deliberately
  // not derived from paginatedRows itself, since that array also gets a new
  // reference on same-page updates (e.g. toggling High Contributing, whose
  // data arrives asynchronously) that must NOT yank the user's scroll
  // position out from under them.
  page: number;
  paginatedRows: CBURow[];
  expandedSrNo: number | null;
  isExpandedComponentsLoading: boolean;
  isExpandedHighContributingLoading: boolean;
  componentCache: Record<number, AggregatedComponent[]>;
  highContributingCache: Record<number, AggregatedComponent[]>;
  selectedComponents: Record<number, Set<string>>;
  typeFilter: TypeFilter;
  uom: UomFilter;
  showHighContributing: boolean;
  // The expanded row's latest POST /api/v1/cbus/recalculate/summary result
  // (see NationalDashboard.tsx) — null until a successful response arrives
  // for it. When set, it fully replaces the expanded row's data fields (fg,
  // rmpm/rmpmMin/rmpmMax, demand, cover/coverMin/coverMax); until then those
  // keep reading the row's own static values from the list API. Every
  // figure is always sourced from one API response or the other — nothing
  // is ever computed client-side from individual components.
  recalculatedRow: CBURow | null;
  isRecalculating: boolean;
  onCbuClick: (row: CBURow) => void;
  navigate: (state: NavState) => void;
  onToggleComp: (srNo: number, code: string, contributionType: CbuRecalculateContributionType) => void;
  onToggleAll: (
    srNo: number,
    comps: AggregatedComponent[],
    allSel: boolean,
    contributionType: CbuRecalculateContributionType,
  ) => void;
  onDemandClick: (row: CBURow, period: "3tdp" | "6m" | "12m") => void;
  onDcStockClick: (row: CBURow) => void;
  onFactoryStockClick: (row: CBURow) => void;
  onInTransitClick: (row: CBURow) => void;
}

export function DashboardTable({
  orderedMetaCols,
  orderedDataCols,
  groupRuns,
  tableMinWidth,
  stickyColCount,
  sortCol,
  sortDir,
  onSort,
  page,
  paginatedRows,
  expandedSrNo,
  isExpandedComponentsLoading,
  isExpandedHighContributingLoading,
  componentCache,
  highContributingCache,
  selectedComponents,
  typeFilter,
  uom,
  showHighContributing,
  recalculatedRow,
  isRecalculating,
  onCbuClick,
  navigate,
  onToggleComp,
  onToggleAll,
  onDemandClick,
  onDcStockClick,
  onFactoryStockClick,
  onInTransitClick,
}: Readonly<DashboardTableProps>) {
  const [expandedDescriptions, setExpandedDescriptions] = useState<Set<number>>(
    new Set()
  );

  const scrollRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = 0;
  }, [page]);

  const effectiveMetaCols = useMemo(
    () => withExpandedDescriptionWidth(orderedMetaCols, expandedDescriptions, paginatedRows),
    [orderedMetaCols, expandedDescriptions, paginatedRows],
  );
  const groupBoundaryColIds = useMemo(
    () => computeGroupBoundaryColIds(orderedDataCols, groupRuns),
    [orderedDataCols, groupRuns],
  );
  const toggleDescriptionExpanded = (srNo: number) => {
    setExpandedDescriptions((prev) => {
      const next = new Set(prev);
      if (srNo === -1) {
        // Toggle all: if any are expanded, collapse all; otherwise expand all
        if (next.size > 0) {
          next.clear();
        } else {
          paginatedRows.forEach((row) => {
            next.add(row.srNo);
          });
        }
      } else if (next.has(srNo)) {
        // Toggle individual
        next.delete(srNo);
      } else {
        next.add(srNo);
      }
      return next;
    });
  };

  return (
    <div ref={scrollRef} className="flex-1 overflow-auto np-table-scroll" style={{ backgroundColor: "#ffffff" }}>
      {/* A single scrolling container (not nested) — sticky header/columns
          resolve their top/left offsets against this same element, which is
          the only way both can stick correctly at once. Two nested
          overflow-auto divs would fight over which one sticky positioning
          binds to (worse, CSS forces overflow-y to compute as "auto" the
          moment overflow-x is set to anything but "visible", so even an
          "overflow-x-auto"-only inner div still ends up a full scroll
          container — the header stuck to it instead of the page). */}
      <div
        className="shadow-lg"
        style={{
          borderWidth: 1,
          borderStyle: "solid",
          borderColor: "#d1d5db",
          boxShadow: "0 0 30px rgba(0,200,240,0.05)",
        }}
      >
        <table
          className="text-xs border-collapse"
          style={{
            backgroundColor: "#EDF5FA",
            minWidth: `${tableMinWidth}px`,
            width: "100%",
          }}
        >
          <thead>
            {/* Group header row */}
            <tr style={{ height: 38 }}>
              <th
                rowSpan={2}
                className="text-white border px-3 py-2 font-semibold whitespace-nowrap select-none"
                style={{
                  ...stickyHead(0, W_SR),
                  top: 0,
                  backgroundColor: "#003087",
                  borderColor: "#ffffff",
                  zIndex: 35,
                  textAlign: "center",
                }}
              >
                {SR_NO_LABEL}
              </th>
              {effectiveMetaCols.map((col, index) => (
                <th
                  key={`meta-hdr-${col.id}`}
                  rowSpan={2}
                  className="text-white border px-3 py-2 text-left font-semibold whitespace-nowrap cursor-pointer select-none"
                  style={{
                    ...stickyHead(metaColLeft(effectiveMetaCols, index), col.minWidth),
                    top: 0,
                    backgroundColor: "#003087",
                    borderColor: "#ffffff",
                    zIndex: 35,
                  }}
                  onClick={() => onSort(col.id)}
                >
                  <span className="inline-flex items-center gap-1 justify-between w-full">
                    <span className="inline-flex items-center gap-1">
                      <span>{col.label}</span>
                      <SortIndicator colId={col.id} sortCol={sortCol} sortDir={sortDir} light />
                    </span>
                    {col.id === "cbuDescription" && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleDescriptionExpanded(-1);
                        }}
                        title={expandedDescriptions.size > 0 ? "Collapse all descriptions" : "Expand all descriptions"}
                        className="p-0.5 rounded transition-colors hover:bg-blue-600 shrink-0"
                        style={{ background: "transparent", border: "none", cursor: "pointer", display: "flex" }}
                      >
                        {expandedDescriptions.size > 0 ? (
                          <ChevronsLeftIcon size={14} aria-hidden="true" style={{ color: "#ffffff" }} />
                        ) : (
                          <ChevronsRightIcon size={14} aria-hidden="true" style={{ color: "#ffffff" }} />
                        )}
                      </button>
                    )}
                  </span>
                </th>
              ))}
              {groupRuns.map((run, i) => (
                <th
                  key={`${run.group}-${i}`}
                  colSpan={run.count}
                  className="text-white border px-3 py-2 text-center font-semibold whitespace-nowrap"
                  style={{
                    backgroundColor: G[run.group].hdr,
                    position: "sticky",
                    top: 0,
                    zIndex: 20,
                    borderColor: "#ffffff",
                    // Sticky cells sitting flush against each other don't
                    // reliably paint a shared border under border-collapse
                    // (same reason the frozen Sr No column's divider below
                    // uses an inset box-shadow instead — see stickyBody's
                    // callers) — so every group boundary, including the
                    // first one against the meta columns, is drawn as an
                    // inset shadow rather than a real border, which always
                    // paints regardless of collapse behavior.
                    borderLeftWidth: 0,
                    boxShadow: "inset 1px 0 0 0 #ffffff",
                  }}
                >
                  {G_LABEL[run.group]}
                </th>
              ))}
            </tr>

            {/* Sub-header row — data columns only (meta + Sr No span 2 rows) */}
            <tr style={{ height: 34 }}>
              {orderedDataCols.map((col) => (
                <th
                  key={col.id}
                  className="border px-3 py-2 font-medium whitespace-nowrap cursor-pointer select-none"
                  style={{
                    ...subHdrStyle(col.id),
                    position: "sticky",
                    top: 38,
                    zIndex: 20,
                    minWidth: col.minWidth,
                    borderColor: "#ffffff",
                    fontWeight: 600,
                    // See the group-header row above: a real border between
                    // two flush sticky cells doesn't reliably paint under
                    // border-collapse, so the group-boundary divider is an
                    // inset box-shadow instead.
                    ...(groupBoundaryColIds.has(col.id)
                      ? { borderLeftWidth: 0, boxShadow: `inset 1px 0 0 0 ${GROUP_BOUNDARY_HEADER_BORDER_COLOR}` }
                      : {}),
                  }}
                  onClick={() => onSort(col.id)}
                  title={COVER_COL_TOOLTIPS[col.id]}
                >
                  <span className="text-right flex items-center justify-end gap-1">
                    {col.label}
                    <SortIndicator colId={col.id} sortCol={sortCol} sortDir={sortDir} />
                  </span>
                </th>
              ))}
            </tr>
          </thead>

          <tbody>
            {paginatedRows.map((row) => {
              const isExpanded = expandedSrNo === row.srNo;
              const rowBg = isExpanded ? "#EDF5F4" : "#ffffff";

              const components: AggregatedComponent[] = componentCache[row.srNo] ?? [];
              const allHighContribComps = highContributingCache[row.srNo] ?? [];
              const selected: Set<string> =
                selectedComponents[row.srNo] ??
                new Set([
                  ...components.map((c) => c.componentCode),
                  ...allHighContribComps.map((c) => c.componentCode),
                ]);

              const visibleComps = components.filter((c) => {
                // Components tagged as high-contributing (even on this
                // unfiltered call) are only shown in the High Contributing
                // section below — never duplicated into Unique Components.
                if (isHighContributingType(c.contributionType)) return false;
                if (typeFilter === "ALL") return true;
                if (typeFilter === "RM") return c.componentMaterialType === "1001";
                if (typeFilter === "PM") return c.componentMaterialType === "1002";
                return true;
              });

              const isFiltered = typeFilter !== "ALL";

              // Once the backend has recalculated this expanded row (POST
              // /api/v1/cbus/recalculate/summary, fired on every RM/PM
              // checkbox toggle — see triggerRecalculate in
              // NationalDashboard.tsx), it fully replaces every data field
              // the list API (GET /api/v1/cbus) originally returned for this
              // row — fg, rmpm/rmpmMin/rmpmMax, demand, totalFG, cover/
              // coverMin/coverMax — including a legitimate all-zero
              // rmpmMin/rmpmMax (e.g. every currently-selected component
              // has zero stock for that bound): that's a real answer, not a
              // sign the response should be distrusted. Identity fields
              // (srNo, cbuCode, cbuDescription, weightKg, basePack, etc.)
              // always stay the original row's own — srNo in particular is
              // this row's rank in the *current* paginated/filtered result
              // set (see fetchCbuByCode's comment in cbuApi.ts), not
              // something the recalculate endpoint's own echoed-back value
              // can be trusted for. recalculatedRow is reset to null
              // whenever a different row expands, so this only ever applies
              // to the row it was actually computed for.
              const displayRow: CBURow =
                isExpanded && recalculatedRow
                  ? {
                      ...row,
                      fg: recalculatedRow.fg,
                      rmpm: recalculatedRow.rmpm,
                      rmpmMin: recalculatedRow.rmpmMin,
                      rmpmMax: recalculatedRow.rmpmMax,
                      demand: recalculatedRow.demand,
                      totalFG: recalculatedRow.totalFG,
                      cover: recalculatedRow.cover,
                      coverMin: recalculatedRow.coverMin,
                      coverMax: recalculatedRow.coverMax,
                    }
                  : row;

              const effRmpmMax: EffRmpm = { ...displayRow.rmpmMax, stvStock: displayRow.rmpmMax.stvStock ?? 0 };
              const effRmpmMin: EffRmpm = { ...displayRow.rmpmMin, stvStock: displayRow.rmpmMin.stvStock ?? 0 };

              // FG Summary = FG stock + RMPM total — a plain sum of two
              // already-API-sourced numbers (both from displayRow, so this
              // matches the recalculated response's own totalFGMax/
              // totalFGMin once one is in play), not an approximation of
              // anything the backend itself computes.
              const totalFGMax = displayRow.fg.totalStock + effRmpmMax.totalStock;
              const totalFGMin = displayRow.fg.totalStock + effRmpmMin.totalStock;

              const maxCoverApi = displayRow.coverMax ?? displayRow.cover;
              const minCoverApi = displayRow.coverMin ?? displayRow.cover;
              const fgCov = coverResultFromDate(maxCoverApi.fgCoverDate);
              const totCovMax = coverResultFromDate(maxCoverApi.totalCoverDate);
              const exclCovMax = coverResultFromDate(maxCoverApi.coverExclOpenPO);
              const totCovMin = coverResultFromDate(minCoverApi.totalCoverDate);
              const exclCovMin = coverResultFromDate(minCoverApi.coverExclOpenPO);

              // High-contributing components are sourced separately from
              // the CBU's standard RM/PM breakdown (visibleComps) — see
              // getHighContributingComponents for details.
              const highContribComps = allHighContribComps.filter((c) => {
                if (typeFilter === "RM") return c.componentMaterialType === "1001";
                if (typeFilter === "PM") return c.componentMaterialType === "1002";
                return true;
              });

              return (
                <Fragment key={`row-${row.srNo}`}>
                  <tr
                    className="transition-all group"
                    style={{
                      backgroundColor: rowBg,
                    }}
                    onMouseEnter={(e) => {
                      if (!isExpanded)
                        (e.currentTarget as HTMLElement).style.backgroundColor = "#EDF5F4";
                    }}
                    onMouseLeave={(e) => {
                      (e.currentTarget as HTMLElement).style.backgroundColor = rowBg;
                    }}
                  >
                    {/* Frozen: Sr No */}
                    <td
                      className="px-2 py-1 text-center"
                      style={{
                        ...stickyBody(0, W_SR, rowBg),
                        boxShadow: "inset 0 -1px 0 0 #e5e7eb, inset -1px 0 0 0 #e5e7eb",
                        color: "#1565C0",
                      }}
                    >
                      {row.srNo}
                    </td>

                    {effectiveMetaCols.map((col, index) =>
                      metaCell({
                        col,
                        row,
                        rowBg,
                        isExpanded,
                        isRecalculating: isExpanded && isRecalculating,
                        onCbuClick,
                        navigate,
                        stickyLeft: metaColLeft(effectiveMetaCols, index),
                        isDescriptionExpanded: expandedDescriptions.has(row.srNo),
                      }),
                    )}

                    {/* Dynamic columns */}
                    {orderedDataCols.map((col) =>
                      mainCell({
                        colId: col.id,
                        row: displayRow,
                        effMax: effRmpmMax,
                        effMin: effRmpmMin,
                        uom,
                        groupBoundaryColIds,
                        totalFGMax,
                        totalFGMin,
                        fgCov,
                        totCovMax,
                        totCovMin,
                        exclCovMax,
                        exclCovMin,
                        onDemand: (e, period) => {
                          e.stopPropagation();
                          onDemandClick(row, period);
                        },
                        onDcStockClick: (e) => {
                          e.stopPropagation();
                          onDcStockClick(row);
                        },
                        onFactoryStockClick: (e) => {
                          e.stopPropagation();
                          onFactoryStockClick(row);
                        },
                        onInTransitClick: (e) => {
                          e.stopPropagation();
                          onInTransitClick(row);
                        },
                      }),
                    )}
                  </tr>

                  {/* Expanded component rows */}
                  {isExpanded && (
                    <>
                      {componentGroupRows({
                        comps: visibleComps,
                        keyPrefix: "main",
                        headerBg: "#EDF5F4",
                        emptyMessage: noComponentDataMessage(typeFilter),
                        isLoading: isExpandedComponentsLoading,
                        row,
                        selected,
                        effectiveMetaCols,
                        orderedDataCols,
                        groupBoundaryColIds,
                        stickyColCount,
                        uom,
                        contributionType: "unique",
                        onToggleAll,
                        onToggleComp,
                        label: (
                          <>
                            {UNIQUE_COMPONENTS_LABEL}{" "}
                            {componentScopeLabel(typeFilter)}
                            {isFiltered && (
                              <span
                                className="px-1.5 py-0.5 rounded text-xs font-medium"
                                style={{
                                  backgroundColor: "rgba(0,105,92,0.15)",
                                  color: "#00695C",
                                }}
                              >
                                {FILTERED_BADGE_LABEL}
                              </span>
                            )}
                          </>
                        ),
                      })}

                      {showHighContributing &&
                        componentGroupRows({
                          comps: highContribComps,
                          keyPrefix: "high",
                          headerBg: "#FFF7ED",
                          emptyMessage: HIGH_CONTRIBUTING_EMPTY_MESSAGE,
                          isLoading: isExpandedHighContributingLoading,
                          row,
                          selected,
                          effectiveMetaCols,
                          orderedDataCols,
                          groupBoundaryColIds,
                          stickyColCount,
                          uom,
                          contributionType: "high-contributing",
                          onToggleAll,
                          onToggleComp,
                          label: <>{HIGH_CONTRIBUTING_GROUP_LABEL}</>,
                        })}
                    </>
                  )}
                </Fragment>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
