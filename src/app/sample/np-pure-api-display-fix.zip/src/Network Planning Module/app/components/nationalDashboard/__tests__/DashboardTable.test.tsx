import { render, screen, fireEvent } from "@testing-library/react";
import { DashboardTable } from "../DashboardTable";
import { computeGroupRuns } from "../utils";
import { ALL_COLS } from "../../../constants/nationalDashboard";
import type { CBURow, AggregatedComponent } from "../../data";

function makeRow(overrides: Partial<CBURow> = {}): CBURow {
  return {
    srNo: 1,
    cbuCode: "TESTCODE",
    cbuDescription: "Test CBU 200ML",
    weightKg: 0.2,
    fg: { dcStock: 100, factoryStock: 50, inTransitStock: 20, totalStock: 170 },
    rmpm: {
      physicalStock: 40,
      qualityStock: 10,
      openPOStock: 5,
      totalStock: 55,
      blockedStock: 0,
      supplierInventory: 0,
      inTransitStock: 0,
    },
    rmpmMin: {
      physicalStock: 40,
      qualityStock: 10,
      openPOStock: 5,
      totalStock: 55,
      blockedStock: 0,
      supplierInventory: 0,
      inTransitStock: 0,
    },
    rmpmMax: {
      physicalStock: 40,
      qualityStock: 10,
      openPOStock: 5,
      totalStock: 55,
      blockedStock: 0,
      supplierInventory: 0,
      inTransitStock: 0,
    },
    demand: { sumNext3TDP: 30, next6Months: 100, next12Months: 200 },
    totalFG: 170,
    cover: { fgCoverDate: "N/A", totalCoverDate: "N/A", coverExclOpenPO: "N/A" },
    ...overrides,
  };
}

function makeComponent(overrides: Partial<AggregatedComponent> = {}): AggregatedComponent {
  return {
    componentCode: "C1",
    componentMaterialType: "1002",
    unrestrictedStock: 10,
    qualityStock: 2,
    blockedStock: 0,
    totalStock: 12,
    openPOStock: 3,
    ...overrides,
  };
}

const orderedMetaCols = ALL_COLS.filter((c) => c.id === "cbuCode" || c.id === "cbuDescription");
const orderedDataCols = ALL_COLS.filter((c) => c.id === "fg_total" || c.id === "demand_12m");
const groupRuns = computeGroupRuns(orderedDataCols);

function baseProps(overrides: Record<string, unknown> = {}) {
  return {
    orderedMetaCols,
    orderedDataCols,
    groupRuns,
    tableMinWidth: 800,
    stickyColCount: 1 + orderedMetaCols.length,
    sortCol: null,
    sortDir: "asc" as const,
    onSort: jest.fn(),
    page: 1,
    paginatedRows: [makeRow()],
    expandedSrNo: null,
    isExpandedComponentsLoading: false,
    isExpandedHighContributingLoading: false,
    componentCache: {},
    highContributingCache: {},
    selectedComponents: {},
    typeFilter: "ALL" as const,
    uom: "EA" as const,
    showHighContributing: false,
    recalculatedRow: null,
    isRecalculating: false,
    onCbuClick: jest.fn(),
    navigate: jest.fn(),
    onToggleComp: jest.fn(),
    onToggleAll: jest.fn(),
    onDemandClick: jest.fn(),
    onDcStockClick: jest.fn(),
    onFactoryStockClick: jest.fn(),
    onInTransitClick: jest.fn(),
    ...overrides,
  };
}

describe("DashboardTable", () => {
  it("renders the Sr No header and every ordered column's label", () => {
    render(<DashboardTable {...baseProps()} />);
    expect(screen.getByText("Sr No")).toBeInTheDocument();
    expect(screen.getByText("CBU Description")).toBeInTheDocument();
    expect(screen.getByText("Total Stock")).toBeInTheDocument();
    expect(screen.getByText("Next 12 Months")).toBeInTheDocument();
  });

  it("calls onSort with the column id when a header is clicked", () => {
    const onSort = jest.fn();
    render(<DashboardTable {...baseProps({ onSort })} />);
    fireEvent.click(screen.getByText("Sr No"));
    expect(onSort).toHaveBeenCalledWith("srNo");
  });

  it("renders a row per paginated CBU with its srNo and code", () => {
    const rows = [makeRow({ srNo: 1, cbuCode: "AAA" }), makeRow({ srNo: 2, cbuCode: "BBB" })];
    render(<DashboardTable {...baseProps({ paginatedRows: rows })} />);
    expect(screen.getByText("AAA")).toBeInTheDocument();
    expect(screen.getByText("BBB")).toBeInTheDocument();
  });

  it("calls onCbuClick with the row when the CBU code cell is clicked", () => {
    const onCbuClick = jest.fn();
    const row = makeRow({ cbuCode: "AAA" });
    render(<DashboardTable {...baseProps({ paginatedRows: [row], onCbuClick })} />);
    fireEvent.click(screen.getByText("AAA"));
    expect(onCbuClick).toHaveBeenCalledWith(row);
  });

  it("shows the empty-component message for an expanded row with no cached components", () => {
    const row = makeRow({ srNo: 1 });
    render(
      <DashboardTable
        {...baseProps({ paginatedRows: [row], expandedSrNo: 1, componentCache: {} })}
      />,
    );
    expect(screen.getByText("No component data for this CBU")).toBeInTheDocument();
  });

  it("shows a loading message instead of the empty message while the expanded row's components are still loading", () => {
    const row = makeRow({ srNo: 1 });
    render(
      <DashboardTable
        {...baseProps({
          paginatedRows: [row],
          expandedSrNo: 1,
          isExpandedComponentsLoading: true,
          componentCache: {},
        })}
      />,
    );
    expect(screen.getByText("Loading components…")).toBeInTheDocument();
    expect(screen.queryByText("No component data for this CBU")).not.toBeInTheDocument();
  });

  it("renders the unique-components group with cached components when the row is expanded", () => {
    const row = makeRow({ srNo: 1 });
    const comps = [makeComponent({ componentCode: "COMP1" })];
    render(
      <DashboardTable
        {...baseProps({
          paginatedRows: [row],
          expandedSrNo: 1,
          componentCache: { 1: comps },
          selectedComponents: { 1: new Set(["COMP1"]) },
        })}
      />,
    );
    expect(screen.getByText("COMP1")).toBeInTheDocument();
  });

  it("excludes components tagged high-contributer from the unique-components group", () => {
    const row = makeRow({ srNo: 1 });
    const comps = [
      makeComponent({ componentCode: "COMP1" }),
      makeComponent({ componentCode: "COMP2", contributionType: "high-contributer" }),
    ];
    render(
      <DashboardTable
        {...baseProps({
          paginatedRows: [row],
          expandedSrNo: 1,
          componentCache: { 1: comps },
          selectedComponents: { 1: new Set(["COMP1", "COMP2"]) },
        })}
      />,
    );
    expect(screen.getByText("COMP1")).toBeInTheDocument();
    expect(screen.queryByText("COMP2")).not.toBeInTheDocument();
  });

  it("does not render component group rows when the row isn't expanded", () => {
    const row = makeRow({ srNo: 1 });
    const comps = [makeComponent({ componentCode: "COMP1" })];
    render(
      <DashboardTable
        {...baseProps({ paginatedRows: [row], expandedSrNo: null, componentCache: { 1: comps } })}
      />,
    );
    expect(screen.queryByText("COMP1")).not.toBeInTheDocument();
  });

  it("calls onDemandClick with the row and period when a demand cell is clicked", () => {
    const onDemandClick = jest.fn();
    const row = makeRow({ demand: { sumNext3TDP: 1, next6Months: 2, next12Months: 999 } });
    render(<DashboardTable {...baseProps({ paginatedRows: [row], onDemandClick })} />);
    fireEvent.click(screen.getByText("999"));
    expect(onDemandClick).toHaveBeenCalledWith(row, "12m");
  });

  it("calls onSort with the column id when a data sub-header is clicked", () => {
    const onSort = jest.fn();
    render(<DashboardTable {...baseProps({ onSort })} />);
    fireEvent.click(screen.getByText("Total Stock"));
    expect(onSort).toHaveBeenCalledWith("fg_total");
  });

  it("calls onSort with the column id when a meta column header is clicked", () => {
    const onSort = jest.fn();
    render(<DashboardTable {...baseProps({ onSort })} />);
    fireEvent.click(screen.getByText("CBU"));
    expect(onSort).toHaveBeenCalledWith("cbuCode");
  });

  it("calls onDcStockClick, onFactoryStockClick and onInTransitClick when their cells are clicked", () => {
    const onDcStockClick = jest.fn();
    const onFactoryStockClick = jest.fn();
    const onInTransitClick = jest.fn();
    const stockCols = ALL_COLS.filter(
      (c) => c.id === "fg_dc" || c.id === "fg_factory" || c.id === "fg_intransit",
    );
    const row = makeRow({
      fg: { dcStock: 100, factoryStock: 50, inTransitStock: 20, totalStock: 170 },
    });
    render(
      <DashboardTable
        {...baseProps({
          orderedDataCols: stockCols,
          groupRuns: computeGroupRuns(stockCols),
          paginatedRows: [row],
          onDcStockClick,
          onFactoryStockClick,
          onInTransitClick,
        })}
      />,
    );
    fireEvent.click(screen.getByText("100"));
    expect(onDcStockClick).toHaveBeenCalledWith(row);
    fireEvent.click(screen.getByText("50"));
    expect(onFactoryStockClick).toHaveBeenCalledWith(row);
    fireEvent.click(screen.getByText("20"));
    expect(onInTransitClick).toHaveBeenCalledWith(row);
  });

  it("defaults the selected-components set to the union of cached and high-contributing codes when none is provided", () => {
    const row = makeRow({ srNo: 1 });
    const comps = [makeComponent({ componentCode: "COMP1" })];
    const highComps = [makeComponent({ componentCode: "HC1" })];
    render(
      <DashboardTable
        {...baseProps({
          paginatedRows: [row],
          expandedSrNo: 1,
          componentCache: { 1: comps },
          highContributingCache: { 1: highComps },
          selectedComponents: {},
          showHighContributing: true,
        })}
      />,
    );
    // Neither row is greyed out (opacity 0.55) because both default to selected.
    const compRow = screen.getByText("COMP1").closest("tr") as HTMLElement;
    const hcRow = screen.getByText("HC1").closest("tr") as HTMLElement;
    expect(compRow.style.opacity).toBe("1");
    expect(hcRow.style.opacity).toBe("1");
  });

  it("highlights a row on mouse enter and reverts it on mouse leave", () => {
    const row = makeRow({ cbuCode: "AAA" });
    render(<DashboardTable {...baseProps({ paginatedRows: [row] })} />);
    const tr = screen.getByText("AAA").closest("tr") as HTMLElement;

    fireEvent.mouseEnter(tr);
    expect(tr.style.backgroundColor).toBe("rgb(237, 245, 244)");

    fireEvent.mouseLeave(tr);
    expect(tr.style.backgroundColor).toBe("rgb(255, 255, 255)");
  });

  it("does not restyle an expanded row on mouse enter (it keeps its expanded background)", () => {
    const row = makeRow({ srNo: 1, cbuCode: "AAA" });
    render(<DashboardTable {...baseProps({ paginatedRows: [row], expandedSrNo: 1 })} />);
    const tr = screen.getByText("AAA").closest("tr") as HTMLElement;

    fireEvent.mouseEnter(tr);
    expect(tr.style.backgroundColor).toBe("rgb(237, 245, 244)");
  });

  it("filters the unique-components group down to RM components when typeFilter is RM", () => {
    const row = makeRow({ srNo: 1 });
    const comps = [
      makeComponent({ componentCode: "RM1", componentMaterialType: "1001" }),
      makeComponent({ componentCode: "PM1", componentMaterialType: "1002" }),
    ];
    render(
      <DashboardTable
        {...baseProps({
          paginatedRows: [row],
          expandedSrNo: 1,
          componentCache: { 1: comps },
          selectedComponents: { 1: new Set(["RM1", "PM1"]) },
          typeFilter: "RM",
        })}
      />,
    );
    expect(screen.getByText("RM1")).toBeInTheDocument();
    expect(screen.queryByText("PM1")).not.toBeInTheDocument();
  });

  it("filters the unique-components group down to PM components when typeFilter is PM", () => {
    const row = makeRow({ srNo: 1 });
    const comps = [
      makeComponent({ componentCode: "RM1", componentMaterialType: "1001" }),
      makeComponent({ componentCode: "PM1", componentMaterialType: "1002" }),
    ];
    render(
      <DashboardTable
        {...baseProps({
          paginatedRows: [row],
          expandedSrNo: 1,
          componentCache: { 1: comps },
          selectedComponents: { 1: new Set(["RM1", "PM1"]) },
          typeFilter: "PM",
        })}
      />,
    );
    expect(screen.getByText("PM1")).toBeInTheDocument();
    expect(screen.queryByText("RM1")).not.toBeInTheDocument();
  });

  it("shows the RM/PM filtered badge next to the unique-components label when a type filter is active", () => {
    const row = makeRow({ srNo: 1 });
    const comps = [makeComponent({ componentCode: "RM1", componentMaterialType: "1001" })];
    render(
      <DashboardTable
        {...baseProps({
          paginatedRows: [row],
          expandedSrNo: 1,
          componentCache: { 1: comps },
          typeFilter: "RM",
        })}
      />,
    );
    expect(screen.getByText("filtered")).toBeInTheDocument();
  });

  it("renders the high-contributing group when showHighContributing is on", () => {
    const row = makeRow({ srNo: 1 });
    const highComps = [makeComponent({ componentCode: "HC1" })];
    render(
      <DashboardTable
        {...baseProps({
          paginatedRows: [row],
          expandedSrNo: 1,
          highContributingCache: { 1: highComps },
          selectedComponents: { 1: new Set(["HC1"]) },
          showHighContributing: true,
        })}
      />,
    );
    expect(screen.getByText("HC1")).toBeInTheDocument();
  });

  it("toggles the expand-all-descriptions button and reflects its state in the title", () => {
    const row = makeRow({ cbuDescription: "A very long CBU description for testing" });
    render(<DashboardTable {...baseProps({ paginatedRows: [row] })} />);

    const expandAllButton = screen.getByTitle("Expand all descriptions");
    fireEvent.click(expandAllButton);
    expect(screen.getByTitle("Collapse all descriptions")).toBeInTheDocument();

    fireEvent.click(screen.getByTitle("Collapse all descriptions"));
    expect(screen.getByTitle("Expand all descriptions")).toBeInTheDocument();
  });

  describe("cover dates stay pinned to the row's static API values regardless of RM/PM selection (no client-side recomputation)", () => {
    const coverCols = ALL_COLS.filter(
      (c) => c.id === "cover_total" || c.id === "cover_excl",
    );

    function renderWithSelection(selected: Set<string>) {
      const row = makeRow({
        srNo: 1,
        fg: { dcStock: 100, factoryStock: 0, inTransitStock: 0, totalStock: 100 },
        demand: { sumNext3TDP: 10, next6Months: 20, next12Months: 365 },
        coverMax: {
          fgCoverDate: "01-07-2026",
          totalCoverDate: "01-10-2026",
          coverExclOpenPO: "24-07-2026",
        },
      });
      const comps = [
        makeComponent({ componentCode: "C1", unrestrictedStock: 50, qualityStock: 0, openPOStock: 0 }),
        makeComponent({ componentCode: "C2", unrestrictedStock: 10, qualityStock: 0, openPOStock: 0 }),
      ];
      return render(
        <DashboardTable
          {...baseProps({
            orderedDataCols: coverCols,
            groupRuns: computeGroupRuns(coverCols),
            paginatedRows: [row],
            expandedSrNo: 1,
            componentCache: { 1: comps },
            selectedComponents: { 1: selected },
          })}
        />,
      );
    }

    it("keeps Total FG Cover pinned to the row's static API date after deselecting a component, without recalculatedRow supplying a fresh value", () => {
      const { unmount } = renderWithSelection(new Set(["C1", "C2"]));
      expect(screen.getByText("01-10-2026")).toBeInTheDocument();
      unmount();

      // Deselecting a component with no recalculatedRow prop supplied must
      // NOT change what's displayed — there's no client-side computation
      // left to react to the selection; only a real
      // POST /api/v1/cbus/recalculate/summary response (surfaced via
      // recalculatedRow) can ever change these figures.
      renderWithSelection(new Set(["C2"]));
      expect(screen.getByText("01-10-2026")).toBeInTheDocument();
    });

    it("keeps Excl. Open PO pinned to the row's static API date the same way", () => {
      const { unmount } = renderWithSelection(new Set(["C1", "C2"]));
      expect(screen.getByText("24-07-2026")).toBeInTheDocument();
      unmount();

      renderWithSelection(new Set(["C2"]));
      expect(screen.getByText("24-07-2026")).toBeInTheDocument();
    });
  });

  describe("recalculatedRow replaces the expanded row's data wholesale, including legitimate all-zero fields", () => {
    const rmpmCols = ALL_COLS.filter(
      (c) => c.id === "rmpmMin_physical" || c.id === "rmpm_physical",
    );
    const zeroRmpm = {
      physicalStock: 0,
      qualityStock: 0,
      openPOStock: 0,
      totalStock: 0,
      blockedStock: 0,
      supplierInventory: 0,
      inTransitStock: 0,
    };

    it("shows the recalculated response's RM/PM stock exactly as returned, including a legitimate all-zero half — not discarded as 'hollow'", () => {
      // Mirrors a real POST /api/v1/cbus/recalculate/summary response:
      // rmpmMax carries real figures, rmpmMin is legitimately all-zero
      // (e.g. every currently-selected component has zero stock at the Min
      // bound) — a genuine answer, not a broken/mismatched payload.
      const row = makeRow({
        srNo: 1,
        rmpmMin: { ...zeroRmpm, physicalStock: 777, totalStock: 777 },
      });
      const comps = [makeComponent({ componentCode: "C1", unrestrictedStock: 2493173769 })];
      const recalculatedRow = makeRow({
        srNo: 1,
        rmpmMax: { ...zeroRmpm, physicalStock: 23139527824, totalStock: 23139527824 },
        rmpmMin: zeroRmpm,
      });

      render(
        <DashboardTable
          {...baseProps({
            orderedDataCols: rmpmCols,
            groupRuns: computeGroupRuns(rmpmCols),
            paginatedRows: [row],
            expandedSrNo: 1,
            componentCache: { 1: comps },
            selectedComponents: { 1: new Set(["C1"]) },
            recalculatedRow,
          })}
        />,
      );

      // Max: the recalculated response's real figure.
      expect(screen.getByText("23,139,527,824")).toBeInTheDocument();
      // Min: the recalculated response's own zero (renders as "—", the
      // app's normal zero-value convention) — not the row's static
      // rmpmMin.physicalStock of 777, which an earlier "hollow" guard would
      // have incorrectly fallen back to.
      expect(screen.queryByText("777")).not.toBeInTheDocument();
    });

    it("uses the recalculated response once it reports real RM/PM stock", () => {
      const row = makeRow({ srNo: 1 });
      const comps = [makeComponent({ componentCode: "C1", unrestrictedStock: 999 })];
      const recalculatedRow = makeRow({
        srNo: 1,
        rmpmMax: { ...zeroRmpm, physicalStock: 12345, totalStock: 12345 },
        rmpmMin: { ...zeroRmpm, physicalStock: 6789, totalStock: 6789 },
      });

      render(
        <DashboardTable
          {...baseProps({
            orderedDataCols: rmpmCols,
            groupRuns: computeGroupRuns(rmpmCols),
            paginatedRows: [row],
            expandedSrNo: 1,
            componentCache: { 1: comps },
            selectedComponents: { 1: new Set(["C1"]) },
            recalculatedRow,
          })}
        />,
      );

      expect(screen.getByText("12,345")).toBeInTheDocument();
      expect(screen.getByText("6,789")).toBeInTheDocument();
    });

    it("replaces FG Cover with the recalculated response's own date too, once a recalculated row exists for this CBU", () => {
      const row = makeRow({
        srNo: 1,
        coverMax: {
          fgCoverDate: "01-07-2026",
          totalCoverDate: "01-10-2026",
          coverExclOpenPO: "24-07-2026",
        },
      });
      const comps = [makeComponent({ componentCode: "C1", unrestrictedStock: 999 })];
      const recalculatedRow = makeRow({
        srNo: 1,
        rmpmMax: { ...zeroRmpm, physicalStock: 12345, totalStock: 12345 },
        rmpmMin: { ...zeroRmpm, physicalStock: 12345, totalStock: 12345 },
        coverMax: {
          fgCoverDate: "15-08-2099",
          totalCoverDate: "16-08-2099",
          coverExclOpenPO: "17-08-2099",
        },
      });

      const fgCoverCol = ALL_COLS.filter((c) => c.id === "cover_fg");

      render(
        <DashboardTable
          {...baseProps({
            orderedDataCols: fgCoverCol,
            groupRuns: computeGroupRuns(fgCoverCol),
            paginatedRows: [row],
            expandedSrNo: 1,
            componentCache: { 1: comps },
            selectedComponents: { 1: new Set(["C1"]) },
            recalculatedRow,
          })}
        />,
      );

      expect(screen.getByText("15-08-2099")).toBeInTheDocument();
      expect(screen.queryByText("01-07-2026")).not.toBeInTheDocument();
    });

    it("replaces Total FG Cover/Excl. Open PO wholesale — both Max and Min — once a recalculated row exists, even when the Min RM/PM figures are all-zero", () => {
      const row = makeRow({ srNo: 1 });
      const comps = [makeComponent({ componentCode: "C1", unrestrictedStock: 2493173769 })];
      const recalculatedRow = makeRow({
        srNo: 1,
        rmpmMax: { ...zeroRmpm, physicalStock: 999999, totalStock: 999999 },
        rmpmMin: zeroRmpm,
        coverMax: {
          fgCoverDate: "01-09-2099",
          totalCoverDate: "02-09-2099",
          coverExclOpenPO: "03-09-2099",
        },
        coverMin: {
          fgCoverDate: "04-09-2099",
          totalCoverDate: "05-09-2099",
          coverExclOpenPO: "06-09-2099",
        },
      });

      const coverCols = ALL_COLS.filter(
        (c) => c.id === "cover_total" || c.id === "cover_excl" || c.id === "cover_total_min" || c.id === "cover_excl_min",
      );

      render(
        <DashboardTable
          {...baseProps({
            orderedDataCols: coverCols,
            groupRuns: computeGroupRuns(coverCols),
            paginatedRows: [row],
            expandedSrNo: 1,
            componentCache: { 1: comps },
            selectedComponents: { 1: new Set(["C1"]) },
            recalculatedRow,
          })}
        />,
      );

      expect(screen.getByText("02-09-2099")).toBeInTheDocument();
      expect(screen.getByText("03-09-2099")).toBeInTheDocument();
      // Min side comes from the recalculated response too — an all-zero
      // rmpmMin doesn't stop its own coverMin from being trusted.
      expect(screen.getByText("05-09-2099")).toBeInTheDocument();
      expect(screen.getByText("06-09-2099")).toBeInTheDocument();
    });

    it("keeps the row's own identity (srNo used for toggle callbacks) even when data fields come from a recalculated response with a different slNo/srNo", () => {
      const row = makeRow({ srNo: 1 });
      const comps = [makeComponent({ componentCode: "C1", unrestrictedStock: 999 })];
      // The recalculate/summary endpoint's own slNo is not this row's rank
      // in the current dashboard listing (see fetchCbuByCode's comment in
      // cbuApi.ts) — it must never leak into anything keyed by srNo.
      const recalculatedRow = makeRow({ srNo: 999 });
      const onToggleComp = jest.fn();

      render(
        <DashboardTable
          {...baseProps({
            paginatedRows: [row],
            expandedSrNo: 1,
            componentCache: { 1: comps },
            selectedComponents: { 1: new Set(["C1"]) },
            recalculatedRow,
            onToggleComp,
          })}
        />,
      );

      fireEvent.click(screen.getByText("C1"));
      expect(onToggleComp).toHaveBeenCalledWith(1, "C1", "unique");
    });
  });
});
