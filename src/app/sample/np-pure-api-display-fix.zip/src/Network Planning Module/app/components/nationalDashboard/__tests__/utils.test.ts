import {
  buildDefaultColOrderByGroup,
  buildOrderedCols,
  countVisibleColumns,
  computeGroupRuns,
  metaColsWidth,
  metaColLeft,
  mapSmallCDisplay,
  mapBgDisplay,
  inferFormatDisplay,
  formatBasePackOption,
  formatCbuOption,
  componentScopeLabel,
  pickSeeded,
  splitBySeed,
  transitTooltip,
  calcCover,
  parseCoverDate,
  computeEffRmpm,
  compareSortValues,
  getVisiblePages,
  getColTheme,
  getRowCoverResults,
  isCustomComponentSelection,
  getEffRmpmForRow,
  getRowSortValue,
  buildRowSearchText,
  getMetaColumnValue,
  coverResultFromDate,
  cellBaseStyle,
  subHdrStyle,
  stickyHead,
  stickyBody,
} from "../utils";
import { ALL_COLS, DEFAULT_GROUP_ORDER } from "../../../constants/nationalDashboard";
import type { CBURow, AggregatedComponent } from "../../data";
import type { EffRmpm } from "../types";

const zeroEff: EffRmpm = {
  physicalStock: 0,
  qualityStock: 0,
  stvStock: 0,
  openPOStock: 0,
  totalStock: 0,
  blockedStock: 0,
  supplierInventory: 0,
  inTransitStock: 0,
};

function makeRow(overrides: Partial<CBURow> = {}): CBURow {
  return {
    srNo: 1,
    cbuCode: "TESTCODE",
    cbuDescription: "Test CBU 200ML",
    weightKg: 0.2,
    fg: { dcStock: 100, factoryStock: 50, inTransitStock: 20, totalStock: 170 },
    rmpm: {
      physicalStock: 40,
      qualityStock: 10,
      openPOStock: 5,
      totalStock: 55,
      blockedStock: 0,
      supplierInventory: 0,
      inTransitStock: 0,
    },
    rmpmMin: {
      physicalStock: 40,
      qualityStock: 10,
      openPOStock: 5,
      totalStock: 55,
      blockedStock: 0,
      supplierInventory: 0,
      inTransitStock: 0,
    },
    rmpmMax: {
      physicalStock: 40,
      qualityStock: 10,
      openPOStock: 5,
      totalStock: 55,
      blockedStock: 0,
      supplierInventory: 0,
      inTransitStock: 0,
    },
    demand: { sumNext3TDP: 30, next6Months: 100, next12Months: 200 },
    totalFG: 170,
    cover: { fgCoverDate: "N/A", totalCoverDate: "N/A", coverExclOpenPO: "N/A" },
    ...overrides,
  };
}

function makeComponent(overrides: Partial<AggregatedComponent> = {}): AggregatedComponent {
  return {
    componentCode: "C1",
    componentMaterialType: "1002",
    unrestrictedStock: 10,
    qualityStock: 2,
    blockedStock: 0,
    totalStock: 12,
    openPOStock: 3,
    ...overrides,
  };
}

describe("buildDefaultColOrderByGroup", () => {
  it("assigns every column to its own group, in ALL_COLS order", () => {
    const result = buildDefaultColOrderByGroup();
    for (const col of ALL_COLS) {
      expect(result[col.group]).toContain(col.id);
    }
    expect(result.meta[0]).toBe(ALL_COLS.find((c) => c.group === "meta")!.id);
  });
});

describe("buildOrderedCols / countVisibleColumns", () => {
  const colOrderByGroup = buildDefaultColOrderByGroup();

  it("returns columns following groupOrder, skipping hidden groups/cols", () => {
    const result = buildOrderedCols(
      DEFAULT_GROUP_ORDER,
      colOrderByGroup,
      new Set(["fg"]),
      new Set(["basePack"]),
    );
    expect(result.some((c) => c.group === "fg")).toBe(false);
    expect(result.some((c) => c.id === "basePack")).toBe(false);
  });

  it("keeps required columns (cbuCode/cbuDescription) visible even when hidden via cols or their group", () => {
    const result = buildOrderedCols(
      DEFAULT_GROUP_ORDER,
      colOrderByGroup,
      new Set(["meta"]),
      new Set(["cbuCode", "cbuDescription"]),
    );
    expect(result.some((c) => c.id === "cbuCode")).toBe(true);
    expect(result.some((c) => c.id === "cbuDescription")).toBe(true);
  });

  it("counts visible columns consistently with buildOrderedCols", () => {
    const hiddenGroups = new Set<typeof DEFAULT_GROUP_ORDER[number]>(["cover"]);
    const hiddenCols = new Set(["bg"]);
    const ordered = buildOrderedCols(DEFAULT_GROUP_ORDER, colOrderByGroup, hiddenGroups, hiddenCols);
    const count = countVisibleColumns(DEFAULT_GROUP_ORDER, colOrderByGroup, hiddenGroups, hiddenCols);
    expect(count).toBe(ordered.length);
  });
});

describe("computeGroupRuns", () => {
  it("groups consecutive columns of the same group into runs", () => {
    const cols = [
      { id: "a", group: "fg" as const, label: "A", minWidth: 10 },
      { id: "b", group: "fg" as const, label: "B", minWidth: 10 },
      { id: "c", group: "demand" as const, label: "C", minWidth: 10 },
    ];
    expect(computeGroupRuns(cols)).toEqual([
      { group: "fg", count: 2 },
      { group: "demand", count: 1 },
    ]);
  });

  it("returns an empty array for no columns", () => {
    expect(computeGroupRuns([])).toEqual([]);
  });
});

describe("metaColsWidth / metaColLeft", () => {
  const cols = [
    { id: "a", group: "meta" as const, label: "A", minWidth: 100 },
    { id: "b", group: "meta" as const, label: "B", minWidth: 50 },
  ];

  it("sums minWidth across columns", () => {
    expect(metaColsWidth(cols)).toBe(150);
  });

  it("computes left offset as W_SR plus preceding columns' widths", () => {
    expect(metaColLeft(cols, 0)).toBeGreaterThanOrEqual(0);
    expect(metaColLeft(cols, 1) - metaColLeft(cols, 0)).toBe(100);
  });
});

describe("display formatting helpers", () => {
  it("maps known Small C values, uppercases unknown ones", () => {
    expect(mapSmallCDisplay("Skin Care")).toBe("SKIN");
    expect(mapSmallCDisplay("Unknown")).toBe("UNKNOWN");
  });

  it("maps known BG values, uppercases unknown ones", () => {
    expect(mapBgDisplay("HPC")).toBe("B&W");
    expect(mapBgDisplay("Foods")).toBe("FOODS");
  });

  it("infers format bucket from ML size in description", () => {
    expect(inferFormatDisplay("Vaseline lotion 90ML")).toBe("SKIN BOTTLES (SMALL)");
    expect(inferFormatDisplay("Vaseline lotion 200ML")).toBe("SKIN BOTTLES (MED)");
    expect(inferFormatDisplay("Vaseline lotion 600ML")).toBe("SKIN BOTTLES (LARGE)");
  });

  it("defaults to medium when no ML size is present", () => {
    expect(inferFormatDisplay("No size here")).toBe("SKIN BOTTLES (MED)");
  });

  it("formats CBU option as code: description", () => {
    const row = makeRow({ cbuCode: "ABC", cbuDescription: "My CBU" });
    expect(formatCbuOption(row)).toBe("ABC: My CBU");
  });

  it("formats base pack option using code + description lookups", () => {
    const row = makeRow({ srNo: 999 });
    // srNo 999 has no BASE_PACK_CODE_BY_SR entry, so code falls back to "".
    expect(formatBasePackOption(row)).toBe(`: ${row.cbuDescription.toUpperCase()}`);
  });
});

describe("componentScopeLabel", () => {
  it("labels ALL/RM/PM scopes", () => {
    expect(componentScopeLabel("ALL")).toBe("(all locations)");
    expect(componentScopeLabel("RM")).toBe("(RM)");
    expect(componentScopeLabel("PM")).toBe("(PM)");
  });
});

describe("pickSeeded", () => {
  it("returns `count` items starting from a seed-derived offset", () => {
    const items = ["a", "b", "c", "d"];
    const result = pickSeeded(items, 2, 1);
    expect(result).toHaveLength(2);
    result.forEach((item) => expect(items).toContain(item));
  });

  it("wraps around and never exceeds the source length", () => {
    const items = ["a", "b", "c"];
    expect(pickSeeded(items, 10, 0)).toHaveLength(3);
  });

  it("handles negative seeds without throwing", () => {
    const items = ["a", "b", "c"];
    expect(() => pickSeeded(items, 2, -5)).not.toThrow();
  });
});

describe("splitBySeed", () => {
  it("splits a total across labels, summing back to the original total", () => {
    const labels = ["x", "y", "z"];
    const parts = splitBySeed(1000, labels, 42);
    expect(parts).toHaveLength(3);
    expect(parts.reduce((sum, p) => sum + p.value, 0)).toBe(1000);
  });

  it("returns zero values for every label when total is zero", () => {
    const parts = splitBySeed(0, ["a", "b"], 1);
    expect(parts).toEqual([
      { label: "a", value: 0 },
      { label: "b", value: 0 },
    ]);
  });

  it("returns an empty array when there are no labels", () => {
    expect(splitBySeed(100, [], 1)).toEqual([]);
  });
});

describe("transitTooltip", () => {
  it("returns the no-stock message when total is zero", () => {
    expect(transitTooltip(0, 1)).toBe("No stock currently recorded.");
  });

  it("returns a route breakdown listing the total when stock exists", () => {
    const tooltip = transitTooltip(500, 3);
    expect(tooltip).toContain("In-Transit by route:");
    expect(tooltip.split("\n").length).toBeGreaterThan(1);
  });
});

describe("calcCover", () => {
  it('returns "-" when neither stock nor demand is available', () => {
    expect(calcCover(0, 0)).toEqual({ days: null, date: "-" });
  });

  it('reports "Excess Stock" when stock is available but there is no demand', () => {
    expect(calcCover(100, 0)).toEqual({ days: null, date: "Excess Stock" });
  });

  it("computes an immediate (0-day) cover date when demand exists but stock is zero", () => {
    const result = calcCover(0, 100);
    expect(result.days).toBe(0);
    expect(result.date).toMatch(/^\d{2}-\d{2}-\d{4}$/);
  });

  it("computes a positive day count and dd-mm-yyyy date for positive inputs", () => {
    const result = calcCover(365, 365);
    expect(result.days).toBe(365);
    expect(result.date).toMatch(/^\d{2}-\d{2}-\d{4}$/);
  });

  it('reports ">12 Months" once stock alone exceeds 12 months of demand', () => {
    const result = calcCover(1000, 500);
    expect(result.date).toBe(">12 Months");
    expect(result.days).toBe(730);
  });

  it("does not report >12 Months when stock equals (but doesn't exceed) 12 months of demand", () => {
    const result = calcCover(500, 500);
    expect(result.date).not.toBe(">12 Months");
  });
});

describe("parseCoverDate", () => {
  it("parses dd-mm-yyyy strings to a timestamp", () => {
    const ts = parseCoverDate("15-06-2026");
    const d = new Date(ts);
    expect(d.getFullYear()).toBe(2026);
    expect(d.getMonth()).toBe(5);
    expect(d.getDate()).toBe(15);
  });

  it("parses yyyy-mm strings to the 1st of that month", () => {
    const ts = parseCoverDate("2026-10");
    const d = new Date(ts);
    expect(d.getFullYear()).toBe(2026);
    expect(d.getMonth()).toBe(9);
    expect(d.getDate()).toBe(1);
  });

  it("treats N/A, dash, em-dash and empty string as negative infinity", () => {
    expect(parseCoverDate("N/A")).toBe(Number.NEGATIVE_INFINITY);
    expect(parseCoverDate("-")).toBe(Number.NEGATIVE_INFINITY);
    expect(parseCoverDate("—")).toBe(Number.NEGATIVE_INFINITY);
    expect(parseCoverDate("")).toBe(Number.NEGATIVE_INFINITY);
  });

  it("treats Excess Stock and >12 Months as positive infinity", () => {
    expect(parseCoverDate("Excess Stock")).toBe(Number.POSITIVE_INFINITY);
    expect(parseCoverDate(">12 Months")).toBe(Number.POSITIVE_INFINITY);
  });

  it("falls back to 0 for unrecognised formats", () => {
    expect(parseCoverDate("garbage")).toBe(0);
  });
});

describe("computeEffRmpm", () => {
  it("falls back to the row's own rmpm figures when no components exist", () => {
    const row = makeRow();
    const result = computeEffRmpm([], [], false, new Set(), "ALL", row);
    expect(result.totalStock).toBe(
      row.rmpm.physicalStock + row.rmpm.qualityStock + row.rmpm.openPOStock,
    );
  });

  it("returns all-zero figures when no components are selected", () => {
    const row = makeRow();
    const comps = [makeComponent()];
    const result = computeEffRmpm(comps, [], false, new Set(), "ALL", row);
    expect(result).toEqual({
      physicalStock: 0,
      qualityStock: 0,
      stvStock: 0,
      openPOStock: 0,
      totalStock: 0,
      blockedStock: 0,
      supplierInventory: 0,
      inTransitStock: 0,
    });
  });

  it("sums unrestricted stock across selected components in max mode", () => {
    const row = makeRow();
    const comps = [
      makeComponent({ componentCode: "A", unrestrictedStock: 10 }),
      makeComponent({ componentCode: "B", unrestrictedStock: 50 }),
    ];
    const selected = new Set(["A", "B"]);
    const result = computeEffRmpm(comps, [], false, selected, "ALL", row, "max");
    expect(result.physicalStock).toBe(60);
  });

  it("sums unrestricted stock across selected components in min mode too — once a selection is applied, min and max agree", () => {
    const row = makeRow();
    const comps = [
      makeComponent({ componentCode: "A", unrestrictedStock: 10 }),
      makeComponent({ componentCode: "B", unrestrictedStock: 50 }),
    ];
    const selected = new Set(["A", "B"]);
    const result = computeEffRmpm(comps, [], false, selected, "ALL", row, "min");
    expect(result.physicalStock).toBe(60);
  });

  it("filters components by RM/PM type when typeFilter is set", () => {
    const row = makeRow();
    const comps = [
      makeComponent({ componentCode: "RM1", componentMaterialType: "1001", unrestrictedStock: 20 }),
      makeComponent({ componentCode: "PM1", componentMaterialType: "1002", unrestrictedStock: 999 }),
    ];
    const selected = new Set(["RM1", "PM1"]);
    const result = computeEffRmpm(comps, [], false, selected, "RM", row, "max");
    expect(result.physicalStock).toBe(20);
  });

  it("includes high-contributing components only when showHighContributing is true", () => {
    const row = makeRow();
    const comps = [makeComponent({ componentCode: "A", unrestrictedStock: 5 })];
    const highComps = [makeComponent({ componentCode: "H", unrestrictedStock: 999 })];
    const selected = new Set(["A", "H"]);

    const withoutHigh = computeEffRmpm(comps, highComps, false, selected, "ALL", row, "max");
    expect(withoutHigh.physicalStock).toBe(5);

    const withHigh = computeEffRmpm(comps, highComps, true, selected, "ALL", row, "max");
    expect(withHigh.physicalStock).toBe(1004);
  });

  it("reports zero STV stock once real components are loaded, since the /components API has no STV dimension to aggregate", () => {
    const row = makeRow();
    const comps = [makeComponent({ componentCode: "A", unrestrictedStock: 10, qualityStock: 5 })];
    const selected = new Set(["A"]);
    const result = computeEffRmpm(comps, [], false, selected, "ALL", row, "max");
    expect(result.stvStock).toBe(0);
  });
});

describe("compareSortValues", () => {
  it("compares numbers ascending/descending", () => {
    expect(compareSortValues(1, 2, "asc")).toBeLessThan(0);
    expect(compareSortValues(1, 2, "desc")).toBeGreaterThan(0);
  });

  it("compares strings using natural/numeric ordering", () => {
    expect(compareSortValues("a", "b", "asc")).toBeLessThan(0);
    expect(compareSortValues("item2", "item10", "asc")).toBeLessThan(0);
  });
});

describe("getVisiblePages", () => {
  it("returns just page 1 when there are no pages", () => {
    expect(getVisiblePages(1, 1)).toEqual([1]);
  });

  it("returns every page when total pages is small", () => {
    expect(getVisiblePages(1, 5)).toEqual([1, 2, 3, 4, 5]);
  });

  it("collapses distant pages into an ellipsis for large page counts", () => {
    const result = getVisiblePages(10, 20);
    expect(result[0]).toBe(1);
    expect(result).toContain("ellipsis");
    expect(result.at(-1)).toBe(20);
  });

  it("never produces two consecutive ellipses", () => {
    const result = getVisiblePages(1, 100);
    for (let i = 1; i < result.length; i++) {
      expect(!(result[i] === "ellipsis" && result[i - 1] === "ellipsis")).toBe(true);
    }
  });
});

describe("buildRowSearchText", () => {
  it("lowercases and joins the CBU code/description, base pack, components, and filter attributes", () => {
    const row = makeRow({ cbuCode: "ABC", cbuDescription: "Some Description" });
    const text = buildRowSearchText(row, {
      bg: "BG1",
      smallC: "SC1",
      format: "Small",
      brand: "BrandX",
    });
    expect(text).toBe(text.toLowerCase());
    expect(text).toContain("abc");
    expect(text).toContain("some description");
    expect(text).toContain("bg1");
    expect(text).toContain("brandx");
  });
});

describe("getMetaColumnValue", () => {
  it("returns the raw field for cbuCode/cbuDescription", () => {
    const row = makeRow({ cbuCode: "XYZ", cbuDescription: "Desc" });
    expect(getMetaColumnValue(row, "cbuCode")).toBe("XYZ");
    expect(getMetaColumnValue(row, "cbuDescription")).toBe("Desc");
  });

  it("returns an empty string for an unrecognized column id", () => {
    expect(getMetaColumnValue(makeRow(), "not-a-real-col")).toBe("");
  });
});

describe("coverResultFromDate", () => {
  it("maps N/A and empty strings to a '-' CoverResult", () => {
    expect(coverResultFromDate("N/A")).toEqual({ days: null, date: "-" });
    expect(coverResultFromDate("")).toEqual({ days: null, date: "-" });
  });

  it("maps Excess Stock and >12 Months through unchanged with a null day count", () => {
    expect(coverResultFromDate("Excess Stock")).toEqual({ days: null, date: "Excess Stock" });
    expect(coverResultFromDate(">12 Months")).toEqual({ days: null, date: ">12 Months" });
  });

  it("computes a day count relative to TODAY for a dd-mm-yyyy date", () => {
    const result = coverResultFromDate("01-01-2099");
    expect(result.date).toBe("01-01-2099");
    expect(typeof result.days).toBe("number");
  });

  it("passes through an unrecognized format with a null day count", () => {
    expect(coverResultFromDate("2026-10")).toEqual({ days: null, date: "2026-10" });
  });
});

describe("getColTheme (remaining branches)", () => {
  it("returns the rmpm theme for rmpm/rmpmMin columns", () => {
    expect(getColTheme("rmpm_physical")).toEqual({ bg: "#ecfdf5", text: "#00695C" });
    expect(getColTheme("rmpmMin_blocked")).toEqual({ bg: "#ecfdf5", text: "#00695C" });
  });

  it("returns the demand theme for demand columns", () => {
    expect(getColTheme("demand_12m")).toEqual({ bg: "#daeefb", text: "#0277BD" });
  });

  it("returns the FG-summary theme for total_fg/total_fg_min", () => {
    expect(getColTheme("total_fg")).toEqual({ bg: "#e0f2fe", text: "#075985" });
    expect(getColTheme("total_fg_min")).toEqual({ bg: "#e0f2fe", text: "#075985" });
  });

  it("returns the FG-cover theme for cover columns", () => {
    expect(getColTheme("cover_total_min")).toEqual({ bg: "#EDF1F7", text: "#003087" });
  });
});

describe("cellBaseStyle", () => {
  it("uses the matching column theme's text color with a shared border", () => {
    expect(cellBaseStyle("fg_total")).toEqual({
      color: "#1565C0",
      border: "1px solid #9ca3af",
    });
  });

  it("adds a bold left border when the column starts a new group", () => {
    expect(cellBaseStyle("fg_total", true)).toEqual({
      color: "#1565C0",
      border: "1px solid #9ca3af",
      borderLeftWidth: 2,
      borderLeftColor: "#9ca3af",
    });
  });
});

describe("subHdrStyle", () => {
  it("uses the RMPM header theme (not the body data-type theme) for rmpm columns", () => {
    expect(subHdrStyle("rmpm_physical")).toEqual({
      backgroundColor: "#d6e8fb",
      color: "#134EB4",
    });
  });

  it("falls back to the body column theme for non-RMPM columns", () => {
    expect(subHdrStyle("fg_total")).toEqual({
      backgroundColor: "#dbeafe",
      color: "#1565C0",
    });
  });
});

describe("stickyHead / stickyBody", () => {
  it("stickyHead pins to the given left offset without a background color", () => {
    expect(stickyHead(40, 100)).toEqual({
      position: "sticky",
      left: 40,
      zIndex: 30,
      minWidth: 100,
      maxWidth: 100,
    });
  });

  it("stickyBody additionally carries the row's background color", () => {
    expect(stickyBody(40, 100, "#ffffff")).toEqual({
      position: "sticky",
      left: 40,
      zIndex: 5,
      minWidth: 100,
      maxWidth: 100,
      backgroundColor: "#ffffff",
    });
  });
});

describe("getColTheme", () => {
  it("returns the meta theme for meta columns", () => {
    expect(getColTheme("cbuCode")).toEqual({ bg: "#e8edf6", text: "#003087" });
  });

  it("returns the fg theme for fg columns", () => {
    expect(getColTheme("fg_total")).toEqual({ bg: "#dbeafe", text: "#1565C0" });
  });

  it("falls back to a default theme for unknown column ids", () => {
    expect(getColTheme("unknown_col")).toEqual({ bg: "#EDF5FA", text: "#374151" });
  });
});

describe("getRowCoverResults", () => {
  it("reads the row's precomputed coverMax/coverMin when no components are loaded", () => {
    const row = makeRow({
      coverMax: { fgCoverDate: "01-07-2026", totalCoverDate: "01-10-2026", coverExclOpenPO: "24-07-2026" },
      coverMin: { fgCoverDate: "02-07-2026", totalCoverDate: "02-10-2026", coverExclOpenPO: "25-07-2026" },
    });
    const result = getRowCoverResults(row, zeroEff, zeroEff, false, false);
    expect(result.fgCov.date).toBe("01-07-2026");
    expect(result.totCovMax.date).toBe("01-10-2026");
    expect(result.totCovMin.date).toBe("02-10-2026");
    expect(result.exclCovMax.date).toBe("24-07-2026");
    expect(result.exclCovMin.date).toBe("25-07-2026");
  });

  it("falls back to the row's single 'cover' field when coverMax/coverMin are absent", () => {
    const row = makeRow({
      coverMax: undefined,
      coverMin: undefined,
      cover: { fgCoverDate: "03-07-2026", totalCoverDate: "03-10-2026", coverExclOpenPO: "26-07-2026" },
    });
    const result = getRowCoverResults(row, zeroEff, zeroEff, false, false);
    expect(result.fgCov.date).toBe("03-07-2026");
    expect(result.totCovMax.date).toBe("03-10-2026");
  });

  it("computes totalFGMax/totalFGMin from the row's FG stock plus effMax/effMin total stock", () => {
    const row = makeRow({ fg: { dcStock: 10, factoryStock: 10, inTransitStock: 0, totalStock: 20 } });
    const effMax = { ...zeroEff, totalStock: 5 };
    const effMin = { ...zeroEff, totalStock: 2 };
    const result = getRowCoverResults(row, effMax, effMin, false, false);
    expect(result.totalFGMax).toBe(25);
    expect(result.totalFGMin).toBe(22);
  });

  it("computes totCov/exclCov client-side from effMax/effMin once components are loaded and a real filter is applied", () => {
    const row = makeRow({
      fg: { dcStock: 100, factoryStock: 0, inTransitStock: 0, totalStock: 100 },
      demand: { sumNext3TDP: 10, next6Months: 20, next12Months: 365 },
    });
    const effMax = { ...zeroEff, totalStock: 50, physicalStock: 0, qualityStock: 0 };
    const result = getRowCoverResults(row, effMax, effMax, true, true);
    // demand12M=365 -> 1/day; FG (100) + effMax total stock (50) covers 150 days from TODAY.
    expect(result.totCovMax.days).toBe(150);
  });

  it("keeps fgCov, totCov, and exclCov sourced from the API's precomputed dates once components are loaded but nothing has been filtered, so none of them change between collapsed and expanded", () => {
    const row = makeRow({
      coverMax: { fgCoverDate: "01-07-2026", totalCoverDate: "01-10-2026", coverExclOpenPO: "24-07-2026" },
      coverMin: { fgCoverDate: "02-07-2026", totalCoverDate: "02-10-2026", coverExclOpenPO: "25-07-2026" },
      fg: { dcStock: 100, factoryStock: 0, inTransitStock: 0, totalStock: 100 },
      demand: { sumNext3TDP: 10, next6Months: 20, next12Months: 365 },
    });
    const effMax = { ...zeroEff, totalStock: 50, physicalStock: 0, qualityStock: 0 };
    const collapsed = getRowCoverResults(row, effMax, effMax, false, false);
    const expandedUnfiltered = getRowCoverResults(row, effMax, effMax, true, false);
    expect(collapsed).toEqual(expandedUnfiltered);
    expect(expandedUnfiltered.fgCov.date).toBe("01-07-2026");
    expect(expandedUnfiltered.totCovMax.date).toBe("01-10-2026");
    expect(expandedUnfiltered.exclCovMax.date).toBe("24-07-2026");
  });

  it("diverges from the API's dates once a real filter is applied (hasCustomFilter true)", () => {
    const row = makeRow({
      coverMax: { fgCoverDate: "01-07-2026", totalCoverDate: "01-10-2026", coverExclOpenPO: "24-07-2026" },
      fg: { dcStock: 100, factoryStock: 0, inTransitStock: 0, totalStock: 100 },
      demand: { sumNext3TDP: 10, next6Months: 20, next12Months: 365 },
    });
    const effMax = { ...zeroEff, totalStock: 50, physicalStock: 0, qualityStock: 0 };
    const filtered = getRowCoverResults(row, effMax, effMax, true, true);
    // fgCov still pinned to the API regardless of filtering (excludes RM/PM entirely).
    expect(filtered.fgCov.date).toBe("01-07-2026");
    // totCov is recomputed client-side once filtered, so it no longer matches the API date.
    expect(filtered.totCovMax.date).not.toBe("01-10-2026");
  });
});

describe("isCustomComponentSelection", () => {
  const comps: AggregatedComponent[] = [
    { componentCode: "A", componentMaterialType: "1001", unrestrictedStock: 1, qualityStock: 0, blockedStock: 0, totalStock: 1, openPOStock: 0 },
    { componentCode: "B", componentMaterialType: "1002", unrestrictedStock: 1, qualityStock: 0, blockedStock: 0, totalStock: 1, openPOStock: 0 },
  ];

  it("is false when everything is selected, the type filter is ALL, and High Contributing is off", () => {
    const selected = new Set(["A", "B"]);
    expect(isCustomComponentSelection(comps, false, selected, "ALL")).toBe(false);
  });

  it("is true when the type filter narrows the pool", () => {
    const selected = new Set(["A", "B"]);
    expect(isCustomComponentSelection(comps, false, selected, "RM")).toBe(true);
  });

  it("is true when High Contributing is toggled on", () => {
    const selected = new Set(["A", "B"]);
    expect(isCustomComponentSelection(comps, true, selected, "ALL")).toBe(true);
  });

  it("is true when a component has been deselected", () => {
    const selected = new Set(["A"]);
    expect(isCustomComponentSelection(comps, false, selected, "ALL")).toBe(true);
  });

  it("is false when selected has a stale extra code no longer in the pool (e.g. a High Contributing code left over from the toggle being switched off)", () => {
    const selected = new Set(["A", "B", "STALE_HIGH_CONTRIB_CODE"]);
    expect(isCustomComponentSelection(comps, false, selected, "ALL")).toBe(false);
  });
});

describe("getEffRmpmForRow", () => {
  it("falls back to the row-level rmpmMin/rmpmMax figures when no components are cached", () => {
    const row = makeRow();
    const result = getEffRmpmForRow(row, "ALL", {}, {}, {}, false, "max");
    expect(result.physicalStock).toBe(row.rmpmMax.physicalStock);
  });

  it("derives the effective figure from cached components when present", () => {
    const row = makeRow({ srNo: 7 });
    const comps = [makeComponent({ componentCode: "A", unrestrictedStock: 42 })];
    const result = getEffRmpmForRow(
      row,
      "ALL",
      { 7: comps },
      {},
      {},
      false,
      "max",
    );
    expect(result.physicalStock).toBe(42);
  });

  it("defaults the selected set to every cached + high-contributing component code when not provided", () => {
    const row = makeRow({ srNo: 7 });
    const comps = [makeComponent({ componentCode: "A", unrestrictedStock: 10 })];
    const highComps = [makeComponent({ componentCode: "B", unrestrictedStock: 999 })];
    const result = getEffRmpmForRow(
      row,
      "ALL",
      { 7: comps },
      {},
      { 7: highComps },
      true,
      "max",
    );
    expect(result.physicalStock).toBe(1009);
  });
});

describe("getRowSortValue", () => {
  it("returns raw row fields for meta columns", () => {
    const row = makeRow({ srNo: 3, cbuCode: "ZZZ", cbuDescription: "Zeta" });
    expect(getRowSortValue(row, "srNo", "ALL", {}, {}, {}, false)).toBe(3);
    expect(getRowSortValue(row, "cbuCode", "ALL", {}, {}, {}, false)).toBe("ZZZ");
    expect(getRowSortValue(row, "cbuDescription", "ALL", {}, {}, {}, false)).toBe("zeta");
  });

  it("returns row-level FG/demand fields directly", () => {
    const row = makeRow({
      fg: { dcStock: 1, factoryStock: 2, inTransitStock: 3, totalStock: 4 },
      demand: { sumNext3TDP: 5, next6Months: 6, next12Months: 7 },
    });
    expect(getRowSortValue(row, "fg_dc", "ALL", {}, {}, {}, false)).toBe(1);
    expect(getRowSortValue(row, "fg_factory", "ALL", {}, {}, {}, false)).toBe(2);
    expect(getRowSortValue(row, "fg_intransit", "ALL", {}, {}, {}, false)).toBe(3);
    expect(getRowSortValue(row, "fg_total", "ALL", {}, {}, {}, false)).toBe(4);
    expect(getRowSortValue(row, "demand_3tdp", "ALL", {}, {}, {}, false)).toBe(5);
    expect(getRowSortValue(row, "demand_6m", "ALL", {}, {}, {}, false)).toBe(6);
    expect(getRowSortValue(row, "demand_12m", "ALL", {}, {}, {}, false)).toBe(7);
  });

  it("derives rmpm/rmpmMin sort values from the effective computed RMPM figures", () => {
    const row = makeRow({ srNo: 9 });
    const comps = [makeComponent({ componentCode: "A", unrestrictedStock: 77 })];
    expect(
      getRowSortValue(row, "rmpm_physical", "ALL", { 9: comps }, {}, {}, false),
    ).toBe(77);
  });

  it("derives cover sort values as a numeric timestamp via parseCoverDate", () => {
    const row = makeRow({
      coverMax: { fgCoverDate: "01-07-2026", totalCoverDate: "01-10-2026", coverExclOpenPO: "N/A" },
      coverMin: { fgCoverDate: "01-07-2026", totalCoverDate: "01-10-2026", coverExclOpenPO: "N/A" },
    });
    const value = getRowSortValue(row, "cover_fg", "ALL", {}, {}, {}, false);
    expect(typeof value).toBe("number");
    expect(value).toBeGreaterThan(0);
  });

  it("returns 0 for a column id with no known sort value", () => {
    const row = makeRow();
    expect(getRowSortValue(row, "not-a-real-col", "ALL", {}, {}, {}, false)).toBe(0);
  });
});
