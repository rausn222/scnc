import { Fragment } from "react";
import { ChevronDown, ChevronRight, FlaskConical } from "lucide-react";
import type { NavState } from "../../App";
import { getComponentDescription, getComponentTypeCode, type AggregatedComponent, type CBURow } from "../data";
import { blockedStockTooltip, BODY_VALUE_TEXT_COLOR, cellBaseStyle, getMetaColumnValue, GROUP_BOUNDARY_BORDER_COLOR, metaColLeft, metaColsWidth, ROW_HOVER_BG, stickyBody, transitTooltip } from "./utils";
import { fmtDateDaysThemed, fmtNWithTheme } from "./format";
import { CELL_TOOLTIPS, COMPONENT_BREAKDOWN_LOADING_TEXT, EMPTY_CELL_PLACEHOLDER, W_SR } from "../../constants/nationalDashboard";
import type { ColDef, CoverResult, EffRmpm, UomFilter } from "./types";
import type { CbuRecalculateContributionType } from "./apiTypes";

// Placeholder/status text ("Recalculating…") — muted relative to
// BODY_VALUE_TEXT_COLOR, but still clears WCAG's 4.5:1 minimum against the
// table's white/mint row backgrounds (the previous #94a3b8 sat at ~2.5:1).
const BODY_MUTED_TEXT_COLOR = "#5B6472";

export interface MetaCellParams {
  col: ColDef;
  row: CBURow;
  rowBg: string;
  isExpanded: boolean;
  // True while this row's POST /api/v1/cbus/recalculate/summary request
  // (fired on an RM/PM checkbox toggle) is in flight — shown as a small
  // inline cue next to the CBU code so the user knows the RM/PM stock and
  // cover figures they're looking at are about to update.
  isRecalculating?: boolean;
  onCbuClick: (row: CBURow) => void;
  navigate: (state: NavState) => void;
  stickyLeft: number;
  isDescriptionExpanded: boolean;
}

export function metaCell({
  col,
  row,
  rowBg,
  isExpanded,
  isRecalculating,
  onCbuClick,
  navigate,
  stickyLeft,
  isDescriptionExpanded,
}: MetaCellParams): React.ReactNode {
  const baseStyle: React.CSSProperties = {
    ...stickyBody(stickyLeft, col.minWidth, rowBg),
    // box-shadow instead of border: sticky-positioned cells drop collapsed
    // table borders on scroll in Chromium/WebKit, so the row/column divider
    // is painted as part of the cell's own background layer instead. Same
    // #9ca3af as cellBaseStyle's border on the scrolling data columns, so
    // the frozen columns' gridlines line up with the rest of the row.
    boxShadow: "inset 0 -1px 0 0 #9ca3af, inset -1px 0 0 0 #9ca3af",
  };

  if (col.id === "cbuCode") {
    return (
      <td
        key={col.id}
        className="px-2 py-1 font-semibold cursor-pointer"
        style={baseStyle}
        onClick={() => onCbuClick(row)}
      >
        <span
          className="flex items-center gap-1.5 whitespace-nowrap"
          style={{ color: "#1565C0" }}
        >
          {isExpanded ? (
            <ChevronDown size={13} style={{ color: "#1565C0", flexShrink: 0 }} />
          ) : (
            <ChevronRight size={13} style={{ color: "#1565C0", flexShrink: 0 }} />
          )}
          {row.cbuCode}
          {isExpanded && isRecalculating && (
            <span
              className="italic font-normal"
              style={{ color: BODY_MUTED_TEXT_COLOR, fontSize: 11 }}
              title="Recalculating RM/PM stock and cover for the current selection"
            >
              Recalculating…
            </span>
          )}
        </span>
      </td>
    );
  }

  if (col.id === "cbuDescription") {
    return (
      <td key={col.id} className="px-2 py-1" style={{
        ...baseStyle,
        maxWidth: isDescriptionExpanded ? undefined : col.minWidth,
      }}>
        <div className="flex items-center justify-between gap-3">
          <div className="flex-1 min-w-0">
            <button
              type="button"
              className={isDescriptionExpanded ? "text-left whitespace-normal hover:underline cursor-pointer" : "truncate hover:underline cursor-pointer text-left"}
              style={{
                color: "#1565C0",
                // 100%, not a hand-computed px figure — the parent's
                // flex-1 min-w-0 already sizes it to exactly whatever's
                // left after the icon button and the gap, so matching that
                // via a fixed subtraction (previously col.minWidth - 28)
                // only drifts out of sync with the td's own padding and
                // crowds or overlaps the icon.
                maxWidth: isDescriptionExpanded ? undefined : "100%",
                font: "inherit",
                background: "transparent",
                border: "none",
                padding: 0,
              }}
              title={CELL_TOOLTIPS.viewCbuDetail}
              onClick={(e) => {
                e.stopPropagation();
                navigate({ page: "cbu-detail", cbuCode: row.cbuCode });
              }}
            >
              {row.cbuDescription}
            </button>
          </div>
          <button
            type="button"
            // onClick={(e) => {
            //   e.stopPropagation();
            //   navigate({ page: "sci-detail", srNo: row.srNo });
            // }}
            // title={CELL_TOOLTIPS.openScenarioSimulation}
            title={'Coming Soon'}
            className="shrink-0 p-1 rounded transition-colors cursor-not-allowed"
            style={{ color: "#1565C0", background: "transparent", border: "none" }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.backgroundColor = ROW_HOVER_BG;
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.backgroundColor =
                "transparent";
            }}
          >
            <FlaskConical size={12} aria-hidden="true" />
          </button>
        </div>
      </td>
    );
  }

  const value = getMetaColumnValue(row, col.id);
  return (
    <td
      key={col.id}
      className="px-2 py-1 truncate"
      style={{ ...baseStyle, color: "#374151" }}
      title={value}
    >
      {value || EMPTY_CELL_PLACEHOLDER}
    </td>
  );
}

// Maps each rmpm_*/rmpmMin_* column id to the EffRmpm field it reads —
// lets the 16 otherwise-identical switch cases below collapse into one
// grouped clause (keeps mainCell's switch under Sonar's case-count limit).
const RMPM_FIELD_BY_COL: Record<string, keyof EffRmpm> = {
  rmpm_physical: "physicalStock",
  rmpm_quality: "qualityStock",
  rmpm_stv: "stvStock",
  rmpm_openpo: "openPOStock",
  rmpm_intransit: "inTransitStock",
  rmpm_supplier: "supplierInventory",
  rmpm_total: "totalStock",
  rmpm_blocked: "blockedStock",
  rmpmMin_physical: "physicalStock",
  rmpmMin_quality: "qualityStock",
  rmpmMin_stv: "stvStock",
  rmpmMin_openpo: "openPOStock",
  rmpmMin_intransit: "inTransitStock",
  rmpmMin_supplier: "supplierInventory",
  rmpmMin_total: "totalStock",
  rmpmMin_blocked: "blockedStock",
};

// Shared by the fg_dc/fg_factory/fg_intransit cases below: renders a plain
// cell when there's no stock, or a clickable/underlined one when there is —
// pulling the branch out of mainCell's switch keeps its cognitive complexity
// under Sonar's limit.
function fgStockCell(
  colId: string,
  value: number,
  display: React.ReactNode,
  zeroTitle: string,
  activeTitle: string,
  onClick: (e: React.MouseEvent) => void,
  isGroupBoundary: boolean,
): React.ReactNode {
  if (value <= 0) {
    return (
      <td key={colId} style={cellBaseStyle(colId, isGroupBoundary)} className="px-2 py-1 text-right" title={zeroTitle}>
        {display}
      </td>
    );
  }
  return (
    <td
      key={colId}
      style={{ ...cellBaseStyle(colId, isGroupBoundary), cursor: "pointer" }}
      className="px-2 py-1 text-right hover:underline"
      title={activeTitle}
      onClick={onClick}
    >
      {display}
    </td>
  );
}

// Shared by the demand_3tdp/demand_6m/demand_12m cases below: same
// zero-vs-clickable split as fgStockCell, but with a demand-specific
// tooltip/typography rather than a caller-supplied title.
function demandCell(
  colId: string,
  value: number,
  display: React.ReactNode,
  fontClass: string,
  onClick: (e: React.MouseEvent) => void,
  isGroupBoundary: boolean,
): React.ReactNode {
  if (value <= 0) {
    return (
      <td key={colId} style={cellBaseStyle(colId, isGroupBoundary)} className={`px-2 py-1 text-right ${fontClass}`} title={CELL_TOOLTIPS.noDemand}>
        {display}
      </td>
    );
  }
  return (
    <td
      key={colId}
      style={cellBaseStyle(colId, isGroupBoundary)}
      className={`px-2 py-1 text-right cursor-pointer transition-colors ${fontClass} hover:underline`}
      onClick={onClick}
    >
      {display}
    </td>
  );
}

export interface MainCellParams {
  colId: string;
  row: CBURow;
  effMax: EffRmpm;
  effMin: EffRmpm;
  uom: UomFilter;
  groupBoundaryColIds: Set<string>;
  totalFGMax: number;
  totalFGMin: number;
  fgCov: CoverResult;
  totCovMax: CoverResult;
  totCovMin: CoverResult;
  exclCovMax: CoverResult;
  exclCovMin: CoverResult;
  onDemand: (e: React.MouseEvent, period: "3tdp" | "6m" | "12m") => void;
  onDcStockClick: (e: React.MouseEvent) => void;
  onFactoryStockClick: (e: React.MouseEvent) => void;
  onInTransitClick: (e: React.MouseEvent) => void;
}

export function mainCell({
  colId,
  row,
  effMax,
  effMin,
  uom,
  groupBoundaryColIds,
  totalFGMax,
  totalFGMin,
  fgCov,
  totCovMax,
  totCovMin,
  exclCovMax,
  exclCovMin,
  onDemand,
  onDcStockClick,
  onFactoryStockClick,
  onInTransitClick,
}: MainCellParams): React.ReactNode {
  const s = (cid: string, n: number | null | undefined) =>
    fmtNWithTheme(n, BODY_VALUE_TEXT_COLOR);
  const isBoundary = groupBoundaryColIds.has(colId);
  switch (colId) {
    case "fg_dc":
      return fgStockCell(
        colId,
        row.fg.dcStock,
        s(colId, row.fg.dcStock),
        CELL_TOOLTIPS.noDcStock,
        CELL_TOOLTIPS.viewDcBreakdown,
        onDcStockClick,
        isBoundary,
      );
    case "fg_factory":
      return fgStockCell(
        colId,
        row.fg.factoryStock,
        s(colId, row.fg.factoryStock),
        CELL_TOOLTIPS.noFactoryStock,
        CELL_TOOLTIPS.viewFactoryBreakdown,
        onFactoryStockClick,
        isBoundary,
      );
    case "fg_intransit":
      return fgStockCell(
        colId,
        row.fg.inTransitStock,
        s(colId, row.fg.inTransitStock),
        CELL_TOOLTIPS.noTransitStock,
        `${transitTooltip(row.fg.inTransitStock, row.srNo)}\n\n${CELL_TOOLTIPS.viewTransitBreakdown}`,
        onInTransitClick,
        isBoundary,
      );
    case "fg_total":
      return (
        <td
          key={colId}
          style={cellBaseStyle(colId, isBoundary)}
          className="px-2 py-1 text-right font-semibold"
        >
          {s(colId, row.fg.totalStock)}
        </td>
      );
    case "fg_blocked":
      return (
        <td
          key={colId}
          style={cellBaseStyle(colId, isBoundary)}
          className="px-2 py-1 text-right"
          title={blockedStockTooltip(row.fg.dcBlockedStock, row.fg.factoryBlockedStock)}
        >
          {s(colId, row.fg.blockedStock)}
        </td>
      );
    case "rmpm_physical":
    case "rmpm_quality":
    case "rmpm_stv":
    case "rmpm_openpo":
    case "rmpm_intransit":
    case "rmpm_supplier":
    case "rmpm_total":
    case "rmpm_blocked":
    case "rmpmMin_physical":
    case "rmpmMin_quality":
    case "rmpmMin_stv":
    case "rmpmMin_openpo":
    case "rmpmMin_intransit":
    case "rmpmMin_supplier":
    case "rmpmMin_total":
    case "rmpmMin_blocked": {
      const eff = colId.startsWith("rmpmMin_") ? effMin : effMax;
      const isTotal = colId.endsWith("_total");
      return (
        <td
          key={colId}
          style={cellBaseStyle(colId, isBoundary)}
          className={`px-2 py-1 text-right${isTotal ? " font-semibold" : ""}`}
        >
          {s(colId, eff[RMPM_FIELD_BY_COL[colId]])}
        </td>
      );
    }
    case "demand_3tdp":
      return demandCell(
        colId,
        row.demand.sumNext3TDP,
        s(colId, row.demand.sumNext3TDP),
        "font-medium",
        (e) => onDemand(e, "3tdp"),
        isBoundary,
      );
    case "demand_6m":
      return demandCell(
        colId,
        row.demand.next6Months,
        s(colId, row.demand.next6Months),
        "font-medium",
        (e) => onDemand(e, "6m"),
        isBoundary,
      );
    case "demand_12m":
      return demandCell(
        colId,
        row.demand.next12Months,
        s(colId, row.demand.next12Months),
        "font-semibold",
        (e) => onDemand(e, "12m"),
        isBoundary,
      );
    case "total_fg":
      return (
        <td
          key={colId}
          style={cellBaseStyle(colId, isBoundary)}
          className="px-2 py-1 text-right font-semibold"
        >
          {s(colId, totalFGMax)}
        </td>
      );
    case "total_fg_min":
      return (
        <td
          key={colId}
          style={cellBaseStyle(colId, isBoundary)}
          className="px-2 py-1 text-right font-semibold"
        >
          {s(colId, totalFGMin)}
        </td>
      );
    case "cover_fg":
    case "cover_fg_min":
      return (
        <td
          key={colId}
          style={cellBaseStyle(colId, isBoundary)}
          className="px-2 py-1 text-right whitespace-nowrap"
        >
          {fmtDateDaysThemed(fgCov, BODY_VALUE_TEXT_COLOR)}
        </td>
      );
    case "cover_total":
      return (
        <td
          key={colId}
          style={cellBaseStyle(colId, isBoundary)}
          className="px-2 py-1 text-right whitespace-nowrap"
        >
          {fmtDateDaysThemed(totCovMax, BODY_VALUE_TEXT_COLOR)}
        </td>
      );
    case "cover_excl":
      return (
        <td
          key={colId}
          style={cellBaseStyle(colId, isBoundary)}
          className="px-2 py-1 text-right whitespace-nowrap"
        >
          {fmtDateDaysThemed(exclCovMax, BODY_VALUE_TEXT_COLOR)}
        </td>
      );
    case "cover_total_min":
      return (
        <td
          key={colId}
          style={cellBaseStyle(colId, isBoundary)}
          className="px-2 py-1 text-right whitespace-nowrap"
        >
          {fmtDateDaysThemed(totCovMin, BODY_VALUE_TEXT_COLOR)}
        </td>
      );
    case "cover_excl_min":
      return (
        <td
          key={colId}
          style={cellBaseStyle(colId, isBoundary)}
          className="px-2 py-1 text-right whitespace-nowrap"
        >
          {fmtDateDaysThemed(exclCovMin, BODY_VALUE_TEXT_COLOR)}
        </td>
      );
    default:
      return (
        <td
          key={colId}
          className="px-2 py-1 border border-gray-100"
          style={isBoundary ? { borderLeftWidth: 2, borderLeftColor: GROUP_BOUNDARY_BORDER_COLOR } : undefined}
        />
      );
  }
}

export function compCell(
  colId: string,
  comp: AggregatedComponent,
  row: CBURow,
  uom: UomFilter,
  groupBoundaryColIds: Set<string>,
): React.ReactNode {
  const s = (cid: string, n: number) =>
    fmtNWithTheme(n, BODY_VALUE_TEXT_COLOR);
  const avail = comp.unrestrictedStock + comp.qualityStock + comp.openPOStock;
  const isBoundary = groupBoundaryColIds.has(colId);
  const blank = (
    <td
      key={colId}
      className="border"
      style={{ ...cellBaseStyle(colId, isBoundary), borderColor: "#c8d8e8" }}
    />
  );
  switch (colId) {
    case "fg_dc":
    case "fg_factory":
    case "fg_intransit":
    case "fg_total":
    case "fg_blocked":
      return blank;
    case "rmpm_physical":
    case "rmpmMin_physical":
      return (
        <td key={colId} className="px-3 py-2 text-right font-medium" style={cellBaseStyle(colId, isBoundary)}>
          {s(colId, comp.unrestrictedStock)}
        </td>
      );
    case "rmpm_quality":
    case "rmpmMin_quality":
      return (
        <td key={colId} className="px-3 py-2 text-right" style={cellBaseStyle(colId, isBoundary)}>
          {s(colId, comp.qualityStock)}
        </td>
      );
    case "rmpm_openpo":
    case "rmpmMin_openpo":
      return (
        <td key={colId} className="px-3 py-2 text-right" style={cellBaseStyle(colId, isBoundary)}>
          {s(colId, comp.openPOStock)}
        </td>
      );
    case "rmpm_stv":
    case "rmpmMin_stv":
    case "rmpm_intransit":
    case "rmpm_supplier":
    case "rmpmMin_intransit":
    case "rmpmMin_supplier":
      return blank;
    case "rmpm_total":
    case "total_fg":
    case "rmpmMin_total":
    case "total_fg_min":
      return (
        <td key={colId} className="px-3 py-2 text-right font-semibold" style={cellBaseStyle(colId, isBoundary)}>
          {s(colId, avail)}
        </td>
      );
    case "rmpm_blocked":
    case "rmpmMin_blocked":
      return (
        <td key={colId} className="px-3 py-2 text-right" style={cellBaseStyle(colId, isBoundary)}>
          {s(colId, comp.blockedStock)}
        </td>
      );
    case "demand_3tdp":
    case "demand_6m":
    case "demand_12m":
      return blank;
    case "cover_fg":
    case "cover_fg_min":
      return blank;
    case "cover_total":
    case "cover_total_min":
      return (
        <td key={colId} className="px-3 py-2 text-right whitespace-nowrap" style={cellBaseStyle(colId, isBoundary)}>
          {s(colId, comp.totalFGCover)}
        </td>
      );
    case "cover_excl":
    case "cover_excl_min":
      return (
        <td key={colId} className="px-3 py-2 text-right whitespace-nowrap" style={cellBaseStyle(colId, isBoundary)}>
          {s(colId, comp.excludeOpenPO)}
        </td>
      );
    default:
      return blank;
  }
}

export interface ComponentGroupRowsParams {
  comps: AggregatedComponent[];
  keyPrefix: string;
  label: React.ReactNode;
  headerBg: string;
  emptyMessage: string;
  isLoading?: boolean;
  row: CBURow;
  selected: Set<string>;
  effectiveMetaCols: ColDef[];
  orderedDataCols: ColDef[];
  groupBoundaryColIds: Set<string>;
  stickyColCount: number;
  uom: UomFilter;
  // Which population this group's checkboxes belong to — "unique" for the
  // Unique Components group, "high-contributing" for the High Contributing
  // group — threaded through to onToggleAll/onToggleComp so the caller can
  // fire POST /api/v1/cbus/recalculate/summary against the right population
  // (see toggleComp/toggleAll in NationalDashboard.tsx).
  contributionType: CbuRecalculateContributionType;
  onToggleAll: (
    srNo: number,
    comps: AggregatedComponent[],
    allSel: boolean,
    contributionType: CbuRecalculateContributionType,
  ) => void;
  onToggleComp: (srNo: number, code: string, contributionType: CbuRecalculateContributionType) => void;
}

// Renders one meta-column cell for a component sub-row. Pulled out of
// componentGroupRows' nested comps.map/effectiveMetaCols.map so its two
// cbuCode/cbuDescription branches don't stack onto that function's own
// nesting — keeps componentGroupRows under Sonar's cognitive complexity limit.
function compMetaCell(
  col: ColDef,
  index: number,
  effectiveMetaCols: ColDef[],
  compBg: string,
  comp: AggregatedComponent,
): React.ReactNode {
  const left = metaColLeft(effectiveMetaCols, index);
  const cellStyle = {
    ...stickyBody(left, col.minWidth, compBg),
    borderColor: "rgba(21,101,192,0.12)",
  };

  if (col.id === "cbuCode") {
    return (
      <td key={`comp-meta-${col.id}`} className="px-3 py-2 border" style={cellStyle}>
        <span className="flex items-center gap-1.5 whitespace-nowrap text-xs">
          <span
            className="inline-block px-2 py-0.5 rounded-full text-[10px] font-semibold shrink-0"
            style={{ backgroundColor: "rgba(0,105,92,0.15)", color: "#00695C" }}
          >
            {getComponentTypeCode(comp.componentMaterialType)}
          </span>
          <span style={{ color: "rgba(21,101,192,0.6)" }}>⌞</span>
          <span className="font-mono font-medium" style={{ color: "#1565C0" }}>
            {comp.componentCode}
          </span>
        </span>
      </td>
    );
  }

  if (col.id === "cbuDescription") {
    return (
      <td key={`comp-meta-${col.id}`} className="px-3 py-2 border" style={cellStyle}>
        <span className="flex items-center justify-between gap-1.5">
          <span
            className="truncate text-xs"
            style={{ color: "#374151" }}
            title={getComponentDescription(comp)}
          >
            {getComponentDescription(comp)}
          </span>
          {comp.contributionPct != null && (
            <span
              className="inline-block px-1.5 py-0.5 rounded-full text-[10px] font-semibold shrink-0"
              style={{
                backgroundColor: "rgba(21,101,192,0.15)",
                color: "#1565C0",
              }}
              title="Contribution to this CBU's production"
            >
              {comp.contributionPct}%
            </span>
          )}
        </span>
      </td>
    );
  }

  return <td key={`comp-meta-${col.id}`} className="border" style={cellStyle} />;
}

/** Renders the "└ Unique Components" / "High-Contributing" sub-rows shown
 * under an expanded CBU row — a single call-site helper broken out of
 * DashboardTable so its per-component cell rendering doesn't nest more than
 * a few levels deep inside the table's row map. */
export function componentGroupRows({
  comps,
  keyPrefix,
  label,
  headerBg,
  emptyMessage,
  isLoading = false,
  row,
  selected,
  effectiveMetaCols,
  orderedDataCols,
  groupBoundaryColIds,
  stickyColCount,
  uom,
  contributionType,
  onToggleAll,
  onToggleComp,
}: ComponentGroupRowsParams): React.ReactNode {
  if (comps.length === 0) {
    return (
      <tr key={`${keyPrefix}-empty-${row.srNo}`}>
        <td
          colSpan={stickyColCount + orderedDataCols.length}
          className="py-3 pr-4 text-left italic"
          style={{
            backgroundColor: isLoading ? "#EDF5FA" : "#ffffff",
            color: isLoading ? "#1565C0" : "#00695C",
            borderBottom: "1px solid rgba(124,58,237,0.15)",
          }}
          aria-busy={isLoading}
        >
          {/* The td itself spans every column via colSpan, so it can't be
              made sticky as a whole — instead the text is pinned inside it,
              at the same left offset the sub-header "└ label" row uses for
              its own meta-column cell, so it stays under the CBU code /
              description section instead of scrolling out with the row. */}
          <span style={{ position: "sticky", left: W_SR + 12, display: "inline-block" }}>
            {isLoading ? COMPONENT_BREAKDOWN_LOADING_TEXT : emptyMessage}
          </span>
        </td>
      </tr>
    );
  }

  const groupAllSel = comps.every((c) => selected.has(c.componentCode));
  const groupSomeSel = !groupAllSel && comps.some((c) => selected.has(c.componentCode));
  const metaWidth = metaColsWidth(effectiveMetaCols);

  return (
    <Fragment key={`${keyPrefix}-group-${row.srNo}`}>
      <tr key={`${keyPrefix}-subhdr-${row.srNo}`}>
        <td
          className="px-3 py-1.5 border text-center"
          style={{
            ...stickyBody(0, W_SR, headerBg),
            borderColor: "rgba(21,101,192,0.12)",
            backgroundColor: headerBg,
          }}
        >
          <input
            type="checkbox"
            checked={groupAllSel}
            ref={(el) => {
              if (el) el.indeterminate = groupSomeSel;
            }}
            onChange={() => onToggleAll(row.srNo, comps, groupAllSel, contributionType)}
            className="w-3.5 h-3.5 cursor-pointer"
            style={{ accentColor: "#6366f1" }}
          />
        </td>
        {effectiveMetaCols.length > 0 ? (
          <td
            colSpan={effectiveMetaCols.length}
            className="px-3 py-1.5 border"
            style={{
              ...stickyBody(W_SR, metaWidth, headerBg),
              borderColor: "rgba(21,101,192,0.12)",
              backgroundColor: headerBg,
            }}
          >
            <span className="flex items-center gap-2 text-xs font-semibold" style={{ color: "#1565C0" }}>
              <span style={{ color: "rgba(21,101,192,0.6)" }}>└</span>
              {label}
            </span>
          </td>
        ) : null}
        {orderedDataCols.map((col) => (
          <td
            key={col.id}
            className="border"
            style={{
              backgroundColor: headerBg,
              borderColor: "rgba(21,101,192,0.12)",
              ...(groupBoundaryColIds.has(col.id)
                ? { borderLeftWidth: 2, borderLeftColor: GROUP_BOUNDARY_BORDER_COLOR }
                : {}),
            }}
          />
        ))}
      </tr>

      {comps.map((comp, ci) => {
        const isChecked = selected.has(comp.componentCode);
        const compBg = isChecked ? "#F0F4FC" : "#ffffff";
        return (
          <tr
            key={`${keyPrefix}-comp-${row.srNo}-${ci}`}
            className="cursor-pointer transition-all"
            style={{ backgroundColor: compBg, opacity: isChecked ? 1 : 0.55 }}
            onClick={() => onToggleComp(row.srNo, comp.componentCode, contributionType)}
          >
            <td
              className="px-3 py-2 border text-center"
              style={{ ...stickyBody(0, W_SR, compBg), borderColor: "rgba(21,101,192,0.12)" }}
            >
              <input
                type="checkbox"
                checked={isChecked}
                onChange={() => onToggleComp(row.srNo, comp.componentCode, contributionType)}
                onClick={(e) => e.stopPropagation()}
                className="w-3.5 h-3.5 cursor-pointer"
                style={{ accentColor: "#6366f1" }}
              />
            </td>

            {effectiveMetaCols.map((col, index) =>
              compMetaCell(col, index, effectiveMetaCols, compBg, comp),
            )}

            {orderedDataCols.map((col) => compCell(col.id, comp, row, uom, groupBoundaryColIds))}
          </tr>
        );
      })}
    </Fragment>
  );
}
