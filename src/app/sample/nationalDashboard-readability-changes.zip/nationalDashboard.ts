import type { ColDef, ColumnGroup } from "../components/nationalDashboard/types";

// ─── Page chrome ───────────────────────────────────────────────────────────────

export const PAGE_TITLE = "Inventory & Coverage";

export const PAGE_BREADCRUMBS = [
  { label: "SAMARTH" },
  { label: "Network Planner" },
  { label: "CBU Transition (National View)" },
];

export const REFRESH_BUTTON_TITLE = "Refresh";
export const EXPORT_BUTTON_TITLE = "Export";

export const SEARCH_PLACEHOLDER = "Search";
export const SEARCH_TOOLTIP =
  "Search by CBU code/description, material code/description, base pack, BG, Small C, Format, or Brand.";

export const HIGH_CONTRIBUTING_LABEL = "High Contributing (≥70%)";
export const highContributingToggleTitle = (showing: boolean) =>
  `${showing ? "Hide" : "Show"} components contributing ≥70% of demand`;

export const LOADING_TEXT = "Loading CBU data…";
export const ERROR_TEXT = "Could not load CBU data.";
export const COMPONENT_BREAKDOWN_LOADING_TEXT = "Loading components…";

// ─── Query error toasts ─────────────────────────────────────────────────────

export const CBU_LIST_ERROR_TOAST = "Could not load CBU list. Please try refreshing.";
export const COMPONENT_BREAKDOWNS_ERROR_TOAST =
  "Could not load component breakdowns. Please try refreshing.";
export const EXPORT_ERROR_TOAST = "Could not export the CBU list. Please try again.";
export const RECALCULATE_SUMMARY_ERROR_TOAST =
  "Could not recalculate the CBU summary for that selection. Please try again.";

// Auto-refresh cadence for the CBU list + component breakdowns. Paused while
// the browser tab is hidden (see useCbuListQuery/useComponentBreakdownsQuery's
// refetchIntervalInBackground: false) so it doesn't poll an unwatched tab.
export const DASHBOARD_REFETCH_INTERVAL_MS = 60_000;

export const NO_CBU_DATA_MESSAGE = "No CBU data available.";
export const NO_SEARCH_RESULTS_MESSAGE = "No CBUs match your search or filters.";
export const CLEAR_FILTERS_LABEL = "Clear filters";

export const FOOTER_ORG_LABEL = "FMCG Network Planning";
export const FOOTER_AGENT_LABEL = "Network Planner Agent";
export const footerDataAsOf = (formattedDate: string) =>
  `Data as of ${formattedDate} · ${FOOTER_ORG_LABEL}`;

// ─── Demand modal (DemandModal.tsx) ────────────────────────────────────────────

export const DEMAND_LOADING_TEXT = "Loading demand data…";
export const DEMAND_EMPTY_TEXT = "No demand data available";
export const DEMAND_ERROR_TEXT = "Could not load demand data.";

// ─── Stock location breakdown modal (StockLocationBreakdownModal.tsx) ─────────

export const STOCK_BREAKDOWN_LOADING_TEXT = "Loading stock breakdown…";
export const STOCK_BREAKDOWN_ERROR_TEXT = "Could not load stock breakdown.";

// ─── Production plan modal (ProductionPlanModal.tsx) ──────────────────────────

export const PRODUCTION_PLAN_LOADING_TEXT = "Loading production plan…";
export const PRODUCTION_PLAN_EMPTY_TEXT = "No production plan data available";
export const PRODUCTION_PLAN_ERROR_TEXT = "Could not load production plan.";

// ─── Filter option lists ───────────────────────────────────────────────────────

export const MATERIAL_TYPE_FILTER_OPTIONS = ["ALL", "RM", "PM"];
export const UOM_FILTER_OPTIONS = ["EA", "MT"];

export const MATERIAL_TYPE_TOGGLE_OPTIONS = [
  { value: "ALL", label: "All" },
  { value: "RM", label: "RM" },
  { value: "PM", label: "PM" },
];

export const UOM_TOGGLE_OPTIONS = [
  { value: "EA", label: "EA" },
  { value: "MT", label: "Tonnes" },
];

// ─── Column customizer (ColumnCustomizer.tsx) ──────────────────────────────────

export const ROWS_PER_PAGE_OPTIONS = [10, 20, 50, 100];

export const ALL_COLS: ColDef[] = [
  { id: "cbuCode", group: "meta", label: "CBU", minWidth: 118, required: true },
  {
    id: "cbuDescription",
    group: "meta",
    label: "CBU Description",
    minWidth: 215,
    required: true,
  },
  { id: "basePack", group: "meta", label: "BasePack", minWidth: 90 },
  {
    id: "basePackDescription",
    group: "meta",
    label: "BasePack Description",
    minWidth: 220,
  },
  { id: "smallC", group: "meta", label: "Small C", minWidth: 72 },
  { id: "bg", group: "meta", label: "BG", minWidth: 56 },
  { id: "format", group: "meta", label: "Format", minWidth: 140 },
  { id: "fg_dc", group: "fg", label: "DC Stock", minWidth: 100 },
  { id: "fg_factory", group: "fg", label: "Factory Stock", minWidth: 100 },
  { id: "fg_intransit", group: "fg", label: "In-Transit", minWidth: 90 },
  { id: "fg_total", group: "fg", label: "Total Stock", minWidth: 100 },
  { id: "fg_blocked", group: "fg", label: "Blocked Stock", minWidth: 100 },
  {
    id: "rmpm_physical",
    group: "rmpm",
    label: "Physical Stock",
    minWidth: 100,
  },
  { id: "rmpm_quality", group: "rmpm", label: "Quality Stock", minWidth: 90 },
  { id: "rmpm_stv", group: "rmpm", label: "STV Stock", minWidth: 90 },
  {
    id: "rmpm_openpo",
    group: "rmpm",
    label: "Open PO Stock",
    minWidth: 90,
  },
  { id: "rmpm_intransit", group: "rmpm", label: "In-Transit", minWidth: 90 },
  {
    id: "rmpm_supplier",
    group: "rmpm",
    label: "Supplier Inventory",
    minWidth: 110,
  },
  { id: "rmpm_total", group: "rmpm", label: "Total Stock", minWidth: 100 },
  {
    id: "rmpm_blocked",
    group: "rmpm",
    label: "Blocked Stock",
    minWidth: 90,
  },
  {
    id: "rmpmMin_physical",
    group: "rmpmMin",
    label: "Physical Stock",
    minWidth: 100,
  },
  { id: "rmpmMin_quality", group: "rmpmMin", label: "Quality Stock", minWidth: 90 },
  { id: "rmpmMin_stv", group: "rmpmMin", label: "STV Stock", minWidth: 90 },
  {
    id: "rmpmMin_openpo",
    group: "rmpmMin",
    label: "Open PO Stock",
    minWidth: 90,
  },
  { id: "rmpmMin_intransit", group: "rmpmMin", label: "In-Transit", minWidth: 90 },
  {
    id: "rmpmMin_supplier",
    group: "rmpmMin",
    label: "Supplier Inventory",
    minWidth: 110,
  },
  { id: "rmpmMin_total", group: "rmpmMin", label: "Total Stock", minWidth: 100 },
  {
    id: "rmpmMin_blocked",
    group: "rmpmMin",
    label: "Blocked Stock",
    minWidth: 90,
  },
  { id: "demand_3tdp", group: "demand", label: "Next 3 TDP", minWidth: 90 },
  {
    id: "demand_6m",
    group: "demand",
    label: "Next 6 Months",
    minWidth: 90,
  },
  {
    id: "demand_12m",
    group: "demand",
    label: "Next 12 Months",
    minWidth: 100,
  },
  { id: "total_fg", group: "summary", label: "Total FG", minWidth: 100 },
  { id: "total_fg_min", group: "summaryMin", label: "Total FG", minWidth: 100 },
  { id: "cover_fg", group: "cover", label: "FG Cover", minWidth: 130 },
  {
    id: "cover_total",
    group: "cover",
    label: "Total FG Cover",
    minWidth: 130,
  },
  {
    id: "cover_excl",
    group: "cover",
    label: "Excl. Open PO",
    minWidth: 130,
  },
  { id: "cover_fg_min", group: "coverMin", label: "FG Cover", minWidth: 130 },
  {
    id: "cover_total_min",
    group: "coverMin",
    label: "Total FG Cover",
    minWidth: 130,
  },
  {
    id: "cover_excl_min",
    group: "coverMin",
    label: "Excl. Open PO",
    minWidth: 130,
  },
];

/**
 * Columns hidden on first load — all columns are shown by default except the
 * In-Transit / Supplier Inventory columns in the FG Equivalent RMPM Stock
 * (Min/Max) sections, and the Product Info columns beyond CBU / CBU
 * Description, all of which are opt-in via the column customizer.
 */
export const DEFAULT_HIDDEN_COLS = new Set([
  "rmpm_intransit",
  "rmpm_supplier",
  "rmpmMin_intransit",
  "rmpmMin_supplier",
  "basePack",
  "basePackDescription",
  "smallC",
  "bg",
  "format",
]);

export const DEFAULT_GROUP_ORDER: ColumnGroup[] = [
  "meta",
  "demand",
  "fg",
  "rmpmMin",
  "summaryMin",
  "coverMin",
  "rmpm",
  "summary",
  "cover",
];

// ─── Theme colours ────────────────────────────────────────────────────────────
// Group header backgrounds. Every value sits on the exact same hue as meta's
// navy (the frozen Sr No / Product Info columns, left untouched) — this is
// one blue theme, not a rainbow of group colours. Differentiation instead
// comes from alternating clearly-stepped lightness (each neighbour in the
// header row differs by 9-17 points of lightness, well past what the eye
// glosses over) rather than a smooth ramp, which is what let rmpm/rmpmMin,
// summary/summaryMin and cover/coverMin render as literally the same colour
// before. Within each Min/Max pair the Max (solid, deeper) always sits ~14
// points darker than its own Min (softer) — one rule, valid for all three
// pairs, on top of the "(Min)"/"(Max)" text already in G_LABEL.
export const G: Record<ColumnGroup, { hdr: string; sub: string }> = {
  meta: { hdr: "#003087", sub: "#e8edf6" },
  fg: { hdr: "#0E44AA", sub: "#0a3880" },
  rmpmMin: { hdr: "#2761CE", sub: "#0e3c8c" },
  rmpm: { hdr: "#0741AB", sub: "#0e3c8c" },
  demand: { hdr: "#2C65CE", sub: "#12428f" },
  summaryMin: { hdr: "#1348AA", sub: "#15469f" },
  summary: { hdr: "#00328F", sub: "#15469f" },
  coverMin: { hdr: "#225BC3", sub: "#184db3" },
  cover: { hdr: "#0A3E9E", sub: "#184db3" },
};

export const G_LABEL: Record<ColumnGroup, string> = {
  meta: "Product Info",
  fg: "FG Stock Across All Locations",
  rmpmMin: "FG Equivalent RMPM Stock (Min)",
  rmpm: "FG Equivalent RMPM Stock (Max)",
  demand: "Demand",
  summaryMin: "FG Summary (Min)",
  summary: "FG Summary (Max)",
  coverMin: "FG Cover (Min)",
  cover: "FG Cover (Max)",
};

export const COVER_COL_TOOLTIPS: Record<string, string> = {
  cover_fg:
    "Days of forward demand covered by on-hand FG stock alone (excludes RM/PM and Open PO).",
  // Formula: FG stock ÷ (Next 12-month demand ÷ 365).
  cover_total:
    "Days of forward demand covered by on-hand FG stock and the FG-equivalent of all available RM/PM (unrestricted stock, stock in quality, and Open PO), summed across a CBU's selected components; the API's own Max aggregate until a specific selection is applied.",
  // Formula: (FG stock + RM/PM total FG-equivalent) ÷ (Next 12-month demand ÷ 365).
  cover_excl:
    "Days of forward demand covered by on-hand FG stock and the FG-equivalent of RM/PM (unrestricted stock and stock in quality) - excludes Open PO, summed across a CBU's selected components; the API's own Max aggregate until a specific selection is applied.",
  // Formula: (FG stock + RM/PM unrestricted + quality FG-equivalent) ÷ (Next 12-month demand ÷ 365).
  cover_fg_min:
    "Days of forward demand covered by on-hand FG stock alone (excludes RM/PM and Open PO).",
  cover_total_min:
    "Days of forward demand covered by on-hand FG stock and the FG-equivalent of all available RM/PM (unrestricted stock, stock in quality, and Open PO), summed across a CBU's selected components; the API's own Min aggregate until a specific selection is applied.",
  // Formula: (FG stock + RM/PM total FG-equivalent) ÷ (Next 12-month demand ÷ 365).
  cover_excl_min:
    "Days of forward demand covered by on-hand FG stock and the FG-equivalent of RM/PM (unrestricted stock and stock in quality) - excludes Open PO, summed across a CBU's selected components; the API's own Min aggregate until a specific selection is applied.",
  // Formula: (FG stock + RM/PM unrestricted + quality FG-equivalent) ÷ (Next 12-month demand ÷ 365).
};

// ─── Frozen column widths ─────────────────────────────────────────────────────
export const W_SR = 46;

export const COLUMN_CUSTOMIZER_LABELS = {
  toggleButton: "Customise",
  panelTitle: "Customise Table",
  reset: "Reset",
  hintText: "DRAG SECTIONS OR COLUMNS · TOGGLE TO SHOW/HIDE",
  done: "Done",
  showSection: "Show section",
  hideSection: "Hide section",
  showColumn: "Show column",
  hideColumn: "Hide column",
  requiredColumn: "Always visible — required to identify the row",
};

// ─── Table hints bar (TableHintsBar.tsx) ───────────────────────────────────────

export const QUICK_TIPS_LABEL = "Quick tips";

export const TABLE_HINTS = [
  {
    target: "CBU Code",
    action: "Expand RM/PM components",
  },
  {
    target: "CBU Description",
    action: "Open CBU Detail",
  },
  {
    iconBg: "#e0f2f1",
    iconColor: "#00695C",
    target: "Flask icon",
    action: "Open Scenario Simulation",
  },
  {
    iconBg: "#dbeafe",
    iconColor: "#1565C0",
    target: "DC Stock",
    action: "View DC-level stock breakdown",
  },
  {
    iconBg: "#ffedd5",
    iconColor: "#ea580c",
    target: "Demand value",
    action: "View month breakdown",
  },
];

// ─── Pagination (TablePagination.tsx) ──────────────────────────────────────────

export const ROWS_PER_PAGE_LABEL = "Rows per page:";
export const PREV_PAGE_ARIA_LABEL = "Previous page";
export const NEXT_PAGE_ARIA_LABEL = "Next page";

// ─── Dashboard table (DashboardTable.tsx) ──────────────────────────────────────

export const SR_NO_LABEL = "Sr No";

const COMPONENT_TYPE_LABELS: Record<"RM" | "PM", string> = {
  RM: "1001 (RM)",
  PM: "1002 (PM)",
};

export const noComponentDataMessage = (typeFilter: "ALL" | "RM" | "PM") =>
  `No component data for ${
    typeFilter === "ALL" ? "this CBU" : `type ${COMPONENT_TYPE_LABELS[typeFilter]}`
  }`;

export const UNIQUE_COMPONENTS_LABEL = "Unique Components";
export const FILTERED_BADGE_LABEL = "filtered";
export const HIGH_CONTRIBUTING_GROUP_LABEL = "High Contributing Components (≥70%)";
export const HIGH_CONTRIBUTING_EMPTY_MESSAGE =
  "No high-contributing components for this CBU";

// ─── Cell renderers (cellRenderers.tsx) ────────────────────────────────────────

export const CELL_TOOLTIPS = {
  viewCbuDetail: "View CBU Detail",
  openScenarioSimulation: "Open Scenario Simulation",
  noDcStock: "No DC stock currently recorded.",
  viewDcBreakdown: "Click to view the DC-level stock breakdown",
  noFactoryStock: "No factory stock currently recorded.",
  viewFactoryBreakdown: "Click to view the factory-level stock breakdown",
  noTransitStock: "No stock currently in transit.",
  viewTransitBreakdown: "Click to view the full in-transit stock breakdown",
  noDemand: "No demand data available.",
};

export const EMPTY_CELL_PLACEHOLDER = "—";

// ─── Display-value formatting (utils.ts) ───────────────────────────────────────

export const SMALL_C_DISPLAY_LABELS: Record<string, string> = {
  "Skin Care": "SKIN",
  "Hair Care": "HAIR",
  "Oral Care": "ORAL",
};

export const BG_DISPLAY_LABELS: Record<string, string> = {
  HPC: "B&W",
};

export const FORMAT_DISPLAY_LABELS = {
  small: "SKIN BOTTLES (SMALL)",
  medium: "SKIN BOTTLES (MED)",
  large: "SKIN BOTTLES (LARGE)",
};

export const NO_STOCK_MESSAGE = "No stock currently recorded.";
