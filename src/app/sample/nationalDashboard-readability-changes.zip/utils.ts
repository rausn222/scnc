import {
  getRowFilterAttributes,
  getRowBasePackCode,
  getRowBasePackDescription,
  getAggregatedComponents,
  getComponentDescription,
  getRowFgMaterial,
  PLANT_CLUSTER_MAP,
  TODAY,
  type CBURow,
  type CBURowCover,
  type AggregatedComponent,
  type CBURowFilterAttributes,
} from "../data";
import {
  ALL_COLS,
  W_SR,
  FORMAT_DISPLAY_LABELS,
  NO_STOCK_MESSAGE,
} from "../../constants/nationalDashboard";
import type {
  ColDef,
  ColumnGroup,
  CoverResult,
  EffRmpm,
  SortDir,
  TypeFilter,
} from "./types";

// ─── Column ordering / visibility ─────────────────────────────────────────────

export function buildDefaultColOrderByGroup(): Record<ColumnGroup, string[]> {
  const result = {} as Record<ColumnGroup, string[]>;
  for (const group of [
    "meta",
    "fg",
    "rmpmMin",
    "rmpm",
    "demand",
    "summaryMin",
    "summary",
    "coverMin",
    "cover",
  ] as ColumnGroup[]) {
    result[group] = ALL_COLS.filter((c) => c.group === group).map(
      (c) => c.id,
    );
  }
  return result;
}

// Required columns (see ColDef.required) identify the row itself — for
// expanded CBUs their cells double up as the component sub-rows' only
// code/description display — so they stay visible no matter what the column
// customizer's group/column hide state says.
export function isColVisible(col: ColDef | undefined, groupHidden: boolean, hiddenCols: Set<string>): col is ColDef {
  if (!col) return false;
  if (col.required) return true;
  return !groupHidden && !hiddenCols.has(col.id);
}

export function buildOrderedCols(
  groupOrder: ColumnGroup[],
  colOrderByGroup: Record<ColumnGroup, string[]>,
  hiddenGroups: Set<ColumnGroup>,
  hiddenCols: Set<string>,
): ColDef[] {
  return groupOrder.flatMap((g) =>
    colOrderByGroup[g]
      .map((id) => ALL_COLS.find((c) => c.id === id))
      .filter((col) => isColVisible(col, hiddenGroups.has(g), hiddenCols)),
  );
}

export function countVisibleColumns(
  groupOrder: ColumnGroup[],
  colOrderByGroup: Record<ColumnGroup, string[]>,
  hiddenGroups: Set<ColumnGroup>,
  hiddenCols: Set<string>,
): number {
  return groupOrder.reduce((sum, g) => {
    const groupHidden = hiddenGroups.has(g);
    return (
      sum +
      colOrderByGroup[g].filter((id) =>
        isColVisible(ALL_COLS.find((c) => c.id === id), groupHidden, hiddenCols),
      ).length
    );
  }, 0);
}

export function computeGroupRuns(cols: ColDef[]) {
  const runs: Array<{ group: ColumnGroup; count: number }> = [];
  for (const col of cols) {
    const last = runs.at(-1);
    if (last?.group === col.group) last.count++;
    else runs.push({ group: col.group, count: 1 });
  }
  return runs;
}

/** Ids of the columns that lead off a new column group (e.g. the first RM/PM
 * Stock column, the first Demand column) — everywhere but the very first
 * group, which sits right against the meta columns and needs no extra
 * divider. Mirrors the thin-vs-bold split the group header row already
 * applies to its own borderLeftWidth (see DashboardTable's `groupRuns.map`),
 * so the bold divider lines up with the group header boundary directly
 * above it. */
export function computeGroupBoundaryColIds(
  cols: ColDef[],
  groupRuns: Array<{ group: ColumnGroup; count: number }>,
): Set<string> {
  const ids = new Set<string>();
  let offset = 0;
  groupRuns.forEach((run, i) => {
    if (i > 0 && cols[offset]) ids.add(cols[offset].id);
    offset += run.count;
  });
  return ids;
}

export function metaColsWidth(cols: ColDef[]): number {
  return cols.reduce((sum, col) => sum + col.minWidth, 0);
}

export function metaColLeft(cols: ColDef[], index: number): number {
  return W_SR + cols.slice(0, index).reduce((sum, col) => sum + col.minWidth, 0);
}

// ─── Display formatting ────────────────────────────────────────────────────────

export function mapSmallCDisplay(smallC: string): string {
  return smallC.toUpperCase() ?? "";
}

export function mapBgDisplay(bg: string): string {
  return bg.toUpperCase() ?? "";
}

export function inferFormatDisplay(description: string): string {
  const mlMatch = /(\d+)\s*ML/i.exec(description);
  const ml = mlMatch ? Number.parseInt(mlMatch[1], 10) : 200;
  if (ml <= 100) return FORMAT_DISPLAY_LABELS.small;
  if (ml <= 300) return FORMAT_DISPLAY_LABELS.medium;
  return FORMAT_DISPLAY_LABELS.large;
}

export function formatBasePackOption(row: CBURow): string {
  return `${getRowBasePackCode(row)}: ${getRowBasePackDescription(row)}`;
}

export function formatCbuOption(row: CBURow): string {
  return `${row.cbuCode}: ${row.cbuDescription}`;
}

export function componentScopeLabel(typeFilter: TypeFilter): string {
  if (typeFilter === "ALL") return "(all locations)";
  if (typeFilter === "RM") return "(RM)";
  return "(PM)";
}

export function formatMaterialOptions(row: CBURow): string[] {
  const fgMaterial = getRowFgMaterial(row);
  return getAggregatedComponents(row.cbuCode, fgMaterial).map(
    (c) => `${c.componentCode}: ${getComponentDescription(c)}`,
  );
}

/** Lowercased haystack of every filterable field/value for a row, for the free-text search box. */
export function buildRowSearchText(
  row: CBURow,
  attrs: CBURowFilterAttributes,
): string {
  return [
    formatCbuOption(row),
    formatBasePackOption(row),
    ...formatMaterialOptions(row),
    attrs.bg,
    attrs.smallC,
    attrs.format,
    attrs.brand,
  ]
    .join(" ")
    .toLowerCase();
}

export function getMetaColumnValue(row: CBURow, colId: string): string {
  const attrs = getRowFilterAttributes(row);
  const basePackDescription = getRowBasePackDescription(row);
  switch (colId) {
    case "cbuCode":
      return row.cbuCode;
    case "cbuDescription":
      return row.cbuDescription;
    case "basePack":
      return getRowBasePackCode(row);
    case "basePackDescription":
      return basePackDescription;
    case "smallC":
      return mapSmallCDisplay(attrs.smallC);
    case "bg":
      return mapBgDisplay(attrs.bg);
    case "format":
      return attrs.format;
    default:
      return "";
  }
}

// ─── FG stock location bifurcation ────────────────────────────────────────────
// No per-route In-Transit data exists in the mock dataset, so each row's
// In-Transit total is deterministically split across the app's real plant
// codes and regions (seeded by srNo, so it's stable across re-renders).
// DC Stock and Factory Stock have real per-location breakdown data instead —
// see DC_STOCK_BREAKDOWN / FACTORY_STOCK_BREAKDOWN in data.ts, surfaced via a
// click-through popup rather than a tooltip.
const ALL_PLANT_CODES = Object.keys(PLANT_CLUSTER_MAP);
const TRANSIT_DESTINATIONS = ["PATH", "NCRH", "HRIH"];

export function pickSeeded<T>(items: T[], count: number, seed: number): T[] {
  const n = Math.min(count, items.length);
  const start = ((seed % items.length) + items.length) % items.length;
  return Array.from({ length: n }, (_, i) => items[(start + i) % items.length]);
}

export function splitBySeed(
  total: number,
  labels: string[],
  seed: number,
): Array<{ label: string; value: number }> {
  if (total <= 0 || labels.length === 0) {
    return labels.map((label) => ({ label, value: 0 }));
  }
  let s = seed || 1;
  const weights = labels.map(() => {
    s = (s * 9301 + 49297) % 233280;
    return 0.4 + s / 233280;
  });
  const weightSum = weights.reduce((a, b) => a + b, 0);
  const raw = weights.map((w) => Math.round((total * w) / weightSum));
  const diff = total - raw.reduce((a, b) => a + b, 0);
  raw[raw.length - 1] += diff;
  return labels.map((label, i) => ({ label, value: raw[i] }));
}

export function blockedStockTooltip(
  dcBlockedStock: number | null | undefined,
  factoryBlockedStock: number | null | undefined,
): string | undefined {
  if (dcBlockedStock == null && factoryBlockedStock == null) return undefined;
  return (
    `DC Blocked Stock: ${(dcBlockedStock ?? 0).toLocaleString("en-IN")}\n` +
    `Factory Blocked Stock: ${(factoryBlockedStock ?? 0).toLocaleString("en-IN")}`
  );
}

export function transitTooltip(total: number, seed: number): string {
  if (total <= 0) return NO_STOCK_MESSAGE;
  const plants = pickSeeded(ALL_PLANT_CODES, 2, seed + 2);
  const routeLabels = plants.map(
    (p, i) => `${p} → ${TRANSIT_DESTINATIONS[(seed + i * 7) % TRANSIT_DESTINATIONS.length]}`,
  );
  const parts = splitBySeed(total, routeLabels, seed + 2);
  return (
    "In-Transit by route:\n" +
    parts.map((p) => `${p.label}: ${p.value.toLocaleString("en-IN")}`).join("\n")
  );
}

// ─── Cover / sort helpers ──────────────────────────────────────────────────────

export function calcCover(stock: number, demand12M: number): CoverResult {
  // No forward demand at all — stock alone can't be "covered" against
  // anything, so there's no cover date to compute either way.
  if (demand12M <= 0) {
    // Stock without demand: flag it as excess rather than a blank N/A.
    if (stock > 0) return { days: null, date: "Excess Stock" };
    // Neither stock nor demand exists for this row — nothing to report.
    return { days: null, date: "-" };
  }
  const days = Math.round(stock / (demand12M / 365));
  // Business rule: stock alone already exceeds a full 12 months of demand —
  // report ">12 Months" rather than a speculative stock-out date. This also
  // keeps `days` far short of the point where `new Date(...)` would go out
  // of range and start returning NaN from getDate()/getMonth()/getFullYear()
  // (real CBUs with near-zero demand could otherwise compute stock-out
  // dates billions of days out).
  if (stock > demand12M) return { days, date: ">12 Months" };
  const dt = new Date(TODAY.getTime() + days * 86_400_000);
  return {
    days,
    date: `${String(dt.getDate()).padStart(2, "0")}-${String(dt.getMonth() + 1).padStart(2, "0")}-${dt.getFullYear()}`,
  };
}

export function parseCoverDate(s: string): number {
  if (!s || s === "N/A" || s === "-" || s === "—") return Number.NEGATIVE_INFINITY;
  if (s === "Excess" || s === "Excess Stock" || s === ">12 Months")
    return Number.POSITIVE_INFINITY;
  const ddmmyyyy = /^(\d{2})-(\d{2})-(\d{4})$/.exec(s);
  if (ddmmyyyy) {
    return new Date(
      Number(ddmmyyyy[3]),
      Number(ddmmyyyy[2]) - 1,
      Number(ddmmyyyy[1]),
    ).getTime();
  }
  const yyyymm = /^(\d{4})-(\d{2})$/.exec(s);
  if (yyyymm) {
    return new Date(Number(yyyymm[1]), Number(yyyymm[2]) - 1, 1).getTime();
  }
  return 0;
}

/** Converts an already-normalized cover-date string (see normalizeCoverDate
 * in ../data — "DD-MM-YYYY", "Excess Stock", ">12 Months", or "N/A") into
 * the {days, date} shape fmtDateDaysThemed/parseCoverDate expect, computing
 * `days` against TODAY for a real date. */
export function coverResultFromDate(dateStr: string): CoverResult {
  if (!dateStr || dateStr === "N/A") return { days: null, date: "-" };
  if (dateStr === "Excess Stock") return { days: null, date: "Excess Stock" };
  if (dateStr === ">12 Months") return { days: null, date: ">12 Months" };
  const ddmmyyyy = /^(\d{2})-(\d{2})-(\d{4})$/.exec(dateStr);
  if (ddmmyyyy) {
    const dt = new Date(
      Number(ddmmyyyy[3]),
      Number(ddmmyyyy[2]) - 1,
      Number(ddmmyyyy[1]),
    );
    const days = Math.round((dt.getTime() - TODAY.getTime()) / 86_400_000);
    return { days, date: dateStr };
  }
  return { days: null, date: dateStr };
}

export interface RowCoverResults {
  fgCov: CoverResult;
  totCovMax: CoverResult;
  totCovMin: CoverResult;
  exclCovMax: CoverResult;
  exclCovMin: CoverResult;
  totalFGMax: number;
  totalFGMin: number;
}

/** True once the user has actually narrowed the row's component pool away
 * from "everything, unfiltered" — an RM/PM type filter, the High
 * Contributing toggle (a separately-sourced population), or deselecting at
 * least one component. Used by getRowCoverResults to decide whether
 * totCov/exclCov may legitimately diverge from the API's precomputed cover
 * dates (a real filter is in effect) or must still match them (nothing the
 * user did should have changed the population the cover dates describe).
 * Checks only that every currently-known component is present in `selected`
 * — not selected.size, which can overcount and false-positive here: a
 * component the user never touched can linger in `selected` after it drops
 * out of the current population (e.g. a High Contributing code added while
 * the toggle was on, left behind once it's switched off again — see the
 * effect in NationalDashboard.tsx that only ever adds newly-seen codes). */
export function isCustomComponentSelection(
  components: AggregatedComponent[],
  showHighContributing: boolean,
  selected: Set<string>,
  typeFilter: TypeFilter,
): boolean {
  if (typeFilter !== "ALL" || showHighContributing) return true;
  return !components.every((c) => selected.has(c.componentCode));
}

/**
 * FG Cover Min/Max for a row. When no per-component breakdown is loaded for
 * the row (the common case — see fetchComponentBreakdowns in api/cbuApi.ts),
 * or when components are loaded but the user hasn't actually filtered
 * anything (hasCustomFilter false — see isCustomComponentSelection), this
 * reads the real CBU Listing API's own precomputed coverMin/coverMax
 * (row.coverMin/row.coverMax) rather than reimplementing the backend's
 * cover-date business logic (Excess stock / > demand horizon handling)
 * client-side — merely expanding a row to view its components shouldn't
 * change the cover dates shown while collapsed. Once the user actually
 * applies an RM/PM filter, toggles High Contributing, or deselects a
 * component, the static API figures can't reflect that, so totCov/exclCov
 * (which fold in the selected RM/PM components) are recomputed client-side
 * from effMax/effMin instead. fgCov is FG stock alone — it excludes RM/PM
 * entirely, so it never depends on component selection and always comes
 * from the API's precomputed date regardless of filter state.
 */
export function getRowCoverResults(
  row: CBURow,
  effMax: EffRmpm,
  effMin: EffRmpm,
  hasLoadedComponents: boolean,
  hasCustomFilter: boolean,
): RowCoverResults {
  const totalFGMax = row.fg.totalStock + effMax.totalStock;
  const totalFGMin = row.fg.totalStock + effMin.totalStock;
  const coverMaxApi: CBURowCover = row.coverMax ?? row.cover;
  const fgCov = coverResultFromDate(coverMaxApi.fgCoverDate);

  if (!hasLoadedComponents || !hasCustomFilter) {
    const coverMinApi: CBURowCover = row.coverMin ?? row.cover;
    return {
      fgCov,
      totCovMax: coverResultFromDate(coverMaxApi.totalCoverDate),
      totCovMin: coverResultFromDate(coverMinApi.totalCoverDate),
      exclCovMax: coverResultFromDate(coverMaxApi.coverExclOpenPO),
      exclCovMin: coverResultFromDate(coverMinApi.coverExclOpenPO),
      totalFGMax,
      totalFGMin,
    };
  }

  return {
    fgCov,
    totCovMax: calcCover(totalFGMax, row.demand.next12Months),
    totCovMin: calcCover(totalFGMin, row.demand.next12Months),
    exclCovMax: calcCover(
      row.fg.totalStock + effMax.physicalStock + effMax.qualityStock,
      row.demand.next12Months,
    ),
    exclCovMin: calcCover(
      row.fg.totalStock + effMin.physicalStock + effMin.qualityStock,
      row.demand.next12Months,
    ),
    totalFGMax,
    totalFGMin,
  };
}

/** The CBU-level RM/PM figure is the sum of every selected component's own
 * stock — e.g. a CBU's physical stock is the total of its selected
 * components' physical stock. Once the user has picked exactly which
 * components count, there's a single unambiguous total rather than a
 * best-/worst-case bracket, so "min" and "max" mode agree here; they only
 * diverge in the no-components-loaded fallback below, which still reflects
 * the API's own distinct row-level rmpmMin/rmpmMax aggregates. High-
 * contributing components are only folded into the sum when their group is
 * actually shown, since they're a separately-sourced list (see
 * DashboardTable.tsx). */
export function computeEffRmpm(
  components: AggregatedComponent[],
  highContribComponents: AggregatedComponent[],
  showHighContributing: boolean,
  selected: Set<string>,
  typeFilter: TypeFilter,
  row: CBURow,
  mode: "min" | "max" = "max",
): EffRmpm {
  if (components.length === 0 && highContribComponents.length === 0) {
    // No per-component data loaded yet — fall back to the row-level Min/Max
    // RMPM figures (rmpmMin/rmpmMax, including stvStock, match the real
    // API's precomputed per-row aggregates 1:1; see CBURmpmStock in data.ts).
    const base = mode === "min" ? row.rmpmMin : row.rmpmMax;
    // Total Stock must be derived from this object's own Physical/Quality
    // /Open PO figures, not whatever total the underlying seed row happens
    // to carry — the two can drift (a row's static totalStock doesn't
    // always equal physicalStock+qualityStock+openPOStock for that same
    // row), which would show a Total Stock inconsistent with the other
    // columns in the same row.
    return {
      ...base,
      stvStock: base.stvStock ?? 0,
      totalStock: base.physicalStock + base.qualityStock + base.openPOStock,
    };
  }
  const matchesType = (c: AggregatedComponent) =>
    typeFilter === "ALL" ||
    (typeFilter === "RM" && c.componentMaterialType === "1001") ||
    (typeFilter === "PM" && c.componentMaterialType === "1002");
  const pool = [
    ...components,
    ...(showHighContributing ? highContribComponents : []),
  ].filter(matchesType);
  const active = pool.filter((c) => selected.has(c.componentCode));
  if (active.length === 0)
    return {
      physicalStock: 0,
      qualityStock: 0,
      stvStock: 0,
      openPOStock: 0,
      totalStock: 0,
      blockedStock: 0,
      supplierInventory: 0,
      inTransitStock: 0,
    };
  const sum = (values: number[]): number => values.reduce((a, b) => a + b, 0);
  const phy = sum(active.map((c) => c.unrestrictedStock));
  const qty = sum(active.map((c) => c.qualityStock));
  const opo = sum(active.map((c) => c.openPOStock));
  const blk = sum(active.map((c) => c.blockedStock));
  return {
    physicalStock: phy,
    qualityStock: qty,
    openPOStock: opo,
    // Sum is distributive — the total of each component's own
    // physical+quality+openPO equals phy+qty+opo above, so no separate pass
    // over active is needed to derive it.
    totalStock: phy + qty + opo,
    blockedStock: blk,
    // AggregatedComponent has no STV/supplier-inventory/in-transit
    // dimension — those only exist at the row-level API aggregate (the
    // fallback branch above), not per component.
    stvStock: 0,
    supplierInventory: 0,
    inTransitStock: 0,
  };
}

export function getEffRmpmForRow(
  row: CBURow,
  typeFilter: TypeFilter,
  componentCache: Record<number, AggregatedComponent[]>,
  selectedComponents: Record<number, Set<string>>,
  highContributingCache: Record<number, AggregatedComponent[]>,
  showHighContributing: boolean,
  mode: "min" | "max" = "max",
): EffRmpm {
  const comps = componentCache[row.srNo] ?? [];
  const highComps = highContributingCache[row.srNo] ?? [];
  const selected =
    selectedComponents[row.srNo] ??
    new Set([...comps.map((c) => c.componentCode), ...highComps.map((c) => c.componentCode)]);
  return computeEffRmpm(comps, highComps, showHighContributing, selected, typeFilter, row, mode);
}

export function getRowSortValue(
  row: CBURow,
  colId: string,
  typeFilter: TypeFilter,
  componentCache: Record<number, AggregatedComponent[]>,
  selectedComponents: Record<number, Set<string>>,
  highContributingCache: Record<number, AggregatedComponent[]>,
  showHighContributing: boolean,
): string | number {
  const eff = getEffRmpmForRow(
    row,
    typeFilter,
    componentCache,
    selectedComponents,
    highContributingCache,
    showHighContributing,
    "max",
  );
  const effMin = getEffRmpmForRow(
    row,
    typeFilter,
    componentCache,
    selectedComponents,
    highContributingCache,
    showHighContributing,
    "min",
  );
  const comps = componentCache[row.srNo] ?? [];
  const highComps = highContributingCache[row.srNo] ?? [];
  const selected =
    selectedComponents[row.srNo] ??
    new Set([...comps.map((c) => c.componentCode), ...highComps.map((c) => c.componentCode)]);
  const hasLoadedComponents = comps.length > 0 || highComps.length > 0;
  // Cover/Total FG figures use their own eff pair, separate from eff/effMin
  // above (which drive the Physical/Quality/Open PO RMPM sort values) — see
  // the matching comment in DashboardTable.tsx.
  const hasCustomFilter = isCustomComponentSelection(comps, showHighContributing, selected, typeFilter);
  const effCover = computeEffRmpm(
    hasCustomFilter ? comps : [],
    hasCustomFilter ? highComps : [],
    showHighContributing,
    selected,
    typeFilter,
    row,
    "max",
  );
  const effCoverMin = computeEffRmpm(
    hasCustomFilter ? comps : [],
    hasCustomFilter ? highComps : [],
    showHighContributing,
    selected,
    typeFilter,
    row,
    "min",
  );
  const {
    fgCov,
    totCovMax: totCov,
    totCovMin,
    exclCovMax: exclCov,
    exclCovMin,
    totalFGMax: totalFG,
    totalFGMin,
  } = getRowCoverResults(
    row,
    effCover,
    effCoverMin,
    hasLoadedComponents,
    hasCustomFilter,
  );

  const valuesByCol: Record<string, string | number> = {
    srNo: row.srNo,
    cbuCode: row.cbuCode,
    cbuDescription: row.cbuDescription.toLowerCase(),
    basePack: getRowBasePackCode(row),
    basePackDescription: getRowBasePackDescription(row).toLowerCase(),
    smallC: mapSmallCDisplay(getRowFilterAttributes(row).smallC),
    bg: mapBgDisplay(getRowFilterAttributes(row).bg),
    format: getRowFilterAttributes(row).format,
    fg_dc: row.fg.dcStock,
    fg_intransit: row.fg.inTransitStock,
    fg_factory: row.fg.factoryStock,
    fg_total: row.fg.totalStock,
    fg_blocked: row.fg.blockedStock ?? 0,
    rmpm_physical: eff.physicalStock,
    rmpm_quality: eff.qualityStock,
    rmpm_stv: eff.stvStock,
    rmpm_openpo: eff.openPOStock,
    rmpm_intransit: eff.inTransitStock,
    rmpm_supplier: eff.supplierInventory,
    rmpm_total: eff.totalStock,
    rmpm_blocked: eff.blockedStock,
    rmpmMin_physical: effMin.physicalStock,
    rmpmMin_quality: effMin.qualityStock,
    rmpmMin_stv: effMin.stvStock,
    rmpmMin_openpo: effMin.openPOStock,
    rmpmMin_intransit: effMin.inTransitStock,
    rmpmMin_supplier: effMin.supplierInventory,
    rmpmMin_total: effMin.totalStock,
    rmpmMin_blocked: effMin.blockedStock,
    demand_3tdp: row.demand.sumNext3TDP,
    demand_6m: row.demand.next6Months,
    demand_12m: row.demand.next12Months,
    total_fg: totalFG,
    total_fg_min: totalFGMin,
    cover_fg: parseCoverDate(fgCov.date),
    cover_fg_min: parseCoverDate(fgCov.date),
    cover_total: parseCoverDate(totCov.date),
    cover_excl: parseCoverDate(exclCov.date),
    cover_total_min: parseCoverDate(totCovMin.date),
    cover_excl_min: parseCoverDate(exclCovMin.date),
  };

  return valuesByCol[colId] ?? 0;
}

export function compareSortValues(
  a: string | number,
  b: string | number,
  dir: SortDir,
): number {
  const mult = dir === "asc" ? 1 : -1;
  if (typeof a === "number" && typeof b === "number") {
    return (a - b) * mult;
  }
  return String(a).localeCompare(String(b), undefined, { numeric: true }) * mult;
}

export function getVisiblePages(
  page: number,
  totalPages: number,
): Array<number | "ellipsis"> {
  if (totalPages <= 1) return [1];
  if (totalPages <= 7) {
    return Array.from({ length: totalPages }, (_, i) => i + 1);
  }
  const pages: Array<number | "ellipsis"> = [1];
  if (page > 3) pages.push("ellipsis");
  const start = Math.max(2, page - 1);
  const end = Math.min(totalPages - 1, page + 1);
  for (let i = start; i <= end; i++) pages.push(i);
  if (page < totalPages - 2) pages.push("ellipsis");
  pages.push(totalPages);
  const deduped: Array<number | "ellipsis"> = [];
  for (const p of pages) {
    const prev = deduped.at(-1);
    if (p === "ellipsis" && prev === "ellipsis") continue;
    if (typeof p === "number" && p === prev) continue;
    deduped.push(p);
  }
  return deduped;
}

// ─── Cell theming / sticky-column styles ──────────────────────────────────────

export function getColTheme(colId: string): { bg: string; text: string } {
  if (
    [
      "cbuCode",
      "cbuDescription",
      "basePack",
      "basePackDescription",
      "smallC",
      "bg",
      "format",
    ].includes(colId)
  ) {
    return { bg: "#e8edf6", text: "#003087" };
  }
  if (["fg_dc", "fg_factory", "fg_intransit", "fg_total", "fg_blocked"].includes(colId)) {
    return { bg: "#dbeafe", text: "#1565C0" };
  }
  if (
    [
      "rmpm_physical",
      "rmpm_quality",
      "rmpm_stv",
      "rmpm_openpo",
      "rmpm_intransit",
      "rmpm_supplier",
      "rmpm_total",
      "rmpm_blocked",
      "rmpmMin_physical",
      "rmpmMin_quality",
      "rmpmMin_stv",
      "rmpmMin_openpo",
      "rmpmMin_intransit",
      "rmpmMin_supplier",
      "rmpmMin_total",
      "rmpmMin_blocked",
    ].includes(colId)
  ) {
    return { bg: "#ecfdf5", text: "#00695C" };
  }
  if (["demand_3tdp", "demand_6m", "demand_12m"].includes(colId)) {
    return { bg: "#daeefb", text: "#0277BD" };
  }
  // FG Summary gets its own distinct blue, separate from FG Cover's navy —
  // see the G[...] group-header colours in constants/nationalDashboard.ts.
  if (["total_fg", "total_fg_min"].includes(colId)) {
    return { bg: "#e0f2fe", text: "#075985" };
  }
  if (
    [
      "cover_fg",
      "cover_total",
      "cover_excl",
      "cover_fg_min",
      "cover_total_min",
      "cover_excl_min",
    ].includes(
      colId,
    )
  ) {
    return { bg: "#EDF1F7", text: "#003087" };
  }
  return { bg: "#EDF5FA", text: "#374151" };
}

export const GROUP_BOUNDARY_BORDER_COLOR = "#9ca3af";
// Header cells sit on the group's own solid/pastel background (see G / subHdrStyle
// below) rather than the body's near-white row background, so their group-boundary
// divider stays a light white line — matching the group header row's own divider —
// instead of the blue used to mark boundaries in the body.
export const GROUP_BOUNDARY_HEADER_BORDER_COLOR = "#ffffff";

// Body cell figures share one neutral, high-contrast color instead of a
// different saturated hue per column group (see getColTheme) — the header/
// sub-header above each column already signals which group a figure
// belongs to, so coloring the digits themselves the same way only added
// competing noise without conveying anything new.
export const BODY_VALUE_TEXT_COLOR = "#1E293B";

// Row hover / expanded-row background — a soft tint of the same blue family
// as the header palette (see G in constants/nationalDashboard.ts) instead of
// the previous mint/teal (#EDF5F4), which read as an off-theme color next to
// an otherwise all-blue table.
export const ROW_HOVER_BG = "#E7EDF9";

export function cellBaseStyle(
  colId: string,
  isGroupBoundary = false,
): React.CSSProperties {
  return {
    color: BODY_VALUE_TEXT_COLOR,
    border: "1px solid #9ca3af",
    ...(isGroupBoundary
      ? { borderLeftWidth: 2, borderLeftColor: GROUP_BOUNDARY_BORDER_COLOR }
      : {}),
  };
}

// getColTheme's RM/PM entry is green — historically the body's material-
// stock data-type colour, back when the body coloured figures per column
// group. The body now renders every figure in one neutral color (see
// BODY_VALUE_TEXT_COLOR), so getColTheme only still drives the sub-header
// row below; RM/PM's green would clash with the blue theme every other
// group's sub-header uses, so this row overrides just those column ids.
const RMPM_HEADER_COL_IDS = new Set([
  "rmpm_physical", "rmpm_quality", "rmpm_stv", "rmpm_openpo", "rmpm_intransit",
  "rmpm_supplier", "rmpm_total", "rmpm_blocked",
  "rmpmMin_physical", "rmpmMin_quality", "rmpmMin_stv", "rmpmMin_openpo",
  "rmpmMin_intransit", "rmpmMin_supplier", "rmpmMin_total", "rmpmMin_blocked",
]);
const RMPM_HEADER_THEME = { bg: "#d6e8fb", text: "#134EB4" };

// Returns header cell colours aligned per column group (blue theme). The
// body no longer shares this colour coding — see BODY_VALUE_TEXT_COLOR.
export function subHdrStyle(colId: string): React.CSSProperties {
  const theme = RMPM_HEADER_COL_IDS.has(colId) ? RMPM_HEADER_THEME : getColTheme(colId);
  return { backgroundColor: theme.bg, color: theme.text };
}

export function stickyHead(left: number, minWidth: number): React.CSSProperties {
  return {
    position: "sticky",
    left,
    zIndex: 30,
    minWidth,
    maxWidth: minWidth,
  };
}

export function stickyBody(
  left: number,
  minWidth: number,
  bg: string,
): React.CSSProperties {
  return {
    position: "sticky",
    left,
    zIndex: 5,
    minWidth,
    maxWidth: minWidth,
    backgroundColor: bg,
  };
}
