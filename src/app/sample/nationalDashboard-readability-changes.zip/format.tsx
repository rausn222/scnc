import type { CoverResult } from "./types";

// "—" / "N/A" placeholders previously rendered at #d1d5db, which measures
// ~1.4:1 contrast against the table's white/mint row backgrounds — well
// below WCAG AA's 4.5:1 minimum, effectively invisible rather than merely
// de-emphasized. This tone stays visually muted next to real values while
// clearing contrast everywhere it's used.
const MUTED_TEXT_COLOR = "#5B6472";

export function fmtNWithTheme(
  n: number | null | undefined,
  textColor: string,
): React.ReactNode {
  // The real API returns null for some numeric fields (no data for that
  // CBU/location) rather than 0 — treat it the same as 0 here.
  if (n == null || n === 0) return <span style={{ color: MUTED_TEXT_COLOR }}>—</span>;
  // The API returns values already converted to whichever uom was
  // requested (EA or MT) — render the figure as-is, with no client-side
  // decimal reformatting for either uom.
  return <span style={{ color: textColor }}>{n.toLocaleString()}</span>;
}

export function fmtDateThemed(
  s: string,
  textColor: string,
): React.ReactNode {
  if (!s || s === "N/A")
    return (
      <span style={{ color: MUTED_TEXT_COLOR, fontStyle: "italic", fontSize: 11 }}>
        N/A
      </span>
    );
  return <span style={{ color: textColor }}>{s}</span>;
}

/** e.g. "25-08-2026 (28d)" — the cover date alongside the day count from today. */
export function fmtDateDaysThemed(
  cover: CoverResult,
  textColor: string,
): React.ReactNode {
  // Neither stock nor demand exists for this row — nothing to report.
  if (cover.date === "-")
    return (
      <span style={{ color: MUTED_TEXT_COLOR, fontStyle: "italic", fontSize: 11 }}>
        N/A
      </span>
    );
  // Stock exists but there's no forward demand to cover — flag as excess
  // rather than implying a stock-out date could be computed.
  if (cover.date === "Excess Stock")
    return (
      <span
        style={{ color: textColor, fontWeight: 700 }}
        title="Stock available with no forward demand"
      >
        Excess Stock
      </span>
    );
  // Stock so far in excess of demand that an exact stock-out date isn't
  // meaningful (calcCover caps this before it can compute an out-of-range,
  // NaN-yielding Date) — the day count itself (often in the billions) isn't
  // useful to show either, so just say the cover exceeds the 12-month
  // demand horizon.
  if (cover.date === ">12 Months")
    return (
      <span
        style={{ color: textColor, fontWeight: 700 }}
        title="Stock covers more than 12 months of demand"
      >
        &gt; Demand Horizon
      </span>
    );
  if (cover.days === null)
    return (
      <span style={{ color: MUTED_TEXT_COLOR, fontStyle: "italic", fontSize: 11 }}>
        N/A
      </span>
    );
  return (
    <span style={{ color: textColor }} title="Stock-out date (days of cover left from today)">
      {cover.date} <span style={{ fontWeight: 700 }}>({cover.days}d)</span>
    </span>
  );
}
