import { render, screen, fireEvent } from "@testing-library/react";
import { DashboardTable } from "../DashboardTable";
import { computeGroupRuns } from "../utils";
import { ALL_COLS } from "../../../constants/nationalDashboard";
import type { CBURow, AggregatedComponent } from "../../data";

function makeRow(overrides: Partial<CBURow> = {}): CBURow {
  return {
    srNo: 1,
    cbuCode: "TESTCODE",
    cbuDescription: "Test CBU 200ML",
    weightKg: 0.2,
    fg: { dcStock: 100, factoryStock: 50, inTransitStock: 20, totalStock: 170 },
    rmpm: {
      physicalStock: 40,
      qualityStock: 10,
      openPOStock: 5,
      totalStock: 55,
      blockedStock: 0,
      supplierInventory: 0,
      inTransitStock: 0,
    },
    rmpmMin: {
      physicalStock: 40,
      qualityStock: 10,
      openPOStock: 5,
      totalStock: 55,
      blockedStock: 0,
      supplierInventory: 0,
      inTransitStock: 0,
    },
    rmpmMax: {
      physicalStock: 40,
      qualityStock: 10,
      openPOStock: 5,
      totalStock: 55,
      blockedStock: 0,
      supplierInventory: 0,
      inTransitStock: 0,
    },
    demand: { sumNext3TDP: 30, next6Months: 100, next12Months: 200 },
    totalFG: 170,
    cover: { fgCoverDate: "N/A", totalCoverDate: "N/A", coverExclOpenPO: "N/A" },
    ...overrides,
  };
}

function makeComponent(overrides: Partial<AggregatedComponent> = {}): AggregatedComponent {
  return {
    componentCode: "C1",
    componentMaterialType: "1002",
    unrestrictedStock: 10,
    qualityStock: 2,
    blockedStock: 0,
    totalStock: 12,
    openPOStock: 3,
    ...overrides,
  };
}

const orderedMetaCols = ALL_COLS.filter((c) => c.id === "cbuCode" || c.id === "cbuDescription");
const orderedDataCols = ALL_COLS.filter((c) => c.id === "fg_total" || c.id === "demand_12m");
const groupRuns = computeGroupRuns(orderedDataCols);

function baseProps(overrides: Record<string, unknown> = {}) {
  return {
    orderedMetaCols,
    orderedDataCols,
    groupRuns,
    tableMinWidth: 800,
    stickyColCount: 1 + orderedMetaCols.length,
    sortCol: null,
    sortDir: "asc" as const,
    onSort: jest.fn(),
    page: 1,
    paginatedRows: [makeRow()],
    expandedSrNo: null,
    isExpandedComponentsLoading: false,
    isExpandedHighContributingLoading: false,
    componentCache: {},
    highContributingCache: {},
    selectedComponents: {},
    typeFilter: "ALL" as const,
    uom: "EA" as const,
    showHighContributing: false,
    recalculatedRow: null,
    isRecalculating: false,
    onCbuClick: jest.fn(),
    navigate: jest.fn(),
    onToggleComp: jest.fn(),
    onToggleAll: jest.fn(),
    onDemandClick: jest.fn(),
    onDcStockClick: jest.fn(),
    onFactoryStockClick: jest.fn(),
    onInTransitClick: jest.fn(),
    ...overrides,
  };
}

describe("DashboardTable", () => {
  it("renders the Sr No header and every ordered column's label", () => {
    render(<DashboardTable {...baseProps()} />);
    expect(screen.getByText("Sr No")).toBeInTheDocument();
    expect(screen.getByText("CBU Description")).toBeInTheDocument();
    expect(screen.getByText("Total Stock")).toBeInTheDocument();
    expect(screen.getByText("Next 12 Months")).toBeInTheDocument();
  });

  it("calls onSort with the column id when a header is clicked", () => {
    const onSort = jest.fn();
    render(<DashboardTable {...baseProps({ onSort })} />);
    fireEvent.click(screen.getByText("Sr No"));
    expect(onSort).toHaveBeenCalledWith("srNo");
  });

  it("renders a row per paginated CBU with its srNo and code", () => {
    const rows = [makeRow({ srNo: 1, cbuCode: "AAA" }), makeRow({ srNo: 2, cbuCode: "BBB" })];
    render(<DashboardTable {...baseProps({ paginatedRows: rows })} />);
    expect(screen.getByText("AAA")).toBeInTheDocument();
    expect(screen.getByText("BBB")).toBeInTheDocument();
  });

  it("calls onCbuClick with the row when the CBU code cell is clicked", () => {
    const onCbuClick = jest.fn();
    const row = makeRow({ cbuCode: "AAA" });
    render(<DashboardTable {...baseProps({ paginatedRows: [row], onCbuClick })} />);
    fireEvent.click(screen.getByText("AAA"));
    expect(onCbuClick).toHaveBeenCalledWith(row);
  });

  it("shows the empty-component message for an expanded row with no cached components", () => {
    const row = makeRow({ srNo: 1 });
    render(
      <DashboardTable
        {...baseProps({ paginatedRows: [row], expandedSrNo: 1, componentCache: {} })}
      />,
    );
    expect(screen.getByText("No component data for this CBU")).toBeInTheDocument();
  });

  it("shows a loading message instead of the empty message while the expanded row's components are still loading", () => {
    const row = makeRow({ srNo: 1 });
    render(
      <DashboardTable
        {...baseProps({
          paginatedRows: [row],
          expandedSrNo: 1,
          isExpandedComponentsLoading: true,
          componentCache: {},
        })}
      />,
    );
    expect(screen.getByText("Loading components…")).toBeInTheDocument();
    expect(screen.queryByText("No component data for this CBU")).not.toBeInTheDocument();
  });

  it("renders the unique-components group with cached components when the row is expanded", () => {
    const row = makeRow({ srNo: 1 });
    const comps = [makeComponent({ componentCode: "COMP1" })];
    render(
      <DashboardTable
        {...baseProps({
          paginatedRows: [row],
          expandedSrNo: 1,
          componentCache: { 1: comps },
          selectedComponents: { 1: new Set(["COMP1"]) },
        })}
      />,
    );
    expect(screen.getByText("COMP1")).toBeInTheDocument();
  });

  it("excludes components tagged high-contributer from the unique-components group", () => {
    const row = makeRow({ srNo: 1 });
    const comps = [
      makeComponent({ componentCode: "COMP1" }),
      makeComponent({ componentCode: "COMP2", contributionType: "high-contributer" }),
    ];
    render(
      <DashboardTable
        {...baseProps({
          paginatedRows: [row],
          expandedSrNo: 1,
          componentCache: { 1: comps },
          selectedComponents: { 1: new Set(["COMP1", "COMP2"]) },
        })}
      />,
    );
    expect(screen.getByText("COMP1")).toBeInTheDocument();
    expect(screen.queryByText("COMP2")).not.toBeInTheDocument();
  });

  it("does not render component group rows when the row isn't expanded", () => {
    const row = makeRow({ srNo: 1 });
    const comps = [makeComponent({ componentCode: "COMP1" })];
    render(
      <DashboardTable
        {...baseProps({ paginatedRows: [row], expandedSrNo: null, componentCache: { 1: comps } })}
      />,
    );
    expect(screen.queryByText("COMP1")).not.toBeInTheDocument();
  });

  it("calls onDemandClick with the row and period when a demand cell is clicked", () => {
    const onDemandClick = jest.fn();
    const row = makeRow({ demand: { sumNext3TDP: 1, next6Months: 2, next12Months: 999 } });
    render(<DashboardTable {...baseProps({ paginatedRows: [row], onDemandClick })} />);
    fireEvent.click(screen.getByText("999"));
    expect(onDemandClick).toHaveBeenCalledWith(row, "12m");
  });

  it("calls onSort with the column id when a data sub-header is clicked", () => {
    const onSort = jest.fn();
    render(<DashboardTable {...baseProps({ onSort })} />);
    fireEvent.click(screen.getByText("Total Stock"));
    expect(onSort).toHaveBeenCalledWith("fg_total");
  });

  it("calls onSort with the column id when a meta column header is clicked", () => {
    const onSort = jest.fn();
    render(<DashboardTable {...baseProps({ onSort })} />);
    fireEvent.click(screen.getByText("CBU"));
    expect(onSort).toHaveBeenCalledWith("cbuCode");
  });

  it("calls onDcStockClick, onFactoryStockClick and onInTransitClick when their cells are clicked", () => {
    const onDcStockClick = jest.fn();
    const onFactoryStockClick = jest.fn();
    const onInTransitClick = jest.fn();
    const stockCols = ALL_COLS.filter(
      (c) => c.id === "fg_dc" || c.id === "fg_factory" || c.id === "fg_intransit",
    );
    const row = makeRow({
      fg: { dcStock: 100, factoryStock: 50, inTransitStock: 20, totalStock: 170 },
    });
    render(
      <DashboardTable
        {...baseProps({
          orderedDataCols: stockCols,
          groupRuns: computeGroupRuns(stockCols),
          paginatedRows: [row],
          onDcStockClick,
          onFactoryStockClick,
          onInTransitClick,
        })}
      />,
    );
    fireEvent.click(screen.getByText("100"));
    expect(onDcStockClick).toHaveBeenCalledWith(row);
    fireEvent.click(screen.getByText("50"));
    expect(onFactoryStockClick).toHaveBeenCalledWith(row);
    fireEvent.click(screen.getByText("20"));
    expect(onInTransitClick).toHaveBeenCalledWith(row);
  });

  it("defaults the selected-components set to the union of cached and high-contributing codes when none is provided", () => {
    const row = makeRow({ srNo: 1 });
    const comps = [makeComponent({ componentCode: "COMP1" })];
    const highComps = [makeComponent({ componentCode: "HC1" })];
    render(
      <DashboardTable
        {...baseProps({
          paginatedRows: [row],
          expandedSrNo: 1,
          componentCache: { 1: comps },
          highContributingCache: { 1: highComps },
          selectedComponents: {},
          showHighContributing: true,
        })}
      />,
    );
    // Neither row is greyed out (opacity 0.55) because both default to selected.
    const compRow = screen.getByText("COMP1").closest("tr") as HTMLElement;
    const hcRow = screen.getByText("HC1").closest("tr") as HTMLElement;
    expect(compRow.style.opacity).toBe("1");
    expect(hcRow.style.opacity).toBe("1");
  });

  it("highlights a row on mouse enter and reverts it on mouse leave", () => {
    const row = makeRow({ cbuCode: "AAA" });
    render(<DashboardTable {...baseProps({ paginatedRows: [row] })} />);
    const tr = screen.getByText("AAA").closest("tr") as HTMLElement;

    fireEvent.mouseEnter(tr);
    expect(tr.style.backgroundColor).toBe("rgb(237, 245, 244)");

    fireEvent.mouseLeave(tr);
    expect(tr.style.backgroundColor).toBe("rgb(255, 255, 255)");
  });

  it("does not restyle an expanded row on mouse enter (it keeps its expanded background)", () => {
    const row = makeRow({ srNo: 1, cbuCode: "AAA" });
    render(<DashboardTable {...baseProps({ paginatedRows: [row], expandedSrNo: 1 })} />);
    const tr = screen.getByText("AAA").closest("tr") as HTMLElement;

    fireEvent.mouseEnter(tr);
    expect(tr.style.backgroundColor).toBe("rgb(237, 245, 244)");
  });

  it("filters the unique-components group down to RM components when typeFilter is RM", () => {
    const row = makeRow({ srNo: 1 });
    const comps = [
      makeComponent({ componentCode: "RM1", componentMaterialType: "1001" }),
      makeComponent({ componentCode: "PM1", componentMaterialType: "1002" }),
    ];
    render(
      <DashboardTable
        {...baseProps({
          paginatedRows: [row],
          expandedSrNo: 1,
          componentCache: { 1: comps },
          selectedComponents: { 1: new Set(["RM1", "PM1"]) },
          typeFilter: "RM",
        })}
      />,
    );
    expect(screen.getByText("RM1")).toBeInTheDocument();
    expect(screen.queryByText("PM1")).not.toBeInTheDocument();
  });

  it("filters the unique-components group down to PM components when typeFilter is PM", () => {
    const row = makeRow({ srNo: 1 });
    const comps = [
      makeComponent({ componentCode: "RM1", componentMaterialType: "1001" }),
      makeComponent({ componentCode: "PM1", componentMaterialType: "1002" }),
    ];
    render(
      <DashboardTable
        {...baseProps({
          paginatedRows: [row],
          expandedSrNo: 1,
          componentCache: { 1: comps },
          selectedComponents: { 1: new Set(["RM1", "PM1"]) },
          typeFilter: "PM",
        })}
      />,
    );
    expect(screen.getByText("PM1")).toBeInTheDocument();
    expect(screen.queryByText("RM1")).not.toBeInTheDocument();
  });

  it("shows the RM/PM filtered badge next to the unique-components label when a type filter is active", () => {
    const row = makeRow({ srNo: 1 });
    const comps = [makeComponent({ componentCode: "RM1", componentMaterialType: "1001" })];
    render(
      <DashboardTable
        {...baseProps({
          paginatedRows: [row],
          expandedSrNo: 1,
          componentCache: { 1: comps },
          typeFilter: "RM",
        })}
      />,
    );
    expect(screen.getByText("filtered")).toBeInTheDocument();
  });

  it("renders the high-contributing group when showHighContributing is on", () => {
    const row = makeRow({ srNo: 1 });
    const highComps = [makeComponent({ componentCode: "HC1" })];
    render(
      <DashboardTable
        {...baseProps({
          paginatedRows: [row],
          expandedSrNo: 1,
          highContributingCache: { 1: highComps },
          selectedComponents: { 1: new Set(["HC1"]) },
          showHighContributing: true,
        })}
      />,
    );
    expect(screen.getByText("HC1")).toBeInTheDocument();
  });

  it("toggles the expand-all-descriptions button and reflects its state in the title", () => {
    const row = makeRow({ cbuDescription: "A very long CBU description for testing" });
    render(<DashboardTable {...baseProps({ paginatedRows: [row] })} />);

    const expandAllButton = screen.getByTitle("Expand all descriptions");
    fireEvent.click(expandAllButton);
    expect(screen.getByTitle("Collapse all descriptions")).toBeInTheDocument();

    fireEvent.click(screen.getByTitle("Collapse all descriptions"));
    expect(screen.getByTitle("Expand all descriptions")).toBeInTheDocument();
  });

  describe("cover-date recalculation on RM/PM component selection (bug repro)", () => {
    const coverCols = ALL_COLS.filter(
      (c) => c.id === "cover_total" || c.id === "cover_excl",
    );

    function renderWithSelection(selected: Set<string>) {
      const row = makeRow({
        srNo: 1,
        fg: { dcStock: 100, factoryStock: 0, inTransitStock: 0, totalStock: 100 },
        demand: { sumNext3TDP: 10, next6Months: 20, next12Months: 365 },
        coverMax: {
          fgCoverDate: "01-07-2026",
          totalCoverDate: "01-10-2026",
          coverExclOpenPO: "24-07-2026",
        },
      });
      const comps = [
        makeComponent({ componentCode: "C1", unrestrictedStock: 50, qualityStock: 0, openPOStock: 0 }),
        makeComponent({ componentCode: "C2", unrestrictedStock: 10, qualityStock: 0, openPOStock: 0 }),
      ];
      return render(
        <DashboardTable
          {...baseProps({
            orderedDataCols: coverCols,
            groupRuns: computeGroupRuns(coverCols),
            paginatedRows: [row],
            expandedSrNo: 1,
            componentCache: { 1: comps },
            selectedComponents: { 1: selected },
          })}
        />,
      );
    }

    it("recomputes Total FG Cover once a component is deselected, instead of keeping the API's static date", () => {
      const { unmount } = renderWithSelection(new Set(["C1", "C2"]));
      // Nothing filtered yet — matches the row's static API-precomputed date.
      expect(screen.getByText("01-10-2026")).toBeInTheDocument();
      unmount();

      // Deselect the higher-stock component (C1) — active pool is now just
      // C2 (unrestrictedStock 10), so FG-equivalent RMPM total drops from
      // whatever C1 contributed, and Total FG Cover should recompute to a
      // different date than the static "01-10-2026" the API returned.
      renderWithSelection(new Set(["C2"]));
      expect(screen.queryByText("01-10-2026")).not.toBeInTheDocument();
    });

    it("recomputes Excl. Open PO cover the same way once a component is deselected", () => {
      const { unmount } = renderWithSelection(new Set(["C1", "C2"]));
      expect(screen.getByText("24-07-2026")).toBeInTheDocument();
      unmount();

      renderWithSelection(new Set(["C2"]));
      expect(screen.queryByText("24-07-2026")).not.toBeInTheDocument();
    });
  });

  describe("recalculatedRow override on the expanded row's RM/PM stock (bug repro: vanishing data)", () => {
    const rmpmMinPhysicalCol = ALL_COLS.filter((c) => c.id === "rmpmMin_physical");
    const zeroRmpm = {
      physicalStock: 0,
      qualityStock: 0,
      openPOStock: 0,
      totalStock: 0,
      blockedStock: 0,
      supplierInventory: 0,
      inTransitStock: 0,
    };

    it("keeps showing the real client-computed RM/PM stock when the recalculate response comes back all-zero, instead of blanking the row", () => {
      const row = makeRow({ srNo: 1 });
      const comps = [
        makeComponent({ componentCode: "C1", unrestrictedStock: 2493173769 }),
        makeComponent({ componentCode: "C2", unrestrictedStock: 23139527824 }),
      ];
      // A hollow response — e.g. the request's selected/deselected codes
      // didn't match anything server-side — must not blank out a row that
      // already has real, loaded component data.
      const hollowRecalculatedRow = makeRow({ srNo: 1, rmpmMax: zeroRmpm, rmpmMin: zeroRmpm });

      render(
        <DashboardTable
          {...baseProps({
            orderedDataCols: rmpmMinPhysicalCol,
            groupRuns: computeGroupRuns(rmpmMinPhysicalCol),
            paginatedRows: [row],
            expandedSrNo: 1,
            componentCache: { 1: comps },
            selectedComponents: { 1: new Set(["C1", "C2"]) },
            recalculatedRow: hollowRecalculatedRow,
          })}
        />,
      );

      // Sum of C1 + C2's unrestrictedStock — the real client-computed
      // total, not the hollow recalculate response's zero.
      expect(screen.getByText("25,632,701,593")).toBeInTheDocument();
    });

    it("uses the recalculated response once it reports real RM/PM stock", () => {
      const row = makeRow({ srNo: 1 });
      const comps = [makeComponent({ componentCode: "C1", unrestrictedStock: 999 })];
      const realRecalculatedRow = makeRow({
        srNo: 1,
        rmpmMax: { ...zeroRmpm, physicalStock: 12345, totalStock: 12345 },
        rmpmMin: { ...zeroRmpm, physicalStock: 12345, totalStock: 12345 },
      });

      render(
        <DashboardTable
          {...baseProps({
            orderedDataCols: rmpmMinPhysicalCol,
            groupRuns: computeGroupRuns(rmpmMinPhysicalCol),
            paginatedRows: [row],
            expandedSrNo: 1,
            componentCache: { 1: comps },
            selectedComponents: { 1: new Set(["C1"]) },
            recalculatedRow: realRecalculatedRow,
          })}
        />,
      );

      expect(screen.getByText("12,345")).toBeInTheDocument();
    });

    it("falls back to client-computed Min stock when only rmpmMax is hollow, and to client-computed Max stock when only rmpmMin is hollow — a partially-broken response mustn't blank the half that's hollow (regression repro)", () => {
      const row = makeRow({ srNo: 1 });
      const comps = [
        makeComponent({ componentCode: "C1", unrestrictedStock: 2493173769 }),
        makeComponent({ componentCode: "C2", unrestrictedStock: 23139527824 }),
      ];
      // Mirrors the reported bug exactly: rmpmMax comes back with real
      // figures (so the row as a whole looked "meaningful" under the old,
      // whole-row OR check) while rmpmMin is hollow — the Min section still
      // went blank because the old guard trusted the recalculated row's
      // rmpmMin too, on the strength of rmpmMax alone.
      const halfHollowRecalculatedRow = makeRow({
        srNo: 1,
        rmpmMax: { ...zeroRmpm, physicalStock: 999999, totalStock: 999999 },
        rmpmMin: zeroRmpm,
      });

      const rmpmCols = ALL_COLS.filter(
        (c) => c.id === "rmpmMin_physical" || c.id === "rmpm_physical",
      );

      render(
        <DashboardTable
          {...baseProps({
            orderedDataCols: rmpmCols,
            groupRuns: computeGroupRuns(rmpmCols),
            paginatedRows: [row],
            expandedSrNo: 1,
            componentCache: { 1: comps },
            selectedComponents: { 1: new Set(["C1", "C2"]) },
            recalculatedRow: halfHollowRecalculatedRow,
          })}
        />,
      );

      // Max column trusts the recalculated (real) figure.
      expect(screen.getByText("999,999")).toBeInTheDocument();
      // Min column falls back to the real client-computed sum instead of
      // showing "—" for the hollow recalculated rmpmMin.
      expect(screen.getByText("25,632,701,593")).toBeInTheDocument();
    });
  });
});
