import { configureStore } from "@reduxjs/toolkit";
import { Provider } from "react-redux";
import { render, screen, fireEvent, act, waitFor, within } from "@testing-library/react";
import { toast } from "sonner";
import NationalDashboard from "../NationalDashboard";
import nationalDashboardReducer from "../../store/slices/nationalDashboardSlice";
import {
  useCbuListPagedQuery,
  useCbuFiltersQuery,
  useCbuComponentsQuery,
  useCbuHighContributingComponentsQuery,
  useLastRefreshQuery,
  useRecalculateCbuSummaryMutation,
} from "../../queries/cbuQueries";
import { fetchCbuExport, fetchUserColumnPreferences, saveUserColumnPreferences, CbuApiError } from "../../api/cbuApi";
import {
  ALL_COLS,
  CBU_LIST_ERROR_TOAST,
  COMPONENT_BREAKDOWNS_ERROR_TOAST,
  EXPORT_ERROR_TOAST,
  RECALCULATE_SUMMARY_ERROR_TOAST,
} from "../../constants/nationalDashboard";
import type { CBURow } from "../../components/data";
import type { CbuListPage } from "../../api/cbuApi";

jest.mock("../../queries/cbuQueries", () => ({
  useCbuListPagedQuery: jest.fn(),
  useCbuFiltersQuery: jest.fn(),
  useCbuComponentsQuery: jest.fn(),
  useCbuHighContributingComponentsQuery: jest.fn(),
  useLastRefreshQuery: jest.fn(),
  useRecalculateCbuSummaryMutation: jest.fn(),
}));

jest.mock("../../api/cbuApi", () => ({
  ...jest.requireActual("../../api/cbuApi"),
  fetchCbuExport: jest.fn(),
  fetchUserColumnPreferences: jest.fn(),
  saveUserColumnPreferences: jest.fn(),
}));

jest.mock("@azure/msal-react", () => ({
  useMsal: () => ({ accounts: [{ username: "test.user@example.com" }] }),
}));

jest.mock("../../App", () => ({
  useNav: () => ({ navigate: jest.fn(), nav: { page: "dashboard" } }),
}));

jest.mock("sonner", () => ({ toast: { error: jest.fn(), success: jest.fn() } }));

jest.mock("../../components/DemandModal", () => ({
  DemandModal: (props: { cbuCode: string; period: string; onClose: () => void }) => (
    <div data-testid="demand-modal">
      demand-modal:{props.cbuCode}:{props.period}
      <button type="button" onClick={props.onClose}>
        Close demand modal
      </button>
    </div>
  ),
}));

jest.mock("../../components/StockLocationBreakdownModal", () => ({
  StockLocationBreakdownModal: (props: { kind: string; onClose: () => void }) => (
    <div data-testid="stock-modal">
      stock-modal:{props.kind}
      <button type="button" onClick={props.onClose}>
        Close stock modal
      </button>
    </div>
  ),
}));

const mockUseCbuListPagedQuery = useCbuListPagedQuery as jest.Mock;
const mockUseCbuFiltersQuery = useCbuFiltersQuery as jest.Mock;
const mockUseCbuComponentsQuery = useCbuComponentsQuery as jest.Mock;
const mockUseCbuHighContributingComponentsQuery = useCbuHighContributingComponentsQuery as jest.Mock;
const mockUseLastRefreshQuery = useLastRefreshQuery as jest.Mock;
const mockUseRecalculateCbuSummaryMutation = useRecalculateCbuSummaryMutation as jest.Mock;
const mockFetchCbuExport = fetchCbuExport as jest.Mock;
const mockFetchUserColumnPreferences = fetchUserColumnPreferences as jest.Mock;
const mockSaveUserColumnPreferences = saveUserColumnPreferences as jest.Mock;

function makeListPage(rows: CBURow[], overrides: Partial<CbuListPage> = {}): CbuListPage {
  return { rows, count: rows.length, page: 1, pageSize: 20, ...overrides };
}

function makeRow(overrides: Partial<CBURow> = {}): CBURow {
  return {
    srNo: 1,
    cbuCode: "VAFA1R",
    cbuDescription: "Vaseline aloe fresh 96X85 ml",
    weightKg: 0.096,
    fg: { dcStock: 133135, factoryStock: 0, inTransitStock: 1920, totalStock: 135055 },
    rmpm: {
      physicalStock: 55200,
      qualityStock: 0,
      openPOStock: 144000,
      totalStock: 199200,
      blockedStock: 0,
      supplierInventory: 0,
      inTransitStock: 0,
    },
    rmpmMin: {
      physicalStock: 55200,
      qualityStock: 0,
      openPOStock: 144000,
      totalStock: 199200,
      blockedStock: 0,
      supplierInventory: 0,
      inTransitStock: 0,
    },
    rmpmMax: {
      physicalStock: 55200,
      qualityStock: 0,
      openPOStock: 144000,
      totalStock: 199200,
      blockedStock: 0,
      supplierInventory: 0,
      inTransitStock: 0,
    },
    demand: { sumNext3TDP: 134945, next6Months: 579016, next12Months: 1888100 },
    totalFG: 334255,
    cover: { fgCoverDate: "01-07-2026", totalCoverDate: "01-10-2026", coverExclOpenPO: "24-07-2026" },
    ...overrides,
  };
}

function renderPage() {
  const store = configureStore({ reducer: { nationalDashboard: nationalDashboardReducer } });
  const utils = render(
    <Provider store={store}>
      <NationalDashboard />
    </Provider>,
  );
  return { store, ...utils };
}

function mockQueries(overrides: {
  cbuList?: Partial<ReturnType<typeof useCbuListPagedQuery>>;
  filters?: Partial<ReturnType<typeof useCbuFiltersQuery>>;
  components?: Partial<ReturnType<typeof useCbuComponentsQuery>>;
  highContributingComponents?: Partial<ReturnType<typeof useCbuHighContributingComponentsQuery>>;
  recalculateSummary?: Partial<ReturnType<typeof useRecalculateCbuSummaryMutation>>;
} = {}) {
  mockUseCbuListPagedQuery.mockReturnValue({
    data: makeListPage([]),
    isLoading: false,
    isError: false,
    error: undefined,
    isFetching: false,
    dataUpdatedAt: 0,
    refetch: jest.fn(),
    ...overrides.cbuList,
  });
  mockUseCbuFiltersQuery.mockReturnValue({
    data: undefined,
    isLoading: false,
    isError: false,
    ...overrides.filters,
  });
  mockUseCbuComponentsQuery.mockReturnValue({
    data: [],
    isLoading: false,
    isError: false,
    refetch: jest.fn(),
    ...overrides.components,
  });
  mockUseCbuHighContributingComponentsQuery.mockReturnValue({
    data: [],
    isLoading: false,
    isError: false,
    refetch: jest.fn(),
    ...overrides.highContributingComponents,
  });
  mockUseLastRefreshQuery.mockReturnValue({ data: undefined, isLoading: false, isError: false });
  mockUseRecalculateCbuSummaryMutation.mockReturnValue({
    mutate: jest.fn(),
    isPending: false,
    ...overrides.recalculateSummary,
  });
}

beforeEach(() => {
  jest.clearAllMocks();
});

describe("NationalDashboard", () => {
  it("shows a loading skeleton while the CBU list is loading", () => {
    mockQueries({ cbuList: { isLoading: true, data: undefined } });
    renderPage();
    expect(screen.getByLabelText("Loading CBU data…")).toBeInTheDocument();
  });

  it("shows an error message when the CBU list query fails", () => {
    mockQueries({ cbuList: { isError: true } });
    renderPage();
    expect(screen.getByText("Could not load CBU data.")).toBeInTheDocument();
  });

  it("shows the no-data message when the CBU list is empty", () => {
    mockQueries();
    renderPage();
    expect(screen.getByText("No CBU data available.")).toBeInTheDocument();
  });

  it("renders CBU rows from the list query", () => {
    mockQueries({ cbuList: { data: makeListPage([makeRow()]) } });
    renderPage();
    expect(screen.getByText("VAFA1R")).toBeInTheDocument();
  });

  it("sends the debounced search box value as the list query's search param", () => {
    jest.useFakeTimers();
    mockQueries({ cbuList: { data: makeListPage([makeRow()]) } });
    renderPage();
    fireEvent.change(screen.getByPlaceholderText("Search"), { target: { value: "AAA111" } });
    act(() => {
      jest.advanceTimersByTime(500);
    });
    const lastParams = mockUseCbuListPagedQuery.mock.calls.at(-1)?.[0];
    expect(lastParams?.search).toBe("AAA111");
    jest.useRealTimers();
  });

  it("applies saved column preferences from the API on initial load", async () => {
    mockQueries({ cbuList: { data: makeListPage([makeRow()]) } });
    mockFetchUserColumnPreferences.mockResolvedValueOnce({
      customized: true,
      sections: [
        {
          section_name: "product_info",
          section_label: "Product Info",
          priority: 1,
          is_visible: true,
          visible_count: 2,
          total_count: 7,
          columns: [
            { name: "cbu", label: "CBU", priority: 1, is_visible: true },
            { name: "cbu_description", label: "CBU Description", priority: 2, is_visible: true },
            { name: "basepack", label: "BasePack", priority: 3, is_visible: false },
          ],
        },
      ],
    });
    const { store } = renderPage();

    await waitFor(() => {
      expect(store.getState().nationalDashboard.hiddenCols).toContain("basePack");
    });
  });

  it("keeps the default column set visible for a fresh user with no saved preference (customized: false), instead of collapsing the table down to just CBU Code/Description", async () => {
    mockQueries({ cbuList: { data: makeListPage([makeRow()]) } });
    // Resolved manually (not mockResolvedValueOnce) so the assertion below
    // can't race ahead of the effect's dispatch — a plain waitFor on "the
    // mock was called" was passing even when the dispatched hiddenCols was
    // still wrong, since that only proves the fetch started, not that its
    // result has been applied to the store yet.
    let resolveFetch: (v: unknown) => void;
    mockFetchUserColumnPreferences.mockReturnValueOnce(
      new Promise((resolve) => {
        resolveFetch = resolve;
      }),
    );
    const { store } = renderPage();

    await waitFor(() => {
      expect(mockFetchUserColumnPreferences).toHaveBeenCalled();
    });
    await act(async () => {
      resolveFetch!({ customized: false, sections: [] });
      await Promise.resolve();
    });

    const hidden = store.getState().nationalDashboard.hiddenCols;
    // A handful of columns are hidden by default (see DEFAULT_HIDDEN_COLS)
    // — everything else, including ordinary data columns like fg_total,
    // must still be visible.
    expect(hidden).not.toContain("fg_total");
    expect(hidden).not.toContain("demand_12m");
    expect(hidden).not.toContain("cover_total");
    expect(hidden).toContain("rmpm_intransit");
    expect(hidden).toContain("basePack");
  });

  it("distinguishes Min and Max section visibility despite shared backend column names", async () => {
    mockQueries({ cbuList: { data: makeListPage([makeRow()]) } });
    mockFetchUserColumnPreferences.mockResolvedValueOnce({
      customized: true,
      sections: [
        {
          section_name: "fg_equivalent_rmpm_stock_min",
          priority: 4,
          is_visible: true,
          columns: [{ name: "physical_stock", priority: 1, is_visible: true }],
        },
        {
          section_name: "fg_equivalent_rmpm_stock_max",
          priority: 7,
          is_visible: true,
          columns: [{ name: "physical_stock", priority: 1, is_visible: false }],
        },
      ],
    });
    const { store } = renderPage();

    await waitFor(() => {
      const hidden = store.getState().nationalDashboard.hiddenCols;
      expect(hidden).not.toContain("rmpmMin_physical");
      expect(hidden).toContain("rmpm_physical");
    });
  });

  it("closes the panel and shows a green success toast after Done, using the real (no success field) response shape", async () => {
    mockQueries({ cbuList: { data: makeListPage([makeRow()]) } });
    mockFetchUserColumnPreferences.mockResolvedValueOnce({ customized: false, sections: [] });
    mockSaveUserColumnPreferences.mockResolvedValueOnce({
      message: "User preferences saved successfully.",
      data: {
        user_email: "test.user@example.com",
        screen_id: "cbu_national_view",
        pref_type: "COLUMN",
        customized: true,
        sections: [],
      },
    });
    renderPage();

    fireEvent.click(screen.getByText("Customise"));
    fireEvent.click(screen.getByText("Done"));

    await waitFor(() => {
      expect(toast.success).toHaveBeenCalledWith(
        "User preferences saved successfully.",
        expect.objectContaining({
          id: "national-dashboard-column-preferences-save-success",
          style: expect.objectContaining({ backgroundColor: "#ecfdf3", color: "#166534" }),
        }),
      );
    });

    await waitFor(() => {
      expect(screen.queryByText("Done")).not.toBeInTheDocument();
    });
  });

  it("saves the current column customization when Done is clicked", async () => {
    mockQueries({ cbuList: { data: makeListPage([makeRow()]) } });
    mockFetchUserColumnPreferences.mockResolvedValueOnce({
      customized: false,
      sections: [],
    });
    mockSaveUserColumnPreferences.mockResolvedValueOnce({ success: true });
    renderPage();

    fireEvent.click(screen.getByText("Customise"));
    fireEvent.click(screen.getAllByTitle("Hide column")[0]);
    fireEvent.click(screen.getByText("Done"));

    await waitFor(() => {
      expect(mockSaveUserColumnPreferences).toHaveBeenCalled();
    });
  });

  it("sends a compact PUT payload with one backend section per logical preference section", async () => {
    mockQueries({ cbuList: { data: makeListPage([makeRow()]) } });
    mockFetchUserColumnPreferences.mockResolvedValueOnce({
      customized: false,
      sections: [],
    });
    mockSaveUserColumnPreferences.mockResolvedValueOnce({ success: true });
    renderPage();

    fireEvent.click(screen.getByText("Customise"));
    fireEvent.click(screen.getByText("Done"));

    await waitFor(() => {
      expect(mockSaveUserColumnPreferences).toHaveBeenCalled();
    });

    const payload = mockSaveUserColumnPreferences.mock.calls[0][0];
    expect(payload.sections.map((section: { section_name: string }) => section.section_name)).toEqual([
      "product_info",
      "demand",
      "fg_equivalent_rmpm_stock_min",
      "fg_summary_min",
      "cover_production_end_date_min",
      "fg_equivalent_rmpm_stock_max",
      "fg_summary_max",
      "cover_production_end_date_max",
    ]);
    expect(payload.sections[2].columns.map((column: { name: string }) => column.name)).toEqual([
      "physical_stock",
      "quality_stock",
      "open_po_stock",
      "in_transit",
      "supplier_inventory",
      "total_stock",
      "blocked_stock",
    ]);
    expect(payload.sections[3].columns.map((column: { name: string }) => column.name)).toEqual([
      "total_fg",
      "total_fg_cover_days",
    ]);
  });

  it("shows a success toast and resets to the latest saved customization after a successful save", async () => {
    mockQueries({ cbuList: { data: makeListPage([makeRow()]) } });
    mockFetchUserColumnPreferences.mockResolvedValueOnce({
      customized: false,
      sections: [],
    });
    mockSaveUserColumnPreferences.mockResolvedValueOnce({ success: true });
    renderPage();

    fireEvent.click(screen.getByText("Customise"));
    fireEvent.click(screen.getAllByTitle("Hide column")[0]);
    fireEvent.click(screen.getByText("Done"));

    await waitFor(() => {
      expect(mockSaveUserColumnPreferences).toHaveBeenCalled();
    });

    await waitFor(() => {
      expect(toast.success).toHaveBeenCalledWith(
        "Column preferences saved",
        expect.objectContaining({ id: "national-dashboard-column-preferences-save-success" }),
      );
    });

    fireEvent.click(screen.getByText("Customise"));
    fireEvent.click(screen.getByText("Reset"));

    // expect(screen.getByText(`${ALL_COLS.length - 1}/${ALL_COLS.length}`)).toBeInTheDocument();
  });

  it("shows a no-search-results message with a clear-filters action when nothing matches", () => {
    jest.useFakeTimers();
    mockQueries();
    mockUseCbuListPagedQuery.mockImplementation((params: { search?: string }) => ({
      data: params.search ? makeListPage([]) : makeListPage([makeRow()]),
      isLoading: false,
      isError: false,
      error: undefined,
      isFetching: false,
      dataUpdatedAt: 0,
      refetch: jest.fn(),
    }));
    renderPage();
    fireEvent.change(screen.getByPlaceholderText("Search"), {
      target: { value: "no such cbu exists" },
    });
    act(() => {
      jest.advanceTimersByTime(500);
    });
    expect(screen.getByText("No CBUs match your search or filters.")).toBeInTheDocument();
    fireEvent.click(screen.getByText("Clear filters"));
    act(() => {
      jest.advanceTimersByTime(500);
    });
    expect(screen.getByText("VAFA1R")).toBeInTheDocument();
    jest.useRealTimers();
  });

  it("toggles the High Contributing filter switch", () => {
    mockQueries({ cbuList: { data: makeListPage([makeRow()]) } });
    renderPage();
    const toggle = screen.getByRole("switch", { name: /High Contributing/i });
    expect(toggle).toHaveAttribute("aria-checked", "false");
    fireEvent.click(toggle);
    expect(toggle).toHaveAttribute("aria-checked", "true");
  });

  it("fetches the High Contributing component set (contributionType=high-contributer) only once the toggle is on", () => {
    mockQueries({ cbuList: { data: makeListPage([makeRow()]) } });
    renderPage();
    fireEvent.click(screen.getByText("VAFA1R"));

    expect(mockUseCbuHighContributingComponentsQuery).toHaveBeenLastCalledWith("VAFA1R", false);

    fireEvent.click(screen.getByRole("switch", { name: /High Contributing/i }));

    expect(mockUseCbuHighContributingComponentsQuery).toHaveBeenLastCalledWith("VAFA1R", true);
  });

  it("shows the High Contributing component group once its data has loaded and the toggle is on", () => {
    mockQueries({
      cbuList: { data: makeListPage([makeRow()]) },
      highContributingComponents: {
        data: [
          {
            componentCode: "HC1",
            componentMaterialType: "1002",
            componentDescription: "High contributor",
            unrestrictedStock: 10,
            qualityStock: 0,
            blockedStock: 0,
            totalStock: 10,
            openPOStock: 0,
            contributionType: "high-contributer",
          },
        ],
      },
    });
    renderPage();
    fireEvent.click(screen.getByText("VAFA1R"));
    fireEvent.click(screen.getByRole("switch", { name: /High Contributing/i }));

    expect(screen.getByText("HC1")).toBeInTheDocument();
  });

  it("excludes components tagged \"unique\" from the High Contributing group, even though the contributionType=high-contributer endpoint returned them", () => {
    mockQueries({
      cbuList: { data: makeListPage([makeRow()]) },
      highContributingComponents: {
        data: [
          {
            componentCode: "HC1",
            componentMaterialType: "1002",
            componentDescription: "High contributor",
            unrestrictedStock: 10,
            qualityStock: 0,
            blockedStock: 0,
            totalStock: 10,
            openPOStock: 0,
            contributionType: "high-contributer",
          },
          {
            componentCode: "NOTHC",
            componentMaterialType: "1002",
            componentDescription: "Not actually high-contributing",
            unrestrictedStock: 5,
            qualityStock: 0,
            blockedStock: 0,
            totalStock: 5,
            openPOStock: 0,
            contributionType: "unique",
          },
        ],
      },
    });
    renderPage();
    fireEvent.click(screen.getByText("VAFA1R"));
    fireEvent.click(screen.getByRole("switch", { name: /High Contributing/i }));

    expect(screen.getByText("HC1")).toBeInTheDocument();
    expect(screen.queryByText("NOTHC")).not.toBeInTheDocument();
  });

  it("calls refetch for both queries when the refresh button is clicked with a row expanded", () => {
    const refetchCbuList = jest.fn();
    const refetchComponents = jest.fn();
    mockQueries({
      cbuList: { data: makeListPage([makeRow()]), refetch: refetchCbuList },
      components: { refetch: refetchComponents },
    });
    renderPage();
    fireEvent.click(screen.getByText("VAFA1R"));
    fireEvent.click(screen.getByTitle("Refresh"));
    expect(refetchCbuList).toHaveBeenCalledTimes(1);
    expect(refetchComponents).toHaveBeenCalledTimes(1);
  });

  it("does not refetch components on refresh when no row is expanded", () => {
    const refetchCbuList = jest.fn();
    const refetchComponents = jest.fn();
    mockQueries({
      cbuList: { data: makeListPage([makeRow()]), refetch: refetchCbuList },
      components: { refetch: refetchComponents },
    });
    renderPage();
    fireEvent.click(screen.getByTitle("Refresh"));
    expect(refetchCbuList).toHaveBeenCalledTimes(1);
    expect(refetchComponents).not.toHaveBeenCalled();
  });

  it("clears search text and dropdown filters when the refresh button is clicked", () => {
    mockQueries({ cbuList: { data: makeListPage([makeRow()]) } });
    const { store } = renderPage();
    fireEvent.change(screen.getByPlaceholderText("Search"), { target: { value: "leftover" } });
    expect(store.getState().nationalDashboard.search).toBe("leftover");
    fireEvent.click(screen.getByTitle("Refresh"));
    expect(store.getState().nationalDashboard.search).toBe("");
  });

  describe("error toasts", () => {
    it("shows a toast with a generic message when the CBU list query fails with a plain error", () => {
      mockQueries({ cbuList: { isError: true, error: new Error("network down") } });
      renderPage();
      expect(toast.error).toHaveBeenCalledWith(
        CBU_LIST_ERROR_TOAST,
        expect.objectContaining({ id: "national-dashboard-cbu-list-error" }),
      );
    });

    it("appends the API's validation detail when the CBU list query fails with a CbuApiError", () => {
      const apiError = new CbuApiError(422, "material: Invalid value", [
        { loc: ["query", "material"], msg: "Invalid value", type: "value_error" },
      ]);
      mockQueries({ cbuList: { isError: true, error: apiError } });
      renderPage();
      expect(toast.error).toHaveBeenCalledWith(
        `${CBU_LIST_ERROR_TOAST} (material: Invalid value)`,
        expect.anything(),
      );
    });

    it("shows a toast when the component breakdown query fails", () => {
      mockQueries({
        cbuList: { data: makeListPage([makeRow()]) },
        components: { isError: true },
      });
      renderPage();
      expect(toast.error).toHaveBeenCalledWith(
        COMPONENT_BREAKDOWNS_ERROR_TOAST,
        expect.objectContaining({ id: "national-dashboard-component-breakdowns-error" }),
      );
    });
  });

  describe("sorting", () => {
    it("sorts ascending on first header click, toggles to descending on the second, and resets to page 1", () => {
      mockQueries({ cbuList: { data: makeListPage([makeRow()]) } });
      const { store } = renderPage();

      const cbuHeader = screen
        .getAllByRole("columnheader")
        .find((el) => el.textContent?.includes("CBU") && !el.textContent?.includes("CBU Description"));
      fireEvent.click(cbuHeader as HTMLElement);
      expect(store.getState().nationalDashboard.sortCol).toBe("cbuCode");
      expect(store.getState().nationalDashboard.sortDir).toBe("asc");
      let lastParams = mockUseCbuListPagedQuery.mock.calls.at(-1)?.[0];
      expect(lastParams?.sortBy).toBe("cbuCode");
      expect(lastParams?.sortOrder).toBe("asc");

      fireEvent.click(cbuHeader as HTMLElement);
      expect(store.getState().nationalDashboard.sortDir).toBe("desc");
      lastParams = mockUseCbuListPagedQuery.mock.calls.at(-1)?.[0];
      expect(lastParams?.sortOrder).toBe("desc");
    });

    it("switches sortBy to the newly clicked column instead of keeping the previous one", () => {
      mockQueries({ cbuList: { data: makeListPage([makeRow()]) } });
      const { store } = renderPage();

      const descHeader = screen
        .getAllByRole("columnheader")
        .find((el) => el.textContent?.includes("CBU Description"));
      fireEvent.click(descHeader as HTMLElement);
      expect(store.getState().nationalDashboard.sortCol).toBe("cbuDescription");
      let lastParams = mockUseCbuListPagedQuery.mock.calls.at(-1)?.[0];
      expect(lastParams?.sortBy).toBe("cbuDescription");

      const cbuHeader = screen
        .getAllByRole("columnheader")
        .find((el) => el.textContent?.includes("CBU") && !el.textContent?.includes("CBU Description"));
      fireEvent.click(cbuHeader as HTMLElement);
      expect(store.getState().nationalDashboard.sortCol).toBe("cbuCode");
      lastParams = mockUseCbuListPagedQuery.mock.calls.at(-1)?.[0];
      expect(lastParams?.sortBy).toBe("cbuCode");
    });
  });

  describe("pagination", () => {
    it("changing rows-per-page sends the new pageSize and resets to page 1", () => {
      mockQueries({ cbuList: { data: makeListPage([makeRow()], { count: 45 }) } });
      const { store, container } = renderPage();
      const select = container.querySelector("select") as HTMLSelectElement;
      fireEvent.change(select, { target: { value: "50" } });
      expect(store.getState().nationalDashboard.rowsPerPage).toBe(50);
      expect(store.getState().nationalDashboard.page).toBe(1);
      const lastParams = mockUseCbuListPagedQuery.mock.calls.at(-1)?.[0];
      expect(lastParams?.pageSize).toBe(50);
    });

    it("clicking Next page advances the page and sends it to the query", () => {
      mockQueries({ cbuList: { data: makeListPage([makeRow()], { count: 45 }) } });
      const { store } = renderPage();
      fireEvent.click(screen.getByLabelText("Next page"));
      expect(store.getState().nationalDashboard.page).toBe(2);
      const lastParams = mockUseCbuListPagedQuery.mock.calls.at(-1)?.[0];
      expect(lastParams?.page).toBe(2);
    });
  });

  describe("toolbar filters", () => {
    it("selecting a Material Type option sends it as the query's materialType param and resets to page 1", () => {
      mockQueries({ cbuList: { data: makeListPage([makeRow()], { count: 45 }) } });
      const { store } = renderPage();
      fireEvent.click(screen.getByLabelText("Next page"));
      expect(store.getState().nationalDashboard.page).toBe(2);

      fireEvent.click(screen.getByRole("button", { name: "RM" }));
      expect(store.getState().nationalDashboard.dropdownFilters.materialType).toEqual(["RM"]);
      expect(store.getState().nationalDashboard.page).toBe(1);
      const lastParams = mockUseCbuListPagedQuery.mock.calls.at(-1)?.[0];
      expect(lastParams?.materialType).toBe("RM");
    });

    it("selecting the Tonnes UOM option sends the API's TON code (not the UI's MT code)", () => {
      mockQueries({ cbuList: { data: makeListPage([makeRow()]) } });
      renderPage();
      fireEvent.click(screen.getByRole("button", { name: "Tonnes" }));
      const lastParams = mockUseCbuListPagedQuery.mock.calls.at(-1)?.[0];
      expect(lastParams?.uom).toBe("TON");
    });
  });

  describe("row expand/collapse", () => {
    it("expands a row when its CBU code is clicked, and collapses it again on a second click", () => {
      mockQueries({ cbuList: { data: makeListPage([makeRow()]) } });
      const { store } = renderPage();
      fireEvent.click(screen.getByText("VAFA1R"));
      expect(store.getState().nationalDashboard.expandedSrNo).toBe(1);
      fireEvent.click(screen.getByText("VAFA1R"));
      expect(store.getState().nationalDashboard.expandedSrNo).toBeNull();
    });

    it("fetches components for the expanded row's cbuCode, not the collapsed state", () => {
      mockQueries({ cbuList: { data: makeListPage([makeRow({ cbuCode: "VAFA1R" })]) } });
      renderPage();
      expect(mockUseCbuComponentsQuery).toHaveBeenLastCalledWith(undefined);
      fireEvent.click(screen.getByText("VAFA1R"));
      expect(mockUseCbuComponentsQuery).toHaveBeenLastCalledWith("VAFA1R");
    });

    it("defaults the expanded row's component selection to every fetched component once loaded", () => {
      mockQueries({
        cbuList: { data: makeListPage([makeRow({ srNo: 1, cbuCode: "VAFA1R" })]) },
        components: {
          data: [
            { componentCode: "COMP1", componentMaterialType: "1002", unrestrictedStock: 0, qualityStock: 0, blockedStock: 0, totalStock: 0, openPOStock: 0 },
            { componentCode: "COMP2", componentMaterialType: "1003", unrestrictedStock: 0, qualityStock: 0, blockedStock: 0, totalStock: 0, openPOStock: 0 },
          ],
        },
      });
      const { store } = renderPage();
      fireEvent.click(screen.getByText("VAFA1R"));
      expect(store.getState().nationalDashboard.selectedComponents[1]).toEqual(
        expect.arrayContaining(["COMP1", "COMP2"]),
      );
    });

    it("keeps a component deselected after unchecking it, instead of immediately re-selecting it", () => {
      mockQueries({
        cbuList: { data: makeListPage([makeRow({ srNo: 1, cbuCode: "VAFA1R" })]) },
        components: {
          data: [
            { componentCode: "COMP1", componentMaterialType: "1002", unrestrictedStock: 0, qualityStock: 0, blockedStock: 0, totalStock: 0, openPOStock: 0 },
            { componentCode: "COMP2", componentMaterialType: "1003", unrestrictedStock: 0, qualityStock: 0, blockedStock: 0, totalStock: 0, openPOStock: 0 },
          ],
        },
      });
      const { store } = renderPage();
      fireEvent.click(screen.getByText("VAFA1R"));
      expect(store.getState().nationalDashboard.selectedComponents[1]).toEqual(
        expect.arrayContaining(["COMP1", "COMP2"]),
      );

      const compRow = screen.getByText("COMP1").closest("tr") as HTMLElement;
      fireEvent.click(within(compRow).getByRole("checkbox"));

      expect(store.getState().nationalDashboard.selectedComponents[1]).toEqual(["COMP2"]);
    });

    // Bug repro: "Total FG Cover"/"Excl. Open PO" should recompute once the
    // user deselects an RM/PM component, instead of staying pinned to the
    // API's static coverMax figures for the row.
    it("recomputes Total FG Cover once an RM/PM component is deselected", () => {
      mockQueries({
        cbuList: {
          data: makeListPage([
            makeRow({
              srNo: 1,
              cbuCode: "VAFA1R",
              fg: { dcStock: 100, factoryStock: 0, inTransitStock: 0, totalStock: 100 },
              demand: { sumNext3TDP: 10, next6Months: 20, next12Months: 365 },
              coverMax: {
                fgCoverDate: "01-07-2026",
                totalCoverDate: "01-10-2026",
                coverExclOpenPO: "24-07-2026",
              },
              coverMin: {
                fgCoverDate: "02-07-2026",
                totalCoverDate: "02-10-2026",
                coverExclOpenPO: "25-07-2026",
              },
            }),
          ]),
        },
        components: {
          data: [
            { componentCode: "COMP1", componentMaterialType: "1002", unrestrictedStock: 50, qualityStock: 0, blockedStock: 0, totalStock: 50, openPOStock: 0 },
            { componentCode: "COMP2", componentMaterialType: "1002", unrestrictedStock: 10, qualityStock: 0, blockedStock: 0, totalStock: 10, openPOStock: 0 },
          ],
        },
      });
      renderPage();
      fireEvent.click(screen.getByText("VAFA1R"));

      // Nothing deselected yet — Total FG Cover matches the API's static date.
      expect(screen.getByText("01-10-2026")).toBeInTheDocument();

      const compRow = screen.getByText("COMP1").closest("tr") as HTMLElement;
      fireEvent.click(within(compRow).getByRole("checkbox"));

      // COMP1 (the higher-stock component) is deselected — Total FG Cover
      // should recompute off the remaining selection (COMP2 alone) and no
      // longer show the original static date.
      expect(screen.queryByText("01-10-2026")).not.toBeInTheDocument();
    });

    // srNo is only a row's rank within the current result set (see
    // fetchCbuByCode's comment in cbuApi.ts), not a stable per-CBU id — once
    // search/sort/pagination actually changes that set, an unrelated CBU can
    // land on the same rank the previously-expanded row held. These guard
    // against that by asserting the row collapses instead of misattributing
    // to whatever CBU is now on that rank.
    it("collapses an expanded row when the search box changes", () => {
      jest.useFakeTimers();
      try {
        mockQueries({ cbuList: { data: makeListPage([makeRow()]) } });
        const { store } = renderPage();
        fireEvent.click(screen.getByText("VAFA1R"));
        expect(store.getState().nationalDashboard.expandedSrNo).toBe(1);

        fireEvent.change(screen.getByPlaceholderText(/search/i), { target: { value: "abc" } });
        act(() => {
          jest.advanceTimersByTime(500);
        });
        expect(store.getState().nationalDashboard.expandedSrNo).toBeNull();
      } finally {
        jest.useRealTimers();
      }
    });

    it("collapses an expanded row when a column is sorted", () => {
      mockQueries({ cbuList: { data: makeListPage([makeRow()]) } });
      const { store } = renderPage();
      fireEvent.click(screen.getByText("VAFA1R"));
      expect(store.getState().nationalDashboard.expandedSrNo).toBe(1);

      const cbuHeader = screen
        .getAllByRole("columnheader")
        .find((el) => el.textContent?.includes("CBU") && !el.textContent?.includes("CBU Description"));
      fireEvent.click(cbuHeader as HTMLElement);
      expect(store.getState().nationalDashboard.expandedSrNo).toBeNull();
    });

    it("collapses an expanded row when moving to the next page", () => {
      mockQueries({ cbuList: { data: makeListPage([makeRow()], { count: 45 }) } });
      const { store } = renderPage();
      fireEvent.click(screen.getByText("VAFA1R"));
      expect(store.getState().nationalDashboard.expandedSrNo).toBe(1);

      fireEvent.click(screen.getByLabelText("Next page"));
      expect(store.getState().nationalDashboard.expandedSrNo).toBeNull();
    });

    it("does not collapse an expanded row when the High Contributing toggle is switched", () => {
      mockQueries({ cbuList: { data: makeListPage([makeRow()]) } });
      const { store } = renderPage();
      fireEvent.click(screen.getByText("VAFA1R"));
      expect(store.getState().nationalDashboard.expandedSrNo).toBe(1);

      fireEvent.click(screen.getByRole("switch", { name: /High Contributing/i }));
      expect(store.getState().nationalDashboard.expandedSrNo).toBe(1);
    });
  });

  describe("export", () => {
    let clickSpy: jest.SpyInstance;
    let createObjectURLSpy: jest.Mock;
    let revokeObjectURLSpy: jest.Mock;

    beforeEach(() => {
      clickSpy = jest.spyOn(HTMLAnchorElement.prototype, "click").mockImplementation(() => {});
      createObjectURLSpy = jest.fn(() => "blob:mock-url");
      revokeObjectURLSpy = jest.fn();
      // jsdom doesn't implement these — the component calls them directly.
      (global as unknown as { URL: typeof URL }).URL.createObjectURL = createObjectURLSpy;
      (global as unknown as { URL: typeof URL }).URL.revokeObjectURL = revokeObjectURLSpy;
    });

    afterEach(() => {
      clickSpy.mockRestore();
    });

    it("downloads the exported file when the Export button is clicked", async () => {
      const blob = new Blob(["data"], { type: "application/octet-stream" });
      mockFetchCbuExport.mockResolvedValueOnce({ blob, filename: "cbu-export.xlsx" });
      mockQueries({ cbuList: { data: makeListPage([makeRow()]) } });
      renderPage();

      fireEvent.click(screen.getByTitle("Export"));

      await waitFor(() => expect(clickSpy).toHaveBeenCalledTimes(1));
      expect(mockFetchCbuExport).toHaveBeenCalledWith(expect.objectContaining({ uom: "EA" }));
      expect(createObjectURLSpy).toHaveBeenCalledWith(blob);
      expect(revokeObjectURLSpy).toHaveBeenCalledWith("blob:mock-url");
    });

    it("shows a toast and does not download anything when the export request fails", async () => {
      mockFetchCbuExport.mockRejectedValueOnce(new CbuApiError(500, "boom"));
      mockQueries({ cbuList: { data: makeListPage([makeRow()]) } });
      renderPage();

      fireEvent.click(screen.getByTitle("Export"));

      await waitFor(() =>
        expect(toast.error).toHaveBeenCalledWith(
          EXPORT_ERROR_TOAST,
          expect.objectContaining({ id: "national-dashboard-export-error" }),
        ),
      );
      expect(clickSpy).not.toHaveBeenCalled();
    });
  });

  describe("modals", () => {
    it("opens the demand modal for the clicked period and closes it again", async () => {
      const row = makeRow({ demand: { sumNext3TDP: 1, next6Months: 2, next12Months: 999 } });
      mockQueries({ cbuList: { data: makeListPage([row]) } });
      renderPage();

      fireEvent.click(screen.getByText("999"));
      expect(
        await screen.findByTestId("demand-modal"),
      ).toHaveTextContent("demand-modal:VAFA1R:12m");

      fireEvent.click(screen.getByText("Close demand modal"));
      expect(screen.queryByTestId("demand-modal")).not.toBeInTheDocument();
    });

    it("opens the stock location modal for the clicked DC stock cell and closes it again", async () => {
      const row = makeRow({
        fg: { dcStock: 999, factoryStock: 500, inTransitStock: 20, totalStock: 1519 },
      });
      mockQueries({ cbuList: { data: makeListPage([row]) } });
      renderPage();

      fireEvent.click(screen.getByText("999"));
      expect(await screen.findByTestId("stock-modal")).toHaveTextContent("stock-modal:dc");

      fireEvent.click(screen.getByText("Close stock modal"));
      expect(screen.queryByTestId("stock-modal")).not.toBeInTheDocument();
    });

    it("opens the stock location modal for the clicked factory stock cell", async () => {
      const row = makeRow({
        fg: { dcStock: 999, factoryStock: 500, inTransitStock: 20, totalStock: 1519 },
      });
      mockQueries({ cbuList: { data: makeListPage([row]) } });
      renderPage();

      fireEvent.click(screen.getByText("500"));
      expect(await screen.findByTestId("stock-modal")).toHaveTextContent("stock-modal:factory");
    });
  });

  describe("column customization save error", () => {
    it("shows an error toast with the failure message when saving column preferences fails", async () => {
      mockQueries({ cbuList: { data: makeListPage([makeRow()]) } });
      mockFetchUserColumnPreferences.mockResolvedValueOnce({ customized: false, sections: [] });
      mockSaveUserColumnPreferences.mockRejectedValueOnce(new Error("Network down"));
      renderPage();

      fireEvent.click(screen.getByText("Customise"));
      fireEvent.click(screen.getByText("Done"));

      await waitFor(() => {
        expect(toast.error).toHaveBeenCalledWith(
          "Network down",
          expect.objectContaining({ id: "national-dashboard-column-preferences-save-error" }),
        );
      });
      // The panel stays open since onDone effectively returned false on failure.
      expect(screen.getByText("Customise Table")).toBeInTheDocument();
    });

    it("falls back to a generic message when the save fails with a non-Error rejection", async () => {
      mockQueries({ cbuList: { data: makeListPage([makeRow()]) } });
      mockFetchUserColumnPreferences.mockResolvedValueOnce({ customized: false, sections: [] });
      mockSaveUserColumnPreferences.mockRejectedValueOnce("boom");
      renderPage();

      fireEvent.click(screen.getByText("Customise"));
      fireEvent.click(screen.getByText("Done"));

      await waitFor(() => {
        expect(toast.error).toHaveBeenCalledWith(
          "Unable to save column preferences",
          expect.objectContaining({ id: "national-dashboard-column-preferences-save-error" }),
        );
      });
    });
  });

  describe("search input focus styling", () => {
    it("changes the search input's border color on focus and reverts it on blur", () => {
      mockQueries({ cbuList: { data: makeListPage([makeRow()]) } });
      renderPage();
      const input = screen.getByPlaceholderText(/search/i) as HTMLInputElement;

      fireEvent.focus(input);
      expect(input.style.borderColor.toLowerCase()).toBe("#1565c0");

      fireEvent.blur(input);
      expect(input.style.borderColor).toBe("#d1d5db");
    });
  });
});
