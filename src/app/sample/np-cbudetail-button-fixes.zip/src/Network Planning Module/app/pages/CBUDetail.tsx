import { useEffect, useMemo, useState } from "react";
import { useMsal } from "@azure/msal-react";
import { toast } from "sonner";
import { useNav } from "../App";
import { ChevronLeft, FlaskConical } from "lucide-react";
import { PageTabHeader } from "../components/PageTabHeader";
import { ScrollShadowContainer } from "../components/ScrollShadowContainer";
import { ProductionPlanModal } from "../components/ProductionPlanModal";
import { StockTable } from "../components/cbuDetails/StockTable";
import { CbuDetailLoading, CbuDetailError } from "../components/cbuDetails/CbuDetailStatus";
import { CbuDetailHeader } from "../components/cbuDetails/CbuDetailHeader";
import { CbuDetailKpiRow } from "../components/cbuDetails/CbuDetailKpiRow";
import { StockTableHeader } from "../components/cbuDetails/StockTableHeader";
import { useCbuDetailData } from "../components/cbuDetails/useCbuDetailData";
import {
  getRowMetricsGetter,
  getPlantMetricsGetter,
} from "../components/cbuDetails/utils";
import type { CbuDetailPageProps } from "../components/cbuDetails/types";
import {
  fetchUserColumnPreferences,
  saveUserColumnPreferences,
  type UserColumnPreferencePayload,
  type UserColumnPreferenceResponse,
} from "../api/cbuApi";
import {
  OPEN_SIMULATION_LABEL,
  // openSimulationTitle,
  BACK_TO_DASHBOARD_LABEL,
  BACK_TO_DASHBOARD_TITLE,
  noRowsMessage,
  rowHeaderSubtext,
  CBU_ROW_ERROR_TOAST,
  CBU_DEMAND_ERROR_TOAST,
  CBU_COMPONENT_BREAKDOWNS_ERROR_TOAST,
  CBU_PLANT_DATA_ERROR_TOAST,
  STOCK_COLUMN_DEFS,
  DEFAULT_HIDDEN_STOCK_COLS,
  type StockColGroup,
} from "../constants/cbuDetail";
import { useAppDispatch, useAppSelector } from "../store/hooks";
import {
  resetCbuDetailState,
  setExpandedComponents,
  setHiddenStockCols,
  setUom,
  toggleComponentExpanded,
  toggleExpandedCluster,
} from "../store/slices/cbuDetailSlice";

const CBU_DETAIL_COLUMN_PREFS_SCREEN_ID = "cbu_details";

// The backend name each STOCK_COLUMN_DEFS id is saved/loaded as — every id
// maps 1:1 to exactly one name, unlike the National Dashboard's preference
// layout (where the same backend name can repeat across Min/Max sections),
// so a flat two-way lookup is all this screen needs.
const STOCK_COLUMN_PREFERENCE_NAMES: Record<string, string> = {
  openPO: "open_po",
  inTransit: "in_transit",
  supplier: "supplier_inventory",
  cover: "fg_cover_date",
  fgAvailable: "fg_available_at_plant",
  productionPlan: "production_plan",
  fgCoverOnHandMin: "fg_cover_on_hand_only_min",
  fgCoverOnHandMax: "fg_cover_on_hand_only_max",
  fgCoverOnHandOpenPOMin: "fg_cover_on_hand_open_po_min",
  fgCoverOnHandOpenPOMax: "fg_cover_on_hand_open_po_max",
};

const STOCK_COLUMN_ID_BY_PREFERENCE_NAME: Record<string, string> = Object.fromEntries(
  Object.entries(STOCK_COLUMN_PREFERENCE_NAMES).map(([id, name]) => [name, id]),
);

// section_name <-> STOCK_COLUMN_DEFS group, one section per group.
const STOCK_COLUMN_PREFERENCE_SECTIONS: Array<{
  sectionName: string;
  group: StockColGroup;
}> = [
  { sectionName: "per_component_stock_metrics", group: "metric" },
  { sectionName: "production_plan_fg_summary", group: "extra" },
];

/** GET response -> hiddenStockCols. A fresh/never-saved user (customized
 * false, e.g. a brand new user-preferences row) falls back to the page's
 * hardcoded default (8 of 10 columns visible) rather than trusting an
 * empty/default response body. */
function buildHiddenStockColsFromPreference(
  preference: UserColumnPreferenceResponse | null | undefined,
): string[] {
  if (!preference?.customized) return DEFAULT_HIDDEN_STOCK_COLS;
  const hidden = new Set(STOCK_COLUMN_DEFS.map((col) => col.id));
  for (const section of preference.sections ?? []) {
    const sectionVisible = section.is_visible !== false;
    for (const column of section.columns ?? []) {
      const colId = STOCK_COLUMN_ID_BY_PREFERENCE_NAME[column.name];
      if (!colId) continue;
      if (sectionVisible && column.is_visible) hidden.delete(colId);
    }
  }
  return Array.from(hidden);
}

/** Current hiddenStockCols -> PUT payload. */
function buildStockColumnPreferencePayload(
  userEmail: string,
  hiddenCols: Set<string>,
): UserColumnPreferencePayload {
  return {
    user_email: userEmail,
    screen_id: CBU_DETAIL_COLUMN_PREFS_SCREEN_ID,
    pref_type: "COLUMN",
    sections: STOCK_COLUMN_PREFERENCE_SECTIONS.map(({ sectionName, group }, index) => {
      const cols = STOCK_COLUMN_DEFS.filter((col) => col.group === group);
      return {
        section_name: sectionName,
        priority: index + 1,
        is_visible: true,
        columns: cols.map((col, colIndex) => ({
          name: STOCK_COLUMN_PREFERENCE_NAMES[col.id],
          priority: colIndex + 1,
          is_visible: !hiddenCols.has(col.id),
        })),
      };
    }),
  };
}

export default function CBUDetail({ cbuCode }: Readonly<CbuDetailPageProps>) {
  const { navigate } = useNav();
  const dispatch = useAppDispatch();
  const { accounts } = useMsal();
  const userEmail = accounts?.[0]?.username ?? "test.user@example.com";
  const uom = useAppSelector((s) => s.cbuDetail.uom);
  const {
    row,
    isLoading,
    isError,
    isRowError,
    isDemandError,
    isBreakdownsError,
    isPlantError,
    isPlantFetching,
    uniqueRM,
    uniquePM,
    highContribCount,
    plants,
    clusters,
    plantRows,
    highContribComps,
    uniqueComponents,
    highContribComponents,
    fgTotal,
    demand12,
  } = useCbuDetailData(cbuCode, uom);

  const stockView = useAppSelector((s) => s.cbuDetail.stockView);
  const expandedComponentsList = useAppSelector(
    (s) => s.cbuDetail.expandedComponents,
  );
  const expandedCluster = useAppSelector((s) => s.cbuDetail.expandedCluster);
  const hiddenStockColsList = useAppSelector(
    (s) => s.cbuDetail.hiddenStockCols,
  );
  const expandedComponents = useMemo(
    () => new Set(expandedComponentsList),
    [expandedComponentsList],
  );
  const hiddenStockCols = useMemo(
    () => new Set(hiddenStockColsList),
    [hiddenStockColsList],
  );
  const [productionPlanPlant, setProductionPlanPlant] = useState<string | null>(
    null,
  );

  // Each CBU detail visit should start from a clean slate, matching the
  // page's previous per-mount local-state behaviour.
  useEffect(() => {
    dispatch(resetCbuDetailState());
  }, [dispatch, cbuCode]);

  // Column visibility is a page-level preference, not per-CBU (see
  // resetCbuDetailState's deliberate preservation of hiddenStockCols above)
  // — so this loads once per page mount, not once per cbuCode, unlike the
  // reset effect above.
  const [hasLoadedColumnPreferences, setHasLoadedColumnPreferences] = useState(false);
  useEffect(() => {
    if (!userEmail || hasLoadedColumnPreferences) return;
    let cancelled = false;
    void (async () => {
      try {
        const preference = await fetchUserColumnPreferences(
          userEmail,
          CBU_DETAIL_COLUMN_PREFS_SCREEN_ID,
        );
        if (cancelled) return;
        dispatch(setHiddenStockCols(buildHiddenStockColsFromPreference(preference)));
      } catch {
        // Keep the existing default visibility when the preference lookup fails.
      } finally {
        if (!cancelled) setHasLoadedColumnPreferences(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [dispatch, hasLoadedColumnPreferences, userEmail]);

  async function handleSaveColumnPreferences() {
    if (!userEmail) return false;
    const payload = buildStockColumnPreferencePayload(userEmail, hiddenStockCols);
    try {
      const result = await saveUserColumnPreferences(payload);
      if (result.data) {
        dispatch(setHiddenStockCols(buildHiddenStockColsFromPreference(result.data)));
      }
      toast.success(result.message ?? "Column preferences saved", {
        id: "cbu-detail-column-preferences-save-success",
        style: {
          backgroundColor: "#ecfdf3",
          color: "#166534",
          border: "1px solid #86efac",
        },
      });
      return true;
    } catch (err) {
      const message = err instanceof Error ? err.message : "Unable to save column preferences";
      toast.error(message, { id: "cbu-detail-column-preferences-save-error" });
      return false;
    }
  }

  useEffect(() => {
    if (isRowError) {
      toast.error(CBU_ROW_ERROR_TOAST, { id: "cbu-detail-row-error" });
    }
  }, [isRowError]);

  useEffect(() => {
    if (isDemandError) {
      toast.error(CBU_DEMAND_ERROR_TOAST, { id: "cbu-detail-demand-error" });
    }
  }, [isDemandError]);

  useEffect(() => {
    if (isBreakdownsError) {
      toast.error(CBU_COMPONENT_BREAKDOWNS_ERROR_TOAST, {
        id: "cbu-detail-breakdowns-error",
      });
    }
  }, [isBreakdownsError]);

  useEffect(() => {
    if (isPlantError) {
      toast.error(CBU_PLANT_DATA_ERROR_TOAST, { id: "cbu-detail-plant-error" });
    }
  }, [isPlantError]);

  if (isLoading) return <CbuDetailLoading />;
  if (isError || !row) {
    return <CbuDetailError onBack={() => navigate({ page: "dashboard" })} />;
  }

  const anyOnHandExpanded = expandedComponents.size > 0;
  const isPlantView = stockView === "plant";
  const rowLabels = isPlantView ? plants : clusters;
  const hasRows = rowLabels.length > 0;
  const getMetrics = getRowMetricsGetter(isPlantView, plantRows, uom, demand12);
  const getPlantMetrics = getPlantMetricsGetter(plantRows, uom, demand12);

  const toggleAllOnHandExpanded = () => {
    dispatch(
      setExpandedComponents(
        anyOnHandExpanded ? [] : [...uniqueComponents, ...highContribComponents],
      ),
    );
  };

  const toggleComponentOnHandExpanded = (compCode: string) => {
    dispatch(toggleComponentExpanded(compCode));
  };

  const handleClusterClick = (cluster: string) => {
    dispatch(toggleExpandedCluster(cluster));
  };

  return (
    <div
      className="flex flex-col h-full overflow-hidden"
      style={{ backgroundColor: "#f5f7fa" }}
    >
      <PageTabHeader active="inventory">
        <button
          type="button"
          // title={openSimulationTitle(row.cbuCode)}
          title="Coming Soon"
          disabled
          className="flex items-center gap-1 px-2 py-1 rounded-full font-semibold transition-colors cursor-not-allowed"
          style={{
            backgroundColor: "#EDF5FA",
            color: "#1565C0",
            border: "1px solid #C5CAD3",
            fontSize: 11,
          }}
        >
          <FlaskConical size={12} aria-hidden="true" />
          {OPEN_SIMULATION_LABEL}
        </button>
      </PageTabHeader>

      <div className="flex-1 overflow-y-auto p-5 space-y-4">
        <button
          type="button"
          onClick={() => navigate({ page: "dashboard" })}
          title={BACK_TO_DASHBOARD_TITLE}
          className="flex items-center gap-1 text-xs font-semibold cursor-pointer"
          style={{ color: "#1565C0", background: "transparent", border: "none", padding: 0 }}
        >
          <ChevronLeft size={14} />
          {BACK_TO_DASHBOARD_LABEL}
        </button>

        <CbuDetailHeader cbuCode={row.cbuCode} cbuDescription={row.cbuDescription} />

        <CbuDetailKpiRow
          uniqueRM={uniqueRM}
          uniquePM={uniquePM}
          fgTotal={fgTotal}
          highContribCount={highContribCount}
          highContribComps={highContribComps}
        />

        <div
          className="bg-white rounded-xl p-5"
          style={{ border: "1px solid #e2e8f0" }}
        >
          <StockTableHeader
            isPlantView={isPlantView}
            anyOnHandExpanded={anyOnHandExpanded}
            onToggleOnHand={toggleAllOnHandExpanded}
            uom={uom}
            onUomChange={(id) => dispatch(setUom(id))}
            hiddenCols={hiddenStockCols}
            onHiddenColsChange={(next) => dispatch(setHiddenStockCols(next))}
            onColumnPreferencesDone={handleSaveColumnPreferences}
            isRefreshing={isPlantFetching}
          />

          {hasRows ? (
            <ScrollShadowContainer
              className="overflow-x-auto rounded-lg np-table-scroll"
              style={{ border: "1px solid #e2e8f0" }}
            >
              <StockTable
                row={row}
                uom={uom}
                rowHeader={isPlantView ? "Plant" : "Cluster"}
                rowHeaderSubtext={rowHeaderSubtext(isPlantView)}
                rowLabels={rowLabels}
                plantRows={plantRows}
                uniqueComponents={uniqueComponents}
                getMetrics={getMetrics}
                getPlantMetrics={getPlantMetrics}
                expandedComponents={expandedComponents}
                onToggleComponentExpanded={toggleComponentOnHandExpanded}
                onPlantProductionClick={setProductionPlanPlant}
                clusterDrilldown={!isPlantView}
                allPlants={plants}
                expandedCluster={expandedCluster}
                onClusterClick={handleClusterClick}
                hiddenCols={hiddenStockCols}
                highContribComponents={highContribComponents}
              />
            </ScrollShadowContainer>
          ) : (
            <p className="text-sm italic" style={{ color: "#94a3b8" }}>
              {noRowsMessage(isPlantView)}
            </p>
          )}
        </div>
      </div>

      {productionPlanPlant && (
        <ProductionPlanModal
          plantCode={productionPlanPlant}
          cbuCode={row.cbuCode}
          cbuDescription={row.cbuDescription}
          live
          onClose={() => setProductionPlanPlant(null)}
        />
      )}
    </div>
  );
}
