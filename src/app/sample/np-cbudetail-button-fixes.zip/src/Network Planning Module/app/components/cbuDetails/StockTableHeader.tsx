import { Package, ChevronDown, ChevronRight, Loader2 } from "lucide-react";
import {
  UOM_OPTIONS,
  STOCK_TABLE_HEADER_LABELS,
  stockTableSectionTitle,
  formatUomLabel,
  CLUSTER_DRILLDOWN_HINT,
  onHandToggleTitle,
  UOM_REFRESHING_LABEL,
} from "../../constants/cbuDetail";
import { CbuColumnCustomizer } from "./CbuColumnCustomizer";
import { FilterToggle } from "../FilterDropdown";
import type { UomFilter } from "./types";

// Same {value,label} shape the National Dashboard's own UOM/Material Type
// toggles use — UOM_OPTIONS carries an extra `description` (used nowhere
// else) that FilterToggle's per-segment title doesn't take.
const UOM_TOGGLE_OPTIONS = UOM_OPTIONS.map(({ id, label }) => ({ value: id, label }));

interface Props {
  isPlantView: boolean;
  anyOnHandExpanded: boolean;
  onToggleOnHand: () => void;
  uom: UomFilter;
  onUomChange: (id: UomFilter) => void;
  hiddenCols: Set<string>;
  onHiddenColsChange: (next: string[]) => void;
  /** Called when the column customizer's "Done" button is clicked, e.g. to
   * persist the current column selection to the backend. */
  onColumnPreferencesDone?: () => Promise<boolean | void> | boolean | void;
  /** True while the table's plant/component data is refetching in the
   * background (e.g. right after a UOM toggle) — the table keeps showing
   * its previous figures rather than blanking out, so this is the only
   * visible cue that a refresh is in flight. */
  isRefreshing?: boolean;
}

export function StockTableHeader({
  isPlantView,
  anyOnHandExpanded,
  onToggleOnHand,
  uom,
  onUomChange,
  hiddenCols,
  onHiddenColsChange,
  onColumnPreferencesDone,
  isRefreshing = false,
}: Readonly<Props>) {
  return (
    <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
      <div>
        <div className="flex items-center gap-2">
          <Package size={15} style={{ color: "#1565C0" }} />
          <span
            className="text-xs font-bold tracking-widest uppercase"
            style={{ color: "#1565C0" }}
          >
            {stockTableSectionTitle(isPlantView)}
          </span>
        </div>
        <p className="text-xs mt-1" style={{ color: "#64748b" }}>
          {formatUomLabel(uom)}
          {!isPlantView && CLUSTER_DRILLDOWN_HINT}
        </p>
      </div>
      {/* items-end (not items-center): FilterToggle stacks a small label
          above its pill, so the group is taller than the single-line
          On-Hand/Customise buttons — aligning to the bottom edge instead of
          the vertical center keeps all three pills flush on one line
          regardless of that height difference. */}
      <div className="flex items-end gap-4 flex-wrap">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold" style={{ color: "#374151" }}>
            {STOCK_TABLE_HEADER_LABELS.onHandStock}
          </span>
          <button
            type="button"
            onClick={onToggleOnHand}
            title={onHandToggleTitle(anyOnHandExpanded)}
            className="flex items-center gap-1 px-2 py-1 rounded-full font-medium cursor-pointer transition-colors whitespace-nowrap"
            style={{
              borderWidth: 1,
              borderStyle: "solid",
              borderColor: anyOnHandExpanded ? "#93c5fd" : "#C5CAD3",
              backgroundColor: anyOnHandExpanded ? "#eff6ff" : "#ffffff",
              color: anyOnHandExpanded ? "#1e40af" : "#374151",
              fontSize: 11,
            }}
          >
            {anyOnHandExpanded
              ? STOCK_TABLE_HEADER_LABELS.collapse
              : STOCK_TABLE_HEADER_LABELS.expandBreakdown}
            {anyOnHandExpanded ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
          </button>
        </div>
        <div className="flex items-center gap-2">
          <FilterToggle
            label={STOCK_TABLE_HEADER_LABELS.uom}
            value={uom}
            onChange={(v) => onUomChange(v as UomFilter)}
            activeColor="#1565C0"
            options={UOM_TOGGLE_OPTIONS}
          />
          {isRefreshing && (
            <output
              className="inline-flex items-center gap-1 text-xs"
              style={{ color: "#64748b" }}
              aria-live="polite"
            >
              <Loader2 size={12} className="animate-spin" style={{ color: "#1565C0" }} />
              {UOM_REFRESHING_LABEL}
            </output>
          )}
        </div>
        <CbuColumnCustomizer
          hiddenCols={hiddenCols}
          onChange={onHiddenColsChange}
          onDone={onColumnPreferencesDone}
        />
      </div>
    </div>
  );
}
