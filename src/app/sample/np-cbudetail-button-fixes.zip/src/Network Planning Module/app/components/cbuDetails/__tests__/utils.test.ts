import {
  isOnHandParentColumn,
  isBreakdownColumn,
  getSubColumns,
  colsForComponent,
  getStockColumnTooltip,
  emptyBreakdown,
  plantBaseMetrics,
  plantFgOnHandBreakdown,
  plantFgMetrics,
  getPlantStockMetrics,
  metricsToValues,
  aggregateMetrics,
  getClusterLabels,
  getPlantsForCluster,
  aggregateClusterMetrics,
  getPlantMetricsGetter,
  getRowMetricsGetter,
  getEffRmpmMinMax,
  getPlantProductionPlan,
  getFgAvailableForPlants,
  getFgCoverDatesForPlants,
} from "../utils";
import type { CBURow, AggregatedComponent, PlantComponentRow } from "../../data";

function makePlantRow(overrides: Partial<PlantComponentRow> = {}): PlantComponentRow {
  return {
    plantco: "UTR",
    componentCode: "C1",
    componentMaterialType: "1002",
    conversionFactor: 0.5,
    onHandStock: 100,
    unrestrictedStock: 60,
    qualityStock: 20,
    stvStock: 5,
    blockedStock: 5,
    openPOStock: 10,
    inTransitStock: 2,
    supplierInventory: 3,
    required: 50,
    isSurplus: true,
    ...overrides,
  };
}

function makeRow(overrides: Partial<CBURow> = {}): CBURow {
  return {
    srNo: 1,
    cbuCode: "TESTCODE",
    cbuDescription: "Test CBU 200ML",
    weightKg: 0.2,
    fg: { dcStock: 100, factoryStock: 50, inTransitStock: 20, totalStock: 170 },
    rmpm: {
      physicalStock: 40,
      qualityStock: 10,
      openPOStock: 5,
      totalStock: 55,
      blockedStock: 0,
      supplierInventory: 0,
      inTransitStock: 0,
    },
    rmpmMin: {
      physicalStock: 40,
      qualityStock: 10,
      openPOStock: 5,
      totalStock: 55,
      blockedStock: 0,
      supplierInventory: 0,
      inTransitStock: 0,
    },
    rmpmMax: {
      physicalStock: 40,
      qualityStock: 10,
      openPOStock: 5,
      totalStock: 55,
      blockedStock: 0,
      supplierInventory: 0,
      inTransitStock: 0,
    },
    demand: { sumNext3TDP: 30, next6Months: 100, next12Months: 200 },
    totalFG: 170,
    cover: { fgCoverDate: "N/A", totalCoverDate: "N/A", coverExclOpenPO: "N/A" },
    ...overrides,
  };
}

function makeComponent(overrides: Partial<AggregatedComponent> = {}): AggregatedComponent {
  return {
    componentCode: "C1",
    componentMaterialType: "1002",
    unrestrictedStock: 10,
    qualityStock: 2,
    blockedStock: 0,
    totalStock: 12,
    openPOStock: 3,
    ...overrides,
  };
}

describe("isOnHandParentColumn / isBreakdownColumn", () => {
  it("only column 0 is the on-hand parent, and only when expanded", () => {
    expect(isOnHandParentColumn(0, true)).toBe(true);
    expect(isOnHandParentColumn(1, true)).toBe(false);
    expect(isOnHandParentColumn(0, false)).toBe(false);
  });

  it("breakdown columns span 1..ON_HAND_BREAKDOWN_COUNT when expanded", () => {
    expect(isBreakdownColumn(1, true)).toBe(true);
    expect(isBreakdownColumn(4, true)).toBe(true);
    expect(isBreakdownColumn(5, true)).toBe(false);
    expect(isBreakdownColumn(1, false)).toBe(false);
  });
});

describe("getSubColumns / colsForComponent", () => {
  it("always starts with On hand stock and ends with the total column when cover is hidden", () => {
    const cols = getSubColumns(false, new Set(["cover"]));
    expect(cols[0]).toBe("On hand stock");
    expect(cols.at(-1)).toBe("Total FG equivalent RM PM stock");
  });

  it("appends FG Cover (Date) after the total column when cover is shown", () => {
    const cols = getSubColumns(false, new Set());
    expect(cols.at(-2)).toBe("Total FG equivalent RM PM stock");
    expect(cols.at(-1)).toBe("FG Cover (Date)");
  });

  it("inserts the breakdown columns right after On hand stock when expanded", () => {
    const collapsed = getSubColumns(false, new Set());
    const expanded = getSubColumns(true, new Set());
    expect(expanded.length).toBe(collapsed.length + 4);
    expect(expanded[1]).toBe("Unrestricted Stock");
  });

  it("omits optional metric columns that are hidden", () => {
    const cols = getSubColumns(false, new Set(["openPO", "inTransit", "supplier"]));
    expect(cols).not.toContain("Open PO");
    expect(cols).not.toContain("In transit");
    expect(cols).not.toContain("Supplier inventory");
  });

  it("omits the cover column when 'cover' is hidden", () => {
    const withCover = getSubColumns(false, new Set());
    const withoutCover = getSubColumns(false, new Set(["cover"]));
    expect(withCover).toContain("FG Cover (Date)");
    expect(withoutCover).not.toContain("FG Cover (Date)");
  });

  it("colsForComponent matches getSubColumns length", () => {
    expect(colsForComponent(true, new Set())).toBe(getSubColumns(true, new Set()).length);
  });
});

describe("getStockColumnTooltip", () => {
  it("returns the configured tooltip for a known label", () => {
    expect(getStockColumnTooltip("Open PO")).toContain("open purchase orders");
  });

  it("returns an empty string for an unknown label", () => {
    expect(getStockColumnTooltip("Nonexistent")).toBe("");
  });
});

describe("emptyBreakdown", () => {
  it("returns all-zero fields", () => {
    expect(emptyBreakdown()).toEqual({
      unrestricted: 0,
      quality: 0,
      stv: 0,
      blocked: 0,
      total: 0,
    });
  });
});

describe("plantBaseMetrics", () => {
  it("returns zeroed metrics when no plant row is given", () => {
    const result = plantBaseMetrics(undefined, 1000);
    expect(result.onHand).toBe(0);
    expect(result.total).toBe(0);
  });

  it("uses onHandStock directly when positive", () => {
    const pr = makePlantRow({ onHandStock: 80, openPOStock: 20 });
    const result = plantBaseMetrics(pr, 1000);
    expect(result.onHand).toBe(80);
    expect(result.total).toBe(80 + 20 + pr.inTransitStock + pr.supplierInventory);
  });

  it("computes demand as demand12M scaled by conversionFactor", () => {
    const pr = makePlantRow({ conversionFactor: 0.5 });
    const result = plantBaseMetrics(pr, 1000);
    expect(result.demand).toBe(500);
  });

  it("carries the plant row's own fgCoverDate through", () => {
    const pr = makePlantRow({ fgCoverDate: "2026-08-11" });
    const result = plantBaseMetrics(pr, 1000);
    expect(result.fgCoverDate).toBe("2026-08-11");
  });
});

describe("plantFgOnHandBreakdown / plantFgMetrics", () => {
  it("uses fg* fields directly when present", () => {
    const pr = makePlantRow({
      fgUnrestrictedStock: 100,
      fgQualityStock: 20,
      fgStvStock: 0,
      fgBlockedStock: 0,
    });
    const breakdown = plantFgOnHandBreakdown(pr);
    expect(breakdown.total).toBe(120);
  });

  it("falls back to converting base-unit fields via conversionFactor", () => {
    const pr = makePlantRow({
      conversionFactor: 0.5,
      unrestrictedStock: 50,
      qualityStock: 0,
      stvStock: 0,
      blockedStock: 0,
      fgUnrestrictedStock: undefined,
      fgQualityStock: undefined,
      fgStvStock: undefined,
      fgBlockedStock: undefined,
    });
    const breakdown = plantFgOnHandBreakdown(pr);
    // toFgEquivalent(50, 0.5) = round(50 / 0.5) = 100
    expect(breakdown.unrestricted).toBe(100);
  });

  it("plantFgMetrics returns fgPhysicalStock as onHand when present", () => {
    const pr = makePlantRow({ fgPhysicalStock: 300, fgOpenPOStock: 40 });
    const result = plantFgMetrics(pr, 1000);
    expect(result.onHand).toBe(300);
    expect(result.openPO).toBe(40);
  });

  it("carries the plant row's own fgCoverDate through, on both the fg* and derived branches", () => {
    const withFg = plantFgMetrics(
      makePlantRow({ fgPhysicalStock: 300, fgCoverDate: "2026-08-11" }),
      1000,
    );
    expect(withFg.fgCoverDate).toBe("2026-08-11");

    const derived = plantFgMetrics(
      makePlantRow({ fgPhysicalStock: undefined, fgOpenPOStock: undefined, fgCoverDate: "2026-09-01" }),
      1000,
    );
    expect(derived.fgCoverDate).toBe("2026-09-01");
  });

  it("prefers the API's totalFGEquivalentRMPMStock over the client-computed sum", () => {
    const pr = makePlantRow({
      fgPhysicalStock: 300,
      fgOpenPOStock: 40,
      inTransitStock: 0,
      supplierInventory: 0,
      totalFGEquivalentRMPMStock: 999,
    });
    const result = plantFgMetrics(pr, 1000);
    // 300 + 40 + 0 + 0 = 340, which would be the fallback sum — the API's
    // own 999 must win instead.
    expect(result.total).toBe(999);
  });

  it("falls back to the computed sum when totalFGEquivalentRMPMStock is absent", () => {
    const pr = makePlantRow({
      fgPhysicalStock: 300,
      fgOpenPOStock: 40,
      inTransitStock: 0,
      supplierInventory: 0,
      totalFGEquivalentRMPMStock: undefined,
    });
    const result = plantFgMetrics(pr, 1000);
    expect(result.total).toBe(340);
  });
});

describe("getPlantStockMetrics", () => {
  it("uses base (RM/PM) metrics for RMPM uom", () => {
    const pr = makePlantRow({ onHandStock: 100 });
    const result = getPlantStockMetrics(pr, "RMPM", 1000);
    expect(result.onHand).toBe(100);
  });

  it("uses FG-equivalent metrics for EA/MT uom", () => {
    const pr = makePlantRow({ fgPhysicalStock: 250 });
    const result = getPlantStockMetrics(pr, "EA", 1000);
    expect(result.onHand).toBe(250);
  });
});

describe("metricsToValues", () => {
  const metrics = {
    onHand: 10,
    onHandBreakdown: { unrestricted: 4, quality: 3, stv: 2, blocked: 1, total: 10 },
    openPO: 5,
    inTransit: 6,
    supplier: 7,
    total: 28,
    demand: 100,
  };

  it("includes onHand and total but not the breakdown when collapsed", () => {
    const values = metricsToValues(metrics, false, new Set());
    expect(values).toEqual([10, 5, 6, 7, 28]);
  });

  it("expands into unrestricted/quality/stv/blocked when expanded", () => {
    const values = metricsToValues(metrics, true, new Set());
    expect(values).toEqual([10, 4, 3, 2, 1, 5, 6, 7, 28]);
  });

  it("omits hidden optional columns", () => {
    const values = metricsToValues(metrics, false, new Set(["openPO", "supplier"]));
    expect(values).toEqual([10, 6, 28]);
  });
});

describe("aggregateMetrics", () => {
  it("sums additive fields but takes the max for total", () => {
    const a = { onHand: 10, onHandBreakdown: emptyBreakdown(), openPO: 1, inTransit: 0, supplier: 0, total: 20, demand: 50 };
    const b = { onHand: 20, onHandBreakdown: emptyBreakdown(), openPO: 2, inTransit: 0, supplier: 0, total: 35, demand: 50 };
    const result = aggregateMetrics([a, b]);
    expect(result.onHand).toBe(30);
    expect(result.total).toBe(35);
    expect(result.demand).toBe(50);
  });

  it("returns zeroed totals for an empty list", () => {
    const result = aggregateMetrics([]);
    expect(result.onHand).toBe(0);
    expect(result.total).toBe(0);
  });

  it("does not carry a single plant's fgCoverDate forward into an aggregate", () => {
    const a = {
      onHand: 10,
      onHandBreakdown: emptyBreakdown(),
      openPO: 1,
      inTransit: 0,
      supplier: 0,
      total: 20,
      demand: 50,
      fgCoverDate: "2026-08-11",
    };
    const result = aggregateMetrics([a]);
    expect(result.fgCoverDate).toBeUndefined();
  });
});

describe("getClusterLabels / getPlantsForCluster", () => {
  it("maps plant codes to their cluster and orders by CLUSTER_DISPLAY_ORDER", () => {
    // UTR -> Haridwar, ULU -> Lotus — both are real clusters and must surface.
    const clusters = getClusterLabels(["UTR", "ULU"]);
    expect(clusters).toContain("Haridwar");
    expect(clusters).toContain("Lotus");
  });

  it("still surfaces a plant whose cluster isn't in the fixed display order", () => {
    const clusters = getClusterLabels(["UNMAPPEDPLANT"]);
    expect(clusters).toContain("UNMAPPEDPLANT");
  });

  it("returns an empty array for no plants", () => {
    expect(getClusterLabels([])).toEqual([]);
  });

  it("getPlantsForCluster filters plants belonging to a cluster", () => {
    const plants = getPlantsForCluster("Haridwar", ["UTR", "UAQ", "UNKNOWNPLANT"]);
    expect(plants).toContain("UTR");
    expect(plants).not.toContain("UAQ");
  });
});

describe("aggregateClusterMetrics", () => {
  it("aggregates metrics only for plants within the given cluster and component", () => {
    const rows = [
      makePlantRow({ plantco: "UTR", componentCode: "C1", onHandStock: 50 }),
      makePlantRow({ plantco: "UAQ", componentCode: "C1", onHandStock: 999 }),
    ];
    const result = aggregateClusterMetrics("Haridwar", "C1", rows, "RMPM", 1000);
    expect(result.onHand).toBe(50);
  });
});

describe("getPlantMetricsGetter / getRowMetricsGetter", () => {
  it("getPlantMetricsGetter resolves metrics for a specific plant + component", () => {
    const rows = [makePlantRow({ plantco: "UTR", componentCode: "C1", onHandStock: 77 })];
    const getter = getPlantMetricsGetter(rows, "RMPM", 1000);
    expect(getter("UTR", "C1").onHand).toBe(77);
    expect(getter("UNKNOWN", "C1").onHand).toBe(0);
  });

  it("getRowMetricsGetter switches between plant and cluster aggregation", () => {
    const rows = [makePlantRow({ plantco: "UTR", componentCode: "C1", onHandStock: 77 })];
    const plantGetter = getRowMetricsGetter(true, rows, "RMPM", 1000);
    expect(plantGetter("UTR", "C1").onHand).toBe(77);

    const clusterGetter = getRowMetricsGetter(false, rows, "RMPM", 1000);
    expect(clusterGetter("Haridwar", "C1").onHand).toBe(77);
  });
});

describe("getEffRmpmMinMax", () => {
  it("returns min and max as the sum of every passed component's stock — getEffRmpmMinMax always selects everything, so min and max agree once components are loaded (computeEffRmpm sums selected components rather than bounding by their peak)", () => {
    const row = makeRow();
    const comps = [
      makeComponent({ componentCode: "A", unrestrictedStock: 10 }),
      makeComponent({ componentCode: "B", unrestrictedStock: 100 }),
    ];
    const { min, max } = getEffRmpmMinMax(comps, [], row);
    expect(min.physicalStock).toBe(110);
    expect(max.physicalStock).toBe(110);
  });
});

describe("getFgAvailableForPlants", () => {
  it("sums totalFGAtPlant across every plant in the list, deduping by plant", () => {
    const rows = [
      makePlantRow({ plantco: "UTR", componentCode: "C1", totalFGAtPlant: 100 }),
      makePlantRow({ plantco: "UTR", componentCode: "C2", totalFGAtPlant: 100 }),
      makePlantRow({ plantco: "UUB", componentCode: "C1", totalFGAtPlant: 50 }),
    ];
    expect(getFgAvailableForPlants(["UTR"], rows)).toBe(100);
    expect(getFgAvailableForPlants(["UTR", "UUB"], rows)).toBe(150);
  });

  it("treats a plant with no matching row as 0", () => {
    const rows = [makePlantRow({ plantco: "UTR", totalFGAtPlant: 100 })];
    expect(getFgAvailableForPlants(["UNKNOWN"], rows)).toBe(0);
  });
});

describe("getFgCoverDatesForPlants", () => {
  it("returns the single plant's dates unchanged", () => {
    const rows = [
      makePlantRow({
        plantco: "UTR",
        fgCoverDateOnHandOnlyMin: "2026-08-04",
        fgCoverDateOnHandOnlyMax: "2026-08-04",
        fgCoverDateOnHandPlusOpenPOMin: "2026-09-01",
        fgCoverDateOnHandPlusOpenPOMax: "2026-09-10",
      }),
    ];
    expect(getFgCoverDatesForPlants(["UTR"], rows)).toEqual({
      onHandOnlyMin: "2026-08-04",
      onHandOnlyMax: "2026-08-04",
      onHandPlusOpenPOMin: "2026-09-01",
      onHandPlusOpenPOMax: "2026-09-10",
    });
  });

  it("rolls up Min to the earliest and Max to the latest date across plants", () => {
    const rows = [
      makePlantRow({
        plantco: "UTR",
        fgCoverDateOnHandPlusOpenPOMin: "2026-09-10",
        fgCoverDateOnHandPlusOpenPOMax: "2026-10-01",
      }),
      makePlantRow({
        plantco: "UUB",
        fgCoverDateOnHandPlusOpenPOMin: "2026-08-04",
        fgCoverDateOnHandPlusOpenPOMax: "2026-11-15",
      }),
    ];
    const result = getFgCoverDatesForPlants(["UTR", "UUB"], rows);
    expect(result.onHandPlusOpenPOMin).toBe("2026-08-04");
    expect(result.onHandPlusOpenPOMax).toBe("2026-11-15");
  });

  it("ignores null dates when rolling up, and returns all-null when the plant list is empty", () => {
    const rows = [
      makePlantRow({ plantco: "UTR", fgCoverDateOnHandOnlyMin: null, fgCoverDateOnHandOnlyMax: null }),
      makePlantRow({ plantco: "UUB", fgCoverDateOnHandOnlyMin: "2026-08-04", fgCoverDateOnHandOnlyMax: "2026-08-04" }),
    ];
    const result = getFgCoverDatesForPlants(["UTR", "UUB"], rows);
    expect(result.onHandOnlyMin).toBe("2026-08-04");
    expect(result.onHandOnlyMax).toBe("2026-08-04");

    expect(getFgCoverDatesForPlants([], rows)).toEqual({
      onHandOnlyMin: null,
      onHandOnlyMax: null,
      onHandPlusOpenPOMin: null,
      onHandPlusOpenPOMax: null,
    });
  });
});

describe("getPlantProductionPlan", () => {
  it("returns 0 when there is no demand", () => {
    expect(getPlantProductionPlan("UTR", 1, 0)).toBe(0);
  });

  it("returns a positive figure bounded by demand for positive demand", () => {
    const value = getPlantProductionPlan("UTR", 1, 100000);
    expect(value).toBeGreaterThan(0);
    expect(value).toBeLessThan(100000);
  });

  it("is deterministic for the same inputs", () => {
    expect(getPlantProductionPlan("UTR", 5, 50000)).toBe(getPlantProductionPlan("UTR", 5, 50000));
  });
});
