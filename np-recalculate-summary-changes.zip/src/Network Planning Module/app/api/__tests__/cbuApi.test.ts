import {
  fetchPlants,
  fetchCbuComponents,
  fetchPlantComponents,
  fetchProductionPlan,
  fetchCbuListPaged,
  fetchCbuFilters,
  searchCbuFilters,
  fetchCbuExport,
  saveUserColumnPreferences,
  fetchStockBreakdownFromApi,
  recalculateCbuSummary,
  mapCbuListRowToCBURow,
  CbuApiError,
} from "../cbuApi";
import { getApiHeaders } from "../apiHeaders";
import type {
  PlantsResponse,
  CbuComponentsResponse,
  ComponentsByPlantResponse,
  ProductionPlanResponse,
  CBUListResponse,
  DcStockBreakdownResponse,
  FactoryStockBreakdownResponse,
  InTransitBreakdownResponse,
  CbuRecalculateSummaryRequest,
  CbuRecalculateSummaryResponse,
} from "../../components/nationalDashboard/apiTypes";
import type { CBURow } from "../../components/data";

const API_BASE =
  "https://bnlwe-af01-q-930839-unilevercom-webapp-03-cngrhthyaacgdbhn.westeurope-01.azurewebsites.net/api";
const PLANTS_URL = `${API_BASE}/v1/plants`;

beforeEach(() => {
  global.fetch = jest.fn();
});

afterEach(() => {
  jest.restoreAllMocks();
});

describe("fetchPlants", () => {
  it("requests /v1/plants with the shared API headers", async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve([]),
    });

    await fetchPlants();

    expect(global.fetch).toHaveBeenCalledWith(PLANTS_URL, {
      headers: getApiHeaders(),
    });
  });

  it("returns the parsed plant list on success", async () => {
    const mockPlants: PlantsResponse = [
      { code: "PATH", name: "Pathankot", cluster: "North" },
      { code: "NCRH", name: "NCR Hub", cluster: "North" },
    ];
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve(mockPlants),
    });

    const result = await fetchPlants();

    expect(result).toEqual(mockPlants);
  });

  it("returns an empty array when the API sends no plants", async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve([]),
    });

    const result = await fetchPlants();

    expect(result).toEqual([]);
  });

  it("throws a CbuApiError with a generic message on a non-422 error status", async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: false,
      status: 500,
    });

    await expect(fetchPlants()).rejects.toMatchObject({
      name: "CbuApiError",
      status: 500,
      message: "API error 500: /api/v1/plants",
    });
  });

  it("parses FastAPI-style validation detail on a 422 response", async () => {
    const detail = [
      { loc: ["query", "page"], msg: "field required", type: "missing" },
    ];
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: false,
      status: 422,
      json: () => Promise.resolve({ detail }),
    });

    let caught: CbuApiError | undefined;
    try {
      await fetchPlants();
    } catch (e) {
      caught = e as CbuApiError;
    }

    expect(caught).toBeInstanceOf(CbuApiError);
    expect(caught?.status).toBe(422);
    expect(caught?.validation).toEqual(detail);
    expect(caught?.message).toBe("query.page: field required");
  });

  it("falls back to a generic 422 message when the error body is unparseable", async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: false,
      status: 422,
      json: () => Promise.reject(new Error("not json")),
    });

    await expect(fetchPlants()).rejects.toMatchObject({
      status: 422,
      message: "Validation error: /api/v1/plants",
    });
  });

  it("propagates a network failure without wrapping it", async () => {
    (global.fetch as jest.Mock).mockRejectedValueOnce(new Error("Network error"));

    await expect(fetchPlants()).rejects.toThrow("Network error");
  });
});

describe("saveUserColumnPreferences", () => {
  it("uses PUT with the full preference payload for the column preference endpoint", async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      text: () => Promise.resolve(""),
    });

    const payload = {
      user_email: "test.user@example.com",
      screen_id: "cbu_national_view",
      pref_type: "COLUMN" as const,
      sections: [
        {
          section_name: "product_info",
          priority: 1,
          is_visible: true,
          columns: [
            { name: "cbu", priority: 1, is_visible: true },
            { name: "cbu_description", priority: 2, is_visible: true },
          ],
        },
      ],
    };

    await saveUserColumnPreferences(payload);

    expect(global.fetch).toHaveBeenCalledWith(
      `${API_BASE}/v1/np/user-preferences?${new URLSearchParams({
        user_email: payload.user_email,
        screen_id: payload.screen_id,
        pref_type: payload.pref_type,
      }).toString()}`,
      {
        method: "PUT",
        headers: getApiHeaders(),
        body: JSON.stringify(payload),
      },
    );
  });
});

describe("fetchCbuComponents", () => {
  it("requests /v1/cbus/{cbuCode}/components with the shared API headers", async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve([]),
    });

    await fetchCbuComponents("VAFA1R");

    expect(global.fetch).toHaveBeenCalledWith(
      `${API_BASE}/v1/cbus/VAFA1R/components`,
      { headers: getApiHeaders() },
    );
  });

  it("URL-encodes the CBU code", async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve([]),
    });

    await fetchCbuComponents("VAF A1R/X");

    expect(global.fetch).toHaveBeenCalledWith(
      `${API_BASE}/v1/cbus/VAF%20A1R%2FX/components`,
      { headers: getApiHeaders() },
    );
  });

  it("maps the wire response into AggregatedComponent shape", async () => {
    const wire: CbuComponentsResponse = [
      {
        componentCode: "65284824",
        componentMaterialType: "1002",
        componentDescription: "Mineral Oil Base",
        unrestrictedStock: 100,
        qualityStock: 20,
        blockedStock: 5,
        totalStock: 125,
        openPOStock: 30,
      },
    ];
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve(wire),
    });

    const result = await fetchCbuComponents("VAFA1R");

    expect(result).toEqual([
      {
        componentCode: "65284824",
        componentMaterialType: "1002",
        componentDescription: "Mineral Oil Base",
        unrestrictedStock: 100,
        qualityStock: 20,
        blockedStock: 5,
        totalStock: 125,
        openPOStock: 30,
        contributionType: null,
      },
    ]);
  });

  it("maps contribution_type into contributionType, even on the unfiltered call", async () => {
    const wire: CbuComponentsResponse = [
      {
        componentCode: "62726821",
        componentMaterialType: "1002",
        componentDescription: "JAR 1KGCH HLX_Icon+VBL",
        unrestrictedStock: 0,
        qualityStock: 0,
        blockedStock: 0,
        totalStock: 51282392,
        openPOStock: 51282392,
        contribution_type: "high-contributer",
      },
    ];
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve(wire),
    });

    const result = await fetchCbuComponents("VAFA1R");

    expect(result[0]).toMatchObject({ contributionType: "high-contributer" });
  });

  it("returns an empty array when the CBU has no components", async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve([]),
    });

    const result = await fetchCbuComponents("VAFA1R");

    expect(result).toEqual([]);
  });

  it("throws a CbuApiError with the CBU-specific endpoint path on failure", async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: false,
      status: 500,
    });

    await expect(fetchCbuComponents("VAFA1R")).rejects.toMatchObject({
      name: "CbuApiError",
      status: 500,
      message: "API error 500: /api/v1/cbus/VAFA1R/components",
    });
  });
});

describe("fetchPlantComponents", () => {
  const row = { cbuCode: "VAFA1R" } as CBURow;

  it("maps rows plus the CBU-level KPI counts from the wire response", async () => {
    const wire: ComponentsByPlantResponse = {
      plants: ["UUB"],
      uniqueRMComponents: 0,
      uniquePMComponents: 2,
      highContributingComponents: 10,
      rows: [
        {
          plantco: "UUB",
          componentCode: "68819916",
          componentMaterialType: "1003",
          conversionFactor: 1.0,
          onHandStock: 0.0,
          unrestrictedStock: 0.0,
          qualityStock: 0.0,
          stvStock: 0.0,
          blockedStock: 0.0,
          openPOStock: 80102.8671875,
          inTransitStock: 0.0,
          supplierInventory: 0.0,
          fgPhysicalStock: 0.0,
          fgOpenPOStock: 80102.8671875,
          fgUnrestrictedStock: 0.0,
          fgQualityStock: 0.0,
          fgStvStock: 0.0,
          fgBlockedStock: 0.0,
          required: 0.0,
          isSurplus: true,
          totalFGAtPlant: 0.0,
          productionPlan: 0.0,
          fgCoverDateOnHandOnlyMin: "2026-08-04",
          fgCoverDateOnHandOnlyMax: "2026-08-04",
          fgCoverDateOnHandPlusOpenPOMin: null,
          fgCoverDateOnHandPlusOpenPOMax: null,
        },
      ],
    };
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve(wire),
    });

    const result = await fetchPlantComponents(row);

    expect(global.fetch).toHaveBeenCalledWith(
      `${API_BASE}/v1/cbus/VAFA1R/components-by-plant?demand12M=0&uom=EA`,
      { headers: getApiHeaders() },
    );
    expect(result.plants).toEqual(["UUB"]);
    expect(result.uniqueRMComponents).toBe(0);
    expect(result.uniquePMComponents).toBe(2);
    expect(result.highContributingComponents).toBe(10);
    expect(result.rows).toEqual([
      expect.objectContaining({
        plantco: "UUB",
        componentCode: "68819916",
        totalFGAtPlant: 0,
        fgCoverDateOnHandOnlyMin: "2026-08-04",
        fgCoverDateOnHandOnlyMax: "2026-08-04",
        fgCoverDateOnHandPlusOpenPOMin: null,
        fgCoverDateOnHandPlusOpenPOMax: null,
      }),
    ]);
  });

  it("maps the page's MT uom to the wire's TON, and defaults to EA when omitted", async () => {
    (global.fetch as jest.Mock).mockResolvedValue({
      ok: true,
      json: () => Promise.resolve({ plants: [], rows: [], uniqueRMComponents: 0, uniquePMComponents: 0, highContributingComponents: 0 }),
    });

    await fetchPlantComponents(row, "MT");
    expect(global.fetch).toHaveBeenLastCalledWith(
      `${API_BASE}/v1/cbus/VAFA1R/components-by-plant?demand12M=0&uom=TON`,
      { headers: getApiHeaders() },
    );

    await fetchPlantComponents(row);
    expect(global.fetch).toHaveBeenLastCalledWith(
      `${API_BASE}/v1/cbus/VAFA1R/components-by-plant?demand12M=0&uom=EA`,
      { headers: getApiHeaders() },
    );
  });

  it("defaults null numeric fields and missing KPI counts to 0", async () => {
    const wire = {
      plants: [],
      rows: [
        {
          plantco: "UUB",
          componentCode: "C1",
          componentMaterialType: "1003",
          conversionFactor: null,
          onHandStock: null,
          unrestrictedStock: null,
          qualityStock: null,
          stvStock: null,
          blockedStock: null,
          openPOStock: null,
          inTransitStock: null,
          supplierInventory: null,
          fgPhysicalStock: null,
          fgOpenPOStock: null,
          fgUnrestrictedStock: null,
          fgQualityStock: null,
          fgStvStock: null,
          fgBlockedStock: null,
          required: null,
          isSurplus: false,
          totalFGAtPlant: null,
          fgCoverDateOnHandOnlyMin: null,
          fgCoverDateOnHandOnlyMax: null,
          fgCoverDateOnHandPlusOpenPOMin: null,
          fgCoverDateOnHandPlusOpenPOMax: null,
        },
      ],
    } as unknown as ComponentsByPlantResponse;
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve(wire),
    });

    const result = await fetchPlantComponents(row);

    expect(result.uniqueRMComponents).toBe(0);
    expect(result.uniquePMComponents).toBe(0);
    expect(result.highContributingComponents).toBe(0);
    expect(result.rows[0]).toMatchObject({
      conversionFactor: 0,
      onHandStock: 0,
      totalFGAtPlant: 0,
    });
  });

  it("throws a CbuApiError with the CBU-specific endpoint path on failure", async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: false,
      status: 500,
    });

    await expect(fetchPlantComponents(row)).rejects.toMatchObject({
      name: "CbuApiError",
      status: 500,
      message: "API error 500: /api/v1/cbus/VAFA1R/components-by-plant",
    });
  });
});

describe("fetchProductionPlan", () => {
  it("requests /v1/cbus/production-plan with cbuCode/plantCode as query params", async () => {
    const wire: ProductionPlanResponse = {
      cbuCode: "NMAD1R8",
      plantCode: "UUB",
      totalProduction: 724428,
      peakWeek: 7,
      peakWeekProductionValue: 41818,
      avgWeek: 38128,
      activeWeeks: 19,
      weeklyProduction: [
        { week: 1, label: "W1", production: 34477, isPeakWeek: false },
        { week: 7, label: "W7", production: 41818, isPeakWeek: true },
      ],
    };
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve(wire),
    });

    const result = await fetchProductionPlan("NMAD1R8", "UUB");

    expect(global.fetch).toHaveBeenCalledWith(
      `${API_BASE}/v1/cbus/production-plan?cbuCode=NMAD1R8&plantCode=UUB`,
      { headers: getApiHeaders() },
    );
    expect(result).toEqual(wire);
  });

  it("throws a CbuApiError with the production-plan endpoint path on failure", async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: false,
      status: 500,
    });

    await expect(fetchProductionPlan("NMAD1R8", "UUB")).rejects.toMatchObject({
      name: "CbuApiError",
      status: 500,
      message: "API error 500: /api/v1/cbus/production-plan",
    });
  });

  it("surfaces FastAPI-style validation detail on a 422 response", async () => {
    const detail = [
      { loc: ["query", "plantCode"], msg: "field required", type: "missing" },
    ];
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: false,
      status: 422,
      json: () => Promise.resolve({ detail }),
    });

    await expect(fetchProductionPlan("NMAD1R8", "")).rejects.toMatchObject({
      name: "CbuApiError",
      status: 422,
      validation: detail,
    });
  });
});

describe("fetchCbuListPaged", () => {
  const emptyResponse: CBUListResponse = { count: 0, page: 1, pageSize: 20, data: [] };

  it("sends highContributing=false explicitly when the toggle is off, not omitted", async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve(emptyResponse),
    });

    await fetchCbuListPaged({
      page: 1,
      pageSize: 20,
      uom: "EA",
      highContributing: false,
      sortBy: "cbuCode",
      sortOrder: "asc",
    });

    expect(global.fetch).toHaveBeenCalledWith(
      `${API_BASE}/v1/cbus?page=1&pageSize=20&uom=EA&highContributing=false&sortBy=cbuCode&sortOrder=asc`,
      { headers: getApiHeaders() },
    );
  });

  it("sends highContributing=true when the toggle is on", async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve(emptyResponse),
    });

    await fetchCbuListPaged({
      page: 1,
      pageSize: 20,
      uom: "EA",
      highContributing: true,
      sortBy: "cbuCode",
      sortOrder: "asc",
    });

    expect(global.fetch).toHaveBeenCalledWith(
      `${API_BASE}/v1/cbus?page=1&pageSize=20&uom=EA&highContributing=true&sortBy=cbuCode&sortOrder=asc`,
      { headers: getApiHeaders() },
    );
  });

  it("sends a multi-select filter as repeated query params", async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve(emptyResponse),
    });

    await fetchCbuListPaged({
      page: 1,
      pageSize: 20,
      bg: ["BG1", "BG2"],
      uom: "EA",
      highContributing: false,
    });

    expect(global.fetch).toHaveBeenCalledWith(
      `${API_BASE}/v1/cbus?page=1&pageSize=20&bg=BG1&bg=BG2&uom=EA&highContributing=false`,
      { headers: getApiHeaders() },
    );
  });

  it("omits a filter dimension entirely when its selection is empty", async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve(emptyResponse),
    });

    await fetchCbuListPaged({
      page: 1,
      pageSize: 20,
      bg: [],
      uom: "EA",
      highContributing: false,
    });

    expect(global.fetch).toHaveBeenCalledWith(
      `${API_BASE}/v1/cbus?page=1&pageSize=20&uom=EA&highContributing=false`,
      { headers: getApiHeaders() },
    );
  });

  it("sends every dropdown filter as repeated params when multi-selected together", async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve(emptyResponse),
    });

    await fetchCbuListPaged({
      page: 1,
      pageSize: 20,
      cbu: ["c1", "c2"],
      basePack: ["string", "s2"],
      smallC: ["string1", "string111"],
      bg: ["string1111"],
      format: ["string1111"],
      brand: ["string111111111"],
      material: ["string111111"],
      uom: "EA",
      highContributing: false,
      sortBy: "cbuCode",
      sortOrder: "asc",
    });

    expect(global.fetch).toHaveBeenCalledWith(
      `${API_BASE}/v1/cbus?page=1&pageSize=20&material=string111111&cbu=c1&cbu=c2&basePack=string&basePack=s2&smallC=string1&smallC=string111&bg=string1111&format=string1111&brand=string111111111&uom=EA&highContributing=false&sortBy=cbuCode&sortOrder=asc`,
      { headers: getApiHeaders() },
    );
  });
});

describe("fetchCbuExport", () => {
  it("sends multi-select filters as repeated params, same as the list endpoint", async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      blob: () => Promise.resolve(new Blob(["data"])),
      headers: { get: () => null },
    });

    await fetchCbuExport({
      cbu: ["c1", "c2"],
      bg: ["BG1", "BG2"],
      uom: "EA",
      highContributing: false,
    });

    expect(global.fetch).toHaveBeenCalledWith(
      `${API_BASE}/v1/cbus/export?cbu=c1&cbu=c2&bg=BG1&bg=BG2&uom=EA&highContributing=false`,
      { headers: getApiHeaders() },
    );
  });
});

describe("fetchCbuFilters", () => {
  const mockGroup = {
    name: "bg",
    totalCount: 10,
    allSelected: false,
    page: 1,
    pageSize: 100,
    hasMore: false,
    options: [
      { value: "BG1", label: "BG1", count: 6, disabled: false, code: "BG1", description: "BG1" },
      { value: "BG2", label: "BG2", count: 0, disabled: true, code: "BG2", description: "BG2" },
    ],
  };
  const mockResponse = {
    bg: mockGroup,
    smallC: mockGroup,
    format: mockGroup,
    brand: mockGroup,
    material: mockGroup,
    cbu: mockGroup,
    basePack: mockGroup,
    basePackDescription: mockGroup,
  };

  it("requests /v1/cbus/filters with no params when nothing is selected", async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve(mockResponse),
    });

    await fetchCbuFilters({});

    expect(global.fetch).toHaveBeenCalledWith(`${API_BASE}/v1/cbus/filters`, {
      headers: getApiHeaders(),
    });
  });

  it("sends the full current multi-select state as repeated params across dimensions", async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve(mockResponse),
    });

    await fetchCbuFilters({
      bg: ["BG1", "BG2"],
      smallC: ["Small1"],
      brand: ["string"],
    });

    expect(global.fetch).toHaveBeenCalledWith(
      `${API_BASE}/v1/cbus/filters?bg=BG1&bg=BG2&smallC=Small1&brand=string`,
      { headers: getApiHeaders() },
    );
  });

  it("sends materialCode/cbuCode selections as the wire's material/cbu params, plus page/pageSize", async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve(mockResponse),
    });

    await fetchCbuFilters({
      materialCode: ["Mat desc"],
      cbuCode: ["CBU desc"],
      page: 2,
      pageSize: 100,
    });

    expect(global.fetch).toHaveBeenCalledWith(
      `${API_BASE}/v1/cbus/filters?material=Mat+desc&cbu=CBU+desc&page=2&pageSize=100`,
      { headers: getApiHeaders() },
    );
  });

  it("returns the parsed group shape (options with count/disabled/code/description, page/pageSize/hasMore) on success", async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve(mockResponse),
    });

    const result = await fetchCbuFilters({});

    expect(result.bg).toEqual(mockGroup);
  });
});

describe("searchCbuFilters", () => {
  const mockSearchResponse = {
    filter_name: "cbu",
    search: "Bru",
    total_count: 1,
    page: 1,
    page_size: 50,
    has_more: false,
    options: [
      {
        value: "CBU1001: Bru Instant Coffee 50g",
        label: "CBU1001: Bru Instant Coffee 50g",
        count: 1,
        disabled: false,
        code: "CBU1001",
        description: "Bru Instant Coffee 50g",
      },
    ],
  };

  it("POSTs the filter name, search text, selections, and pagination to /v1/cbus/filters/search", async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve(mockSearchResponse),
    });

    const payload = {
      filter_name: "cbu" as const,
      search: "Bru",
      selections: {
        bg: [],
        smallC: [],
        format: [],
        brand: [],
        material: [],
        cbu: [],
        basePack: [],
        basePackDescription: [],
      },
      page: 1,
      pageSize: 50,
    };
    await searchCbuFilters(payload);

    expect(global.fetch).toHaveBeenCalledWith(`${API_BASE}/v1/cbus/filters/search`, {
      method: "POST",
      headers: getApiHeaders(),
      body: JSON.stringify(payload),
    });
  });

  it("returns the parsed search response (total_count/page/has_more/options) on success", async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve(mockSearchResponse),
    });

    const result = await searchCbuFilters({
      filter_name: "cbu",
      search: "Bru",
      selections: {
        bg: [],
        smallC: [],
        format: [],
        brand: [],
        material: [],
        cbu: [],
        basePack: [],
        basePackDescription: [],
      },
      page: 1,
      pageSize: 50,
    });

    expect(result).toEqual(mockSearchResponse);
  });

  it("throws a CbuApiError on a non-ok response", async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: false,
      status: 500,
      json: () => Promise.resolve(null),
    });

    await expect(
      searchCbuFilters({
        filter_name: "bg",
        search: "x",
        selections: {
          bg: [],
          smallC: [],
          format: [],
          brand: [],
          material: [],
          cbu: [],
          basePack: [],
          basePackDescription: [],
        },
        page: 1,
        pageSize: 50,
      }),
    ).rejects.toThrow(CbuApiError);
  });
});

describe("fetchStockBreakdownFromApi", () => {
  it("requests /v1/cbus/{cbuCode}/stock-breakdown with stock_type and uom for a dc kind", async () => {
    const wire: DcStockBreakdownResponse = {
      cbu_code: "VAFA1R",
      stock_type: "DC_STOCK",
      uom: "EA",
      summary: { total_stock: "0", active_locations_count: 0 },
      count: 0,
      data: [],
    };
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve(wire),
    });

    await fetchStockBreakdownFromApi("VAFA1R", "dc", "EA");

    expect(global.fetch).toHaveBeenCalledWith(
      `${API_BASE}/v1/cbus/VAFA1R/stock-breakdown?stock_type=DC_STOCK&uom=EA`,
      { headers: getApiHeaders() },
    );
  });

  it("maps the MT uom to the wire's TON for factory kind", async () => {
    const wire: FactoryStockBreakdownResponse = {
      cbu_code: "VAFA1R",
      stock_type: "FACTORY_STOCK",
      uom: "TON",
      summary: { total_stock: "0", active_locations_count: 0 },
      count: 0,
      data: [],
    };
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve(wire),
    });

    await fetchStockBreakdownFromApi("VAFA1R", "factory", "MT");

    expect(global.fetch).toHaveBeenCalledWith(
      `${API_BASE}/v1/cbus/VAFA1R/stock-breakdown?stock_type=FACTORY_STOCK&uom=TON`,
      { headers: getApiHeaders() },
    );
  });

  it("computes totalStockExclInTransit from unrestricted+quality+blocked, not the wire's own total (bug 32007)", async () => {
    const wire: DcStockBreakdownResponse = {
      cbu_code: "VAFA1R",
      stock_type: "DC_STOCK",
      uom: "EA",
      summary: { total_stock: "0", active_locations_count: 1 },
      count: 1,
      data: [
        {
          stock_type: "DC_STOCK",
          dc_code: "UUB",
          uom: "EA",
          unrestricted: "10",
          quality: "5",
          blocked: "2",
          // The API is seen sending "0.0000" here for rows that clearly
          // hold stock — this must not be trusted for the mapped total.
          total_excl_in_transit: "0.0000",
        },
      ],
    };
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve(wire),
    });

    const result = await fetchStockBreakdownFromApi("VAFA1R", "dc", "EA");

    expect(result).toEqual([
      {
        plantCode: "UUB",
        baseUom: "EA",
        unrestrictedStock: 10,
        qualityStock: 5,
        blockedStock: 2,
        totalStockExclInTransit: 15,
        plantOrDc: "DC",
      },
    ]);
  });

  it("falls back to plant_code and tags rows as Plant for factory kind", async () => {
    const wire: FactoryStockBreakdownResponse = {
      cbu_code: "VAFA1R",
      stock_type: "FACTORY_STOCK",
      uom: "EA",
      summary: { total_stock: "0", active_locations_count: 1 },
      count: 1,
      data: [
        {
          stock_type: "FACTORY_STOCK",
          plant_code: "PATH",
          uom: "EA",
          unrestricted: "1",
          quality: "0",
          blocked: "0",
          total_excl_in_transit: "1",
        },
      ],
    };
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve(wire),
    });

    const result = await fetchStockBreakdownFromApi("VAFA1R", "factory", "EA");

    expect(result).toEqual([
      {
        plantCode: "PATH",
        baseUom: "EA",
        unrestrictedStock: 1,
        qualityStock: 0,
        blockedStock: 0,
        totalStockExclInTransit: 1,
        plantOrDc: "Plant",
      },
    ]);
  });

  it("maps in-transit rows by route, using total_in_transit for both stock fields", async () => {
    const wire: InTransitBreakdownResponse = {
      cbu_code: "VAFA1R",
      stock_type: "IN_TRANSIT",
      uom: "EA",
      summary: { total_stock: "0", active_locations_count: 1 },
      count: 1,
      data: [
        {
          stock_type: "IN_TRANSIT",
          route: "UUB->PATH",
          source: "UUB",
          destination: "PATH",
          uom: "EA",
          total_in_transit: "42",
        },
      ],
    };
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve(wire),
    });

    const result = await fetchStockBreakdownFromApi("VAFA1R", "transit", "EA");

    expect(result).toEqual([
      {
        plantCode: "UUB->PATH",
        baseUom: "EA",
        unrestrictedStock: 42,
        qualityStock: 0,
        blockedStock: 0,
        totalStockExclInTransit: 42,
        plantOrDc: "Route",
      },
    ]);
  });

  it("returns an empty array when the CBU has no stock at any location", async () => {
    const wire: DcStockBreakdownResponse = {
      cbu_code: "VAFA1R",
      stock_type: "DC_STOCK",
      uom: "EA",
      summary: { total_stock: "0", active_locations_count: 0 },
      count: 0,
      data: [],
    };
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve(wire),
    });

    const result = await fetchStockBreakdownFromApi("VAFA1R", "dc", "EA");

    expect(result).toEqual([]);
  });

  it("throws a CbuApiError with the stock-breakdown endpoint path on failure", async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: false,
      status: 500,
    });

    await expect(
      fetchStockBreakdownFromApi("VAFA1R", "dc", "EA"),
    ).rejects.toMatchObject({
      name: "CbuApiError",
      status: 500,
      message: "API error 500: /api/v1/cbus/VAFA1R/stock-breakdown",
    });
  });
});

describe("recalculateCbuSummary", () => {
  const payload: CbuRecalculateSummaryRequest = {
    cbuCode: "CBU1001",
    selectedRmpmCodes: [],
    deselectedRmpmCodes: ["RM2001", "RM2005"],
    uom: "EA",
    contributionType: "high-contributing",
  };

  // Full CbuListRow shape — same row shape GET /api/v1/cbus returns per CBU,
  // confirmed against a live response rather than the narrower Min/Max-only
  // slice the endpoint's own description implies.
  const mockWireRow: CbuRecalculateSummaryResponse = {
    slNo: 0,
    cbuCode: "CBU1001",
    cbuDescription: "Bru Instant Coffee 50g",
    weightKg: 0.05,
    basepack: "BP1",
    basepackDescription: "50g Pouch",
    smallC: "SC1",
    bg: "BG1",
    format: "Pouch",
    brand: "Bru",
    fg: {
      uom: "EA",
      dcStock: 200,
      factoryStock: 100,
      inTransitStock: 0,
      totalStock: 300,
      blockedStock: 0,
      dcBlockedStock: 0,
      factoryBlockedStock: 0,
    },
    rmpmMin: {
      uom: "EA",
      physicalStock: 100,
      qualityStock: 0,
      openPOStock: 0,
      blockedStock: 0,
      supplierInventory: 0,
      inTransitStock: 0,
      totalStock: 100,
      stvStock: 0,
    },
    rmpmMax: {
      uom: "EA",
      physicalStock: 150,
      qualityStock: 0,
      openPOStock: 0,
      blockedStock: 0,
      supplierInventory: 0,
      inTransitStock: 0,
      totalStock: 150,
      stvStock: 0,
    },
    demand: { sumNext3TDP: 1000, next6Months: 5000, next12Months: 9000 },
    totalFGMin: { totalFG: 500, totalFGDays: 10 },
    totalFGMax: { totalFG: 650, totalFGDays: 13 },
    coverMin: {
      fgCoverDate: "2026-09-18",
      totalCoverDate: "2026-09-20",
      coverExcludingOpenPO: "2026-09-15",
    },
    coverMax: {
      fgCoverDate: "2026-09-21",
      totalCoverDate: "2026-09-23",
      coverExcludingOpenPO: "2026-09-18",
    },
  };

  it("POSTs cbuCode/selected/deselected RMPM codes/uom/contributionType to /v1/cbus/recalculate/summary", async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve(mockWireRow),
    });

    await recalculateCbuSummary(payload);

    expect(global.fetch).toHaveBeenCalledWith(`${API_BASE}/v1/cbus/recalculate/summary`, {
      method: "POST",
      headers: getApiHeaders(),
      body: JSON.stringify(payload),
    });
  });

  it("returns the recalculated row mapped into a CBURow, same as the list endpoint", async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: () => Promise.resolve(mockWireRow),
    });

    const result = await recalculateCbuSummary(payload);

    expect(result).toEqual(mapCbuListRowToCBURow(mockWireRow));
    expect(result.cbuCode).toBe("CBU1001");
    expect(result.fg.totalStock).toBe(300);
    expect(result.rmpmMax.physicalStock).toBe(150);
  });

  it("throws a CbuApiError with the recalculate-summary endpoint path on failure", async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: false,
      status: 500,
    });

    await expect(recalculateCbuSummary(payload)).rejects.toMatchObject({
      name: "CbuApiError",
      status: 500,
      message: "API error 500: /api/v1/cbus/recalculate/summary",
    });
  });

  it("throws a CbuApiError with parsed validation detail on a 422 response", async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: false,
      status: 422,
      json: () =>
        Promise.resolve({
          detail: [{ loc: ["body", "cbuCode"], msg: "field required", type: "value_error" }],
        }),
    });

    await expect(recalculateCbuSummary(payload)).rejects.toMatchObject({
      name: "CbuApiError",
      status: 422,
      message: "body.cbuCode: field required",
    });
  });
});
