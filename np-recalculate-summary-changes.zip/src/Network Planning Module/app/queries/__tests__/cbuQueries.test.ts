import { useQuery, useMutation } from "@tanstack/react-query";
import {
  usePlantsQuery,
  plantQueryKeys,
  useCbuComponentsQuery,
  cbuQueryKeys,
  useRecalculateCbuSummaryMutation,
} from "../cbuQueries";
import { fetchPlants, fetchCbuComponents, recalculateCbuSummary } from "../../api/cbuApi";
import type { CbuRecalculateSummaryRequest } from "../../components/nationalDashboard/apiTypes";

jest.mock("@tanstack/react-query", () => ({
  ...jest.requireActual("@tanstack/react-query"),
  useQuery: jest.fn(),
  useMutation: jest.fn(),
}));

jest.mock("../../api/cbuApi", () => ({
  ...jest.requireActual("../../api/cbuApi"),
  fetchPlants: jest.fn(),
  fetchCbuComponents: jest.fn(),
  recalculateCbuSummary: jest.fn(),
}));

const mockUseQuery = useQuery as jest.Mock;
const mockUseMutation = useMutation as jest.Mock;

beforeEach(() => {
  jest.clearAllMocks();
});

describe("plantQueryKeys", () => {
  it("builds a stable, namespaced list key", () => {
    expect(plantQueryKeys.all).toEqual(["plants"]);
    expect(plantQueryKeys.list()).toEqual(["plants", "list"]);
  });
});

describe("usePlantsQuery", () => {
  it("queries with the plants list key and fetchPlants as the query function", () => {
    mockUseQuery.mockReturnValue({ data: undefined, isLoading: true });

    usePlantsQuery();

    expect(mockUseQuery).toHaveBeenCalledTimes(1);
    const call = mockUseQuery.mock.calls[0][0];
    expect(call.queryKey).toEqual(plantQueryKeys.list());
    expect(call.queryFn).toBe(fetchPlants);
    // Same long stale time as useCbuFiltersQuery — plant master data changes rarely.
    expect(call.staleTime).toBe(10 * 60_000);
  });

  it("returns whatever useQuery resolves (react-query passthrough)", () => {
    const mockPlants = [{ code: "PATH", name: "Pathankot", cluster: "North" }];
    mockUseQuery.mockReturnValue({ data: mockPlants, isLoading: false });

    const { data, isLoading } = usePlantsQuery();

    expect(data).toEqual(mockPlants);
    expect(isLoading).toBe(false);
  });
});

describe("useCbuComponentsQuery", () => {
  it("is disabled and keys off an empty cbuCode when none is given", () => {
    mockUseQuery.mockReturnValue({ data: undefined, isLoading: false });

    useCbuComponentsQuery(undefined);

    const call = mockUseQuery.mock.calls[0][0];
    expect(call.queryKey).toEqual(cbuQueryKeys.components(""));
    expect(call.enabled).toBe(false);
  });

  it("enables the query and keys off the given cbuCode once set", () => {
    mockUseQuery.mockReturnValue({ data: undefined, isLoading: true });

    useCbuComponentsQuery("VAFA1R");

    const call = mockUseQuery.mock.calls[0][0];
    expect(call.queryKey).toEqual(cbuQueryKeys.components("VAFA1R"));
    expect(call.enabled).toBe(true);
  });

  it("calls fetchCbuComponents with the given cbuCode when the query function runs", () => {
    mockUseQuery.mockReturnValue({ data: undefined, isLoading: true });

    useCbuComponentsQuery("VAFA1R");

    const call = mockUseQuery.mock.calls[0][0];
    call.queryFn();
    expect(fetchCbuComponents).toHaveBeenCalledWith("VAFA1R");
  });

  it("returns whatever useQuery resolves (react-query passthrough)", () => {
    const mockComponents = [{ componentCode: "C1", componentMaterialType: "1002" }];
    mockUseQuery.mockReturnValue({ data: mockComponents, isLoading: false });

    const { data, isLoading } = useCbuComponentsQuery("VAFA1R");

    expect(data).toEqual(mockComponents);
    expect(isLoading).toBe(false);
  });
});

describe("useRecalculateCbuSummaryMutation", () => {
  it("wires recalculateCbuSummary as the mutation function", () => {
    mockUseMutation.mockReturnValue({ mutate: jest.fn(), isPending: false });

    useRecalculateCbuSummaryMutation();

    expect(mockUseMutation).toHaveBeenCalledTimes(1);
    const call = mockUseMutation.mock.calls[0][0];

    const payload: CbuRecalculateSummaryRequest = {
      cbuCode: "CBU1001",
      selectedRmpmCodes: [],
      deselectedRmpmCodes: ["RM2001", "RM2005"],
      uom: "EA",
      contributionType: "high-contributing",
    };
    call.mutationFn(payload);
    expect(recalculateCbuSummary).toHaveBeenCalledWith(payload);
  });

  it("returns whatever useMutation resolves (react-query passthrough)", () => {
    const mutate = jest.fn();
    mockUseMutation.mockReturnValue({ mutate, isPending: true });

    const { mutate: returnedMutate, isPending } = useRecalculateCbuSummaryMutation();

    expect(returnedMutate).toBe(mutate);
    expect(isPending).toBe(true);
  });
});
