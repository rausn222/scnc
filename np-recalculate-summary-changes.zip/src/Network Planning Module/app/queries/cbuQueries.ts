import { useQuery, useMutation, keepPreviousData } from "@tanstack/react-query";
import {
  fetchCbuByCode,
  fetchCbuBySrNo,
  fetchCbuComponents,
  fetchCbuFilters,
  fetchCbuList,
  fetchCbuListForDashboard,
  fetchComponentBreakdowns,
  fetchDemandData,
  fetchForecastDemandBreakdown,
  fetchLastRefreshTime,
  fetchPlantComponents,
  fetchPlants,
  fetchProductionPlan,
  fetchStockBreakdownFromApi,
  recalculateCbuSummary,
} from "../api/cbuApi";
import type { CBURow } from "../components/data";
import type {
  CbuFiltersQueryParams,
  CbuListQueryParams,
  CbuRecalculateSummaryRequest,
  ForecastDemandViewType,
} from "../components/nationalDashboard/apiTypes";

// How long cached data is considered fresh before a refetch is allowed to
// happen at all (on mount, refocus, or interval tick).
const STALE_TIME_MS = 60_000;

// Filter option lists change far less often than the row data itself —
// a longer stale time avoids refetching them on every focus/mount.
const FILTERS_STALE_TIME_MS = 10 * 60_000;

// The last-refresh timestamp is shown passively in the tab header - polling
// every 5 minutes keeps it current without needing a page reload, without
// hammering the endpoint like the table's own 60s stale time would.
const LAST_REFRESH_POLL_MS = 5 * 60_000;

// How long an unused (not currently selected) filter combination's response
// stays in react-query's cache before being garbage-collected. Sibling-aware
// faceted search means every distinct selection is its own cache entry
// (see cbuQueryKeys.filters) — a long gcTime means toggling back to a
// combination visited earlier in the session serves instantly from cache
// instead of re-hitting the slow /cbus/filters endpoint, even once that
// entry has gone stale (react-query still shows stale cached data instantly,
// then revalidates in the background).
const FILTERS_GC_TIME_MS = 30 * 60_000;

/** Opt-in polling — off by default so pages that don't need it (CBU Detail,
 * the SCI CBU search dropdown) keep their existing fetch-once behaviour. */
interface QueryRefreshOptions {
  refetchInterval?: number;
}

export const cbuQueryKeys = {
  all: ["cbu"] as const,
  list: () => [...cbuQueryKeys.all, "list"] as const,
  listPaged: (params: CbuListQueryParams) =>
    [...cbuQueryKeys.all, "listPaged", params] as const,
  detail: (srNo: number) => [...cbuQueryKeys.all, "detail", srNo] as const,
  detailByCode: (cbuCode: string) =>
    [...cbuQueryKeys.all, "detailByCode", cbuCode] as const,
  componentBreakdowns: (srNos: number[]) =>
    [...cbuQueryKeys.all, "componentBreakdowns", srNos] as const,
  components: (cbuCode: string) =>
    [...cbuQueryKeys.all, "components", cbuCode] as const,
  highContributingComponents: (cbuCode: string) =>
    [...cbuQueryKeys.all, "highContributingComponents", cbuCode] as const,
  demand: (cbuCode: string) => [...cbuQueryKeys.all, "demand", cbuCode] as const,
  forecastDemand: (
    cbuCode: string,
    period: "3tdp" | "6m" | "12m",
    uom: "EA" | "MT",
    viewType: ForecastDemandViewType,
  ) =>
    [...cbuQueryKeys.all, "forecastDemand", cbuCode, period, uom, viewType] as const,
  // Keyed by cbuCode, not srNo — see fetchCbuByCode's comment in cbuApi.ts:
  // srNo comes from a page=1&pageSize=1 lookup for the CBU Detail page, so
  // it's always the same value (the single row's rank of 1) for every CBU,
  // which previously collided every CBU's plant-components/stock-breakdown
  // query onto the same cache entry and served stale data across CBUs.
  stockBreakdown: (
    kind: "dc" | "factory" | "transit",
    cbuCode: string,
    uom: "EA" | "MT",
  ) => [...cbuQueryKeys.all, "stockBreakdown", kind, cbuCode, uom] as const,
  plantComponents: (cbuCode: string, uom: "EA" | "MT") =>
    [...cbuQueryKeys.all, "plantComponents", cbuCode, uom] as const,
  productionPlan: (cbuCode: string, plantCode: string) =>
    [...cbuQueryKeys.all, "productionPlan", cbuCode, plantCode] as const,
  filters: (params: CbuFiltersQueryParams) =>
    [...cbuQueryKeys.all, "filters", params] as const,
  lastRefresh: () => [...cbuQueryKeys.all, "lastRefresh"] as const,
};

export const plantQueryKeys = {
  all: ["plants"] as const,
  list: () => [...plantQueryKeys.all, "list"] as const,
};

export function useCbuListQuery(options?: QueryRefreshOptions) {
  return useQuery({
    queryKey: cbuQueryKeys.list(),
    queryFn: fetchCbuList,
    staleTime: STALE_TIME_MS,
    refetchInterval: options?.refetchInterval,
    refetchIntervalInBackground: false,
  });
}

/**
 * GET /api/v1/cbus, server-driven pagination/sort/filter for the National
 * Dashboard table — every page/rowsPerPage/sort/search/dropdown-filter
 * change refetches with the corresponding query params. `placeholderData:
 * keepPreviousData` keeps the current page rendered (rather than flashing a
 * loading state) while the next page's request is in flight.
 */
export function useCbuListPagedQuery(
  params: CbuListQueryParams,
  options?: QueryRefreshOptions,
) {
  return useQuery({
    queryKey: cbuQueryKeys.listPaged(params),
    queryFn: () => fetchCbuListForDashboard(params),
    staleTime: STALE_TIME_MS,
    placeholderData: keepPreviousData,
    refetchInterval: options?.refetchInterval,
    refetchIntervalInBackground: false,
  });
}

/** Feeds the National Dashboard toolbar's dropdown options — sibling-aware
 * faceted search, so it refetches on every filter selection change (params
 * is the full current multi-select state, see NationalDashboard.tsx).
 * `placeholderData: keepPreviousData` keeps the previous options/counts
 * shown while the next combination loads, instead of flashing empty. */
export function useCbuFiltersQuery(params: CbuFiltersQueryParams) {
  return useQuery({
    queryKey: cbuQueryKeys.filters(params),
    queryFn: () => fetchCbuFilters(params),
    staleTime: FILTERS_STALE_TIME_MS,
    gcTime: FILTERS_GC_TIME_MS,
    placeholderData: keepPreviousData,
  });
}

export function useCbuDetailQuery(srNo: number | undefined) {
  return useQuery({
    queryKey: cbuQueryKeys.detail(srNo ?? -1),
    queryFn: () => fetchCbuBySrNo(srNo),
    enabled: srNo != null,
    staleTime: STALE_TIME_MS,
  });
}

/** GET /api/v1/cbus?cbu=<code>&page=1&pageSize=1 — real-API row lookup for
 * the CBU Detail page, keyed by cbuCode rather than srNo (see fetchCbuByCode
 * in cbuApi.ts for why). */
export function useCbuDetailByCodeQuery(cbuCode: string | undefined) {
  return useQuery({
    queryKey: cbuQueryKeys.detailByCode(cbuCode ?? ""),
    queryFn: () => fetchCbuByCode(cbuCode),
    enabled: cbuCode != null,
    staleTime: STALE_TIME_MS,
  });
}

/** Batched component breakdown (RM/PM + high-contributing) for the given CBU rows. */
export function useComponentBreakdownsQuery(
  rows: CBURow[],
  options?: QueryRefreshOptions,
) {
  const srNos = rows.map((r) => r.srNo);
  return useQuery({
    queryKey: cbuQueryKeys.componentBreakdowns(srNos),
    queryFn: () => fetchComponentBreakdowns(rows),
    enabled: rows.length > 0,
    staleTime: STALE_TIME_MS,
    refetchInterval: options?.refetchInterval,
    refetchIntervalInBackground: false,
  });
}

/** GET /api/v1/cbus/{cbu_code}/components — real per-component (RM/PM)
 * breakdown for a single CBU, fetched on demand when its National Dashboard
 * row is expanded (enabled only while cbuCode is set). */
export function useCbuComponentsQuery(cbuCode: string | undefined) {
  return useQuery({
    queryKey: cbuQueryKeys.components(cbuCode ?? ""),
    queryFn: () => fetchCbuComponents(cbuCode),
    enabled: cbuCode != null,
    staleTime: STALE_TIME_MS,
  });
}

/** GET /api/v1/cbus/{cbu_code}/components?contributionType=high-contributer
 * — the separately-sourced "High Contributing" component set, fetched only
 * while the High Contributing toggle is on. Toggling it on (or expanding a
 * different row while it's already on) flips `enabled`/the cbuCode segment
 * of the query key, which is what makes react-query issue a fresh request
 * with the latest response rather than reusing stale data. */
export function useCbuHighContributingComponentsQuery(
  cbuCode: string | undefined,
  enabled: boolean,
) {
  return useQuery({
    queryKey: cbuQueryKeys.highContributingComponents(cbuCode ?? ""),
    queryFn: () => fetchCbuComponents(cbuCode, "high-contributer"),
    enabled: cbuCode != null && enabled,
    staleTime: STALE_TIME_MS,
  });
}

export function useDemandQuery(cbuCode: string | undefined) {
  return useQuery({
    queryKey: cbuQueryKeys.demand(cbuCode ?? ""),
    queryFn: () => fetchDemandData(cbuCode),
    enabled: cbuCode != null,
    staleTime: STALE_TIME_MS,
  });
}

/** GET /api/v1/cbus/{cbu_code}/forecast-demand-breakdown — backs the Demand
 * modal (Next 3 TDP / Next 6 Months / Next 12 Months), refetching on the
 * period tab, UOM toggle, or Book Month/MOC view change. */
export function useForecastDemandQuery(
  cbuCode: string | undefined,
  period: "3tdp" | "6m" | "12m",
  uom: "EA" | "MT",
  viewType: ForecastDemandViewType,
) {
  return useQuery({
    queryKey: cbuQueryKeys.forecastDemand(cbuCode ?? "", period, uom, viewType),
    queryFn: () =>
      fetchForecastDemandBreakdown(cbuCode, period, uom, viewType),
    enabled: cbuCode != null,
    staleTime: STALE_TIME_MS,
  });
}

/** GET /api/v1/cbus/{cbu_code}/stock-breakdown — backs the "FG Stock Across
 * All Locations" popup (DC / Factory / In-Transit), refetching on UOM toggle. */
export function useStockBreakdownQuery(
  kind: "dc" | "factory" | "transit",
  row: CBURow | null,
  uom: "EA" | "MT",
) {
  return useQuery({
    queryKey: cbuQueryKeys.stockBreakdown(kind, row?.cbuCode ?? "", uom),
    queryFn: () => fetchStockBreakdownFromApi(row.cbuCode, kind, uom),
    enabled: row != null,
    staleTime: STALE_TIME_MS,
  });
}

/** `placeholderData: keepPreviousData` keeps the table showing its current
 * (EA or TON) figures while the other unit's request is in flight, rather
 * than dropping the whole page into a loading state on every UOM toggle —
 * uom is part of the query key, so without this each toggle would look like
 * a first-ever fetch (no cached data yet for that key). */
export function usePlantComponentsQuery(
  row: CBURow | null | undefined,
  uom: "EA" | "MT" = "EA",
) {
  return useQuery({
    queryKey: cbuQueryKeys.plantComponents(row?.cbuCode ?? "", uom),
    queryFn: () => fetchPlantComponents(row, uom),
    enabled: row != null,
    staleTime: STALE_TIME_MS,
    placeholderData: keepPreviousData,
  });
}

/** GET /api/v1/cbus/production-plan — backs the CBU Detail page's Production
 * Plan breakdown popup, fetched on demand once a plant's "Production plan"
 * cell is clicked (enabled only while plantCode is set). */
export function useProductionPlanQuery(
  cbuCode: string | undefined,
  plantCode: string | null,
) {
  return useQuery({
    queryKey: cbuQueryKeys.productionPlan(cbuCode ?? "", plantCode ?? ""),
    queryFn: () => fetchProductionPlan(cbuCode, plantCode),
    enabled: cbuCode != null && plantCode != null,
    staleTime: STALE_TIME_MS,
  });
}

/** GET /api/v1/plants — plant master list (code/name/cluster). Not consumed
 * anywhere yet; changes rarely, so it gets the same long stale time as
 * useCbuFiltersQuery. */
export function usePlantsQuery() {
  return useQuery({
    queryKey: plantQueryKeys.list(),
    queryFn: fetchPlants,
    staleTime: FILTERS_STALE_TIME_MS,
  });
}

/** GET /api/v1/cbus/last-refresh - backs the "Last Refreshed" label next to
 * the tabs (PageTabHeader). */
export function useLastRefreshQuery() {
  return useQuery({
    queryKey: cbuQueryKeys.lastRefresh(),
    queryFn: fetchLastRefreshTime,
    staleTime: LAST_REFRESH_POLL_MS,
    refetchInterval: LAST_REFRESH_POLL_MS,
    refetchIntervalInBackground: false,
  });
}

/**
 * POST /api/v1/cbus/recalculate/summary — recalculates a CBU row's RMPM
 * FG-equivalent stock, FG summary, and cover dates after the user
 * selects/deselects RMPM codes. A mutation rather than a query: it's fired
 * imperatively on each checkbox change instead of being derived from stable
 * params, so there's nothing to cache/key. Call `.mutate(payload)` (or
 * `.mutateAsync(payload)`) from the toggle handler once this is wired in.
 */
export function useRecalculateCbuSummaryMutation() {
  return useMutation({
    mutationFn: (payload: CbuRecalculateSummaryRequest) =>
      recalculateCbuSummary(payload),
  });
}
