import { Fragment, useMemo, useState, useEffect, useRef, lazy, Suspense } from "react";
import { useMsal } from "@azure/msal-react";
import { motion } from "motion/react";
import { toast } from "sonner";
import { type CBURow, type AggregatedComponent, isHighContributingType,} from "../components/data";
import {
  CbuApiError,
  fetchCbuExport,
  fetchCbuFilters,
  fetchUserColumnPreferences,
  saveUserColumnPreferences,
  searchCbuFilters,
  toApiUom,
  type UserColumnPreferencePayload,
  type UserColumnPreferenceResponse,
} from "../api/cbuApi";
import type {
  CbuExportQueryParams,
  CbuFilterGroupKey,
  CbuFilterOption,
  CbuFiltersQueryParams,
  CbuListQueryParams,
  CbuRecalculateContributionType,
  MultiFilterId,
} from "../components/nationalDashboard/apiTypes";
import { Loader } from "../components/Loader";
import { PageTabHeader } from "../components/PageTabHeader";
import { TableSkeleton } from "../components/TableSkeleton";
import { ALL_FILTER_DEFINITIONS, MoreFiltersPanel, type FilterId,} from "../components/MoreFiltersPanel";
import { FilterDropdown, FilterToggle, type FilterOption } from "../components/FilterDropdown";
import { useNav } from "../App";
import { RefreshCw, Download, Search, AlertTriangle, FilterX } from "lucide-react";
import {
  ALL_COLS,
  W_SR,
  REFRESH_BUTTON_TITLE,
  EXPORT_BUTTON_TITLE,
  SEARCH_PLACEHOLDER,
  SEARCH_TOOLTIP,
  HIGH_CONTRIBUTING_LABEL,
  highContributingToggleTitle,
  LOADING_TEXT,
  ERROR_TEXT,
  NO_CBU_DATA_MESSAGE,
  NO_SEARCH_RESULTS_MESSAGE,
  CLEAR_FILTERS_LABEL,
  DASHBOARD_REFETCH_INTERVAL_MS,
  CBU_LIST_ERROR_TOAST,
  COMPONENT_BREAKDOWNS_ERROR_TOAST,
  EXPORT_ERROR_TOAST,
  RECALCULATE_SUMMARY_ERROR_TOAST,
  MATERIAL_TYPE_FILTER_OPTIONS,
  UOM_FILTER_OPTIONS,
  MATERIAL_TYPE_TOGGLE_OPTIONS,
  UOM_TOGGLE_OPTIONS,
} from "../constants/nationalDashboard";
import type { ColumnGroup, TypeFilter, UomFilter,} from "../components/nationalDashboard/types";
import { buildOrderedCols, compareSortValues, computeGroupRuns, getRowSortValue, metaColsWidth,} from "../components/nationalDashboard/utils";
import { TableHintsBar } from "../components/nationalDashboard/TableHintsBar";
import { TablePagination } from "../components/nationalDashboard/TablePagination";
import { ColumnCustomizer } from "../components/nationalDashboard/ColumnCustomizer";
import { DashboardTable } from "../components/nationalDashboard/DashboardTable";
import { useCbuComponentsQuery, useCbuFiltersQuery, useCbuHighContributingComponentsQuery, useCbuListPagedQuery, useRecalculateCbuSummaryMutation } from "../queries/cbuQueries";
import { useAppDispatch, useAppSelector } from "../store/hooks";
import {
  setColOrderByGroup, setDropdownFilter, setExpandedSrNo, setFilterOrder, setGroupOrder, setHiddenCols,
  setHiddenGroups, setPage, setRowsPerPage, setSearch, setSelectedComponentsForRow, setSort,
  setVisibleFilters, toggleSelectedComponent, toggleShowHighContributing, resetFilters,
} from "../store/slices/nationalDashboardSlice";

// Modals are only needed once the user opens one, and DemandModal pulls in
// the recharts charting library — split both out of the initial page chunk.
const DemandModal = lazy(() =>
  import("../components/DemandModal").then((m) => ({ default: m.DemandModal })),
);
const StockLocationBreakdownModal = lazy(() =>
  import("../components/StockLocationBreakdownModal").then((m) => ({
    default: m.StockLocationBreakdownModal,
  })),
);

const MODAL_LOADER_FALLBACK = (
  <div
    className="fixed inset-0 z-50 flex items-center justify-center"
    style={{ backgroundColor: "rgba(0,48,135,0.18)", backdropFilter: "blur(4px)" }}
  >
    <Loader fullHeight={false} />
  </div>
);

/** Bridges a Redux-backed value to the `useState`-shaped setter APIs that
 * MoreFiltersPanel / ColumnCustomizer expect, so those shared components
 * don't need to know their state now lives in the store. */
function toStateSetter<T>(
  current: T,
  onChange: (next: T) => void,
): React.Dispatch<React.SetStateAction<T>> {
  return (action) => {
    const next =
      typeof action === "function"
        ? (action as (prev: T) => T)(current)
        : action;
    onChange(next);
  };
}

function isAllSentinel(value: string): boolean {
  return value.trim().toUpperCase() === "ALL";
}

function formatDataAsOf(timestamp: number): string {
  if (!timestamp) return "—";
  const d = new Date(timestamp);
  return `${String(d.getDate()).padStart(2, "0")}-${d.toLocaleString("en", { month: "short" })}-${d.getFullYear()}`;
}

function mapColumnIdToPreferenceName(columnId: string): string {
  const aliases: Record<string, string> = {
    cbuCode: "cbu",
    cbuDescription: "cbu_description",
    basePack: "basepack",
    basePackDescription: "basepack_description",
    smallC: "small_c",
    bg: "bg",
    format: "format",
    fg_dc: "dc_stock",
    fg_factory: "factory_stock",
    fg_intransit: "in_transit",
    fg_total: "total_stock",
    rmpm_physical: "physical_stock",
    rmpm_quality: "quality_stock",
    rmpm_stv: "stv_stock",
    rmpm_openpo: "open_po_stock",
    rmpm_intransit: "in_transit",
    rmpm_supplier: "supplier_inventory",
    rmpm_total: "total_stock",
    rmpm_blocked: "blocked_stock",
    rmpmMin_physical: "physical_stock",
    rmpmMin_quality: "quality_stock",
    rmpmMin_stv: "stv_stock",
    rmpmMin_openpo: "open_po_stock",
    rmpmMin_intransit: "in_transit",
    rmpmMin_supplier: "supplier_inventory",
    rmpmMin_total: "total_stock",
    rmpmMin_blocked: "blocked_stock",
    demand_3tdp: "next_3_tdp",
    demand_6m: "next_6_months",
    demand_12m: "next_12_months",
    total_fg: "total_fg",
    total_fg_min: "total_fg",
    cover_fg: "fg_cover",
    cover_total: "total_fg_cover",
    cover_excl: "excl_open_po",
    cover_fg_min: "fg_cover",
    cover_total_min: "total_fg_cover",
    cover_excl_min: "excl_open_po",
  };
  return aliases[columnId] ?? columnId;
}

const PREFERENCE_SECTION_LAYOUT: Array<{
  sectionName: string;
  groups: ColumnGroup[];
  allowedNames: string[];
  requiredNames?: string[];
}> = [
  {
    sectionName: "product_info",
    groups: ["meta"],
    allowedNames: [
      "cbu",
      "cbu_description",
      "basepack",
      "basepack_description",
      "small_c",
      "bg",
      "format",
    ],
  },
  {
    sectionName: "demand",
    groups: ["demand"],
    allowedNames: ["next_3_tdp", "next_6_months", "next_12_months"],
  },
  {
    sectionName: "fg_equivalent_rmpm_stock_min",
    groups: ["rmpmMin"],
    allowedNames: [
      "physical_stock",
      "quality_stock",
      "open_po_stock",
      "in_transit",
      "supplier_inventory",
      "total_stock",
      "blocked_stock",
    ],
  },
  {
    sectionName: "fg_summary_min",
    groups: ["summaryMin"],
    allowedNames: ["total_fg", "total_fg_cover_days"],
    requiredNames: ["total_fg_cover_days"],
  },
  {
    sectionName: "cover_production_end_date_min",
    groups: ["coverMin"],
    allowedNames: ["fg_cover", "total_fg_cover", "excl_open_po"],
  },
  {
    sectionName: "fg_equivalent_rmpm_stock_max",
    groups: ["rmpm"],
    allowedNames: [
      "physical_stock",
      "quality_stock",
      "open_po_stock",
      "in_transit",
      "supplier_inventory",
      "total_stock",
      "blocked_stock",
    ],
  },
  {
    sectionName: "fg_summary_max",
    groups: ["summary"],
    allowedNames: ["total_fg", "total_fg_cover_days"],
    requiredNames: ["total_fg_cover_days"],
  },
  {
    sectionName: "cover_production_end_date_max",
    groups: ["cover"],
    allowedNames: ["fg_cover", "total_fg_cover", "excl_open_po"],
  },
];

/** Reverse of mapColumnIdToPreferenceName, scoped to a section's own
 * group(s). Backend column names are reused identically across a Min/Max
 * section pair (e.g. "physical_stock" appears in both
 * fg_equivalent_rmpm_stock_min and _max) — the section (and therefore its
 * group) is what disambiguates which concrete column id ("rmpmMin_physical"
 * vs "rmpm_physical") is meant, so the search must stay within that group
 * rather than matching the name against all columns. */
function findColumnIdForPreferenceName(
  groups: ColumnGroup[],
  preferenceName: string,
): string | null {
  for (const group of groups) {
    const match = ALL_COLS.find(
      (col) => col.group === group && mapColumnIdToPreferenceName(col.id) === preferenceName,
    );
    if (match) return match.id;
  }
  return null;
}

/** True for columns the backend preference contract actually manages: its
 * group has a PREFERENCE_SECTION_LAYOUT entry, and that entry's
 * allowedNames actually lists the column's backend name. Columns that fail
 * this — the whole "fg" group (no section for it exists at all), and STV
 * Stock specifically (fg_equivalent_rmpm_stock_min/_max's allowedNames omit
 * "stv_stock" — confirmed by the API never returning it) — never come back
 * in a GET/PUT response no matter what, so they must not be reset from that
 * response the way backend-managed columns are. */
function isBackendManagedColumn(colId: string): boolean {
  const col = ALL_COLS.find((c) => c.id === colId);
  if (!col) return false;
  const layout = PREFERENCE_SECTION_LAYOUT.find((l) => l.groups.includes(col.group));
  return layout ? layout.allowedNames.includes(mapColumnIdToPreferenceName(colId)) : false;
}

/** `fallbackHidden` supplies the hidden/visible state for columns
 * isBackendManagedColumn excludes, since the API response can never speak
 * to them — omit it (initial page load) to default them to visible, or pass
 * the pre-save hiddenCols (post-save reconcile) so the user's own toggle for
 * them survives the round trip instead of being silently reset. */
/** For columns the backend preference contract doesn't manage, restores
 * `fallbackHidden`'s hidden/visible state (or defaults to visible when no
 * fallback is given) — mutates `hidden` in place. */
function releaseNonBackendManagedColumns(
  hidden: Set<string>,
  fallbackHidden?: Set<string>,
): void {
  for (const col of ALL_COLS) {
    if (isBackendManagedColumn(col.id)) continue;
    if (!fallbackHidden?.has(col.id)) hidden.delete(col.id);
  }
}

/** Applies each preference section's per-column visibility onto `hidden`,
 * mutating it in place. */
function applyPreferenceSectionVisibility(
  hidden: Set<string>,
  sections: UserColumnPreferenceResponse["sections"] | undefined,
): void {
  for (const section of sections ?? []) {
    const layout = PREFERENCE_SECTION_LAYOUT.find(
      (l) => l.sectionName === section.section_name,
    );
    if (!layout) continue;
    const sectionVisible = section.is_visible !== false;
    for (const column of section.columns ?? []) {
      const colId = findColumnIdForPreferenceName(layout.groups, column.name);
      if (!colId) continue;
      if (sectionVisible && column.is_visible) {
        hidden.delete(colId);
      } else {
        hidden.add(colId);
      }
    }
  }
}

function buildHiddenColsFromPreference(
  preference: UserColumnPreferenceResponse | null | undefined,
  fallbackHidden?: Set<string>,
): string[] {
  const hidden = new Set<string>(ALL_COLS.map((col) => col.id));
  if (!preference?.customized) {
    hidden.delete("cbuCode");
    hidden.delete("cbuDescription");
    return Array.from(hidden);
  }

  releaseNonBackendManagedColumns(hidden, fallbackHidden);
  applyPreferenceSectionVisibility(hidden, preference.sections);

  return Array.from(hidden);
}

function buildHiddenGroupsFromPreference(
  preference: UserColumnPreferenceResponse | null | undefined,
): ColumnGroup[] {
  const hiddenGroups: ColumnGroup[] = [];
  if (!preference?.sections?.length) return hiddenGroups;
  for (const section of preference.sections) {
    const layout = PREFERENCE_SECTION_LAYOUT.find(
      (l) => l.sectionName === section.section_name,
    );
    if (layout && section.is_visible === false) hiddenGroups.push(...layout.groups);
  }
  return hiddenGroups;
}

function buildPreferencePayload(
  userEmail: string,
  groupOrder: ColumnGroup[],
  colOrderByGroup: Record<ColumnGroup, string[]>,
  hiddenGroups: Set<ColumnGroup>,
  hiddenCols: Set<string>,
): UserColumnPreferencePayload {
  const sections = PREFERENCE_SECTION_LAYOUT.map(({ sectionName, groups, allowedNames, requiredNames = [] }, index) => {
    const sectionVisible = !groups.some((group) => hiddenGroups.has(group));
    const seenBackendNames = new Set<string>();
    const columns = [
      ...groups.flatMap((group) => colOrderByGroup[group] ?? []).flatMap((id) => {
        const backendName = mapColumnIdToPreferenceName(id);
        if (!backendName || seenBackendNames.has(backendName) || !allowedNames.includes(backendName)) {
          return [];
        }
        seenBackendNames.add(backendName);
        return [{
          name: backendName,
          priority: 0,
          is_visible: sectionVisible && !hiddenCols.has(id),
        }];
      }),
      ...requiredNames.flatMap((name) => {
        if (seenBackendNames.has(name) || !allowedNames.includes(name)) return [];
        seenBackendNames.add(name);
        return [{
          name,
          priority: 0,
          is_visible: sectionVisible,
        }];
      }),
    ];

    return {
      section_name: sectionName,
      priority: index + 1,
      is_visible: sectionVisible,
      columns: columns.map((column, colIndex) => ({
        ...column,
        priority: colIndex + 1,
      })),
    };
  });

  return {
    user_email: userEmail,
    screen_id: "cbu_national_view",
    pref_type: "COLUMN",
    sections,
  };
}

/**
 * Maps each sortable column's internal UI id to the backend field name to
 * send as sortBy — the values below are the API's confirmed sortBy
 * vocabulary (a flat field list, not dot-paths), superseding the earlier
 * best-guess dot-path mapping. If the backend rejects one (422), the
 * resulting toast shows exactly which field/message it objected to (see
 * throwApiError in cbuApi.ts) — use that to correct the mapping here.
 */
const SORT_BY_FIELD_MAP: Record<string, string> = {
  cbuCode: "cbuCode",
  cbuDescription: "cbuDescription",
  basePack: "basePack",
  basePackDescription: "basePackDescription",
  smallC: "smallC",
  bg: "bg",
  format: "format",
  fg_dc: "dcStock",
  fg_factory: "factoryStock",
  fg_intransit: "inTransit",
  fg_total: "fgStock",
  rmpm_physical: "physicalStockMax",
  rmpm_quality: "qualityStockMax",
  rmpm_stv: "stvStockMax",
  rmpm_openpo: "openPOStockMax",
  rmpm_intransit: "inTransitStockMax",
  rmpm_supplier: "supplierInventoryMax",
  rmpm_total: "rmpmStock",
  rmpm_blocked: "blockedStockMax",
  rmpmMin_physical: "physicalStockMin",
  rmpmMin_quality: "qualityStockMin",
  rmpmMin_stv: "stvStockMin",
  rmpmMin_openpo: "openPOStockMin",
  rmpmMin_intransit: "inTransitStockMin",
  rmpmMin_supplier: "supplierInventoryMin",
  rmpmMin_total: "rmpmStockMin",
  rmpmMin_blocked: "blockedStockMin",
  demand_3tdp: "next3Tdp",
  demand_6m: "next6Month",
  demand_12m: "next12Month",
  total_fg: "totalFGMax",
  total_fg_min: "totalFGMin",
  cover_fg: "fgCoverMax",
  cover_total: "totalFGCoverMax",
  cover_excl: "exclOpenPOMax",
  cover_fg_min: "fgCoverMin",
  cover_total_min: "totalFGCoverMin",
  cover_excl_min: "exclOpenPOMin",
};

// The 7 checkbox multi-select dropdown ids, and how many options page each
// /cbus/filters call for them (initial load and every scroll-triggered
// loadMore) fetches.
const MULTI_SELECT_FILTER_IDS: Set<FilterId> = new Set<MultiFilterId>([
  "bg",
  "smallC",
  "format",
  "brand",
  "materialCode",
  "cbuCode",
  "basePack",
]);
const FILTER_OPTIONS_PAGE_SIZE = 100;

// materialCode/cbuCode/basePack have no description anywhere the frontend
// can attach to them (their own `label` is just the bare code again), so
// these three toolbar dropdowns instead source from the group that does
// carry a description: materialCode/cbuCode read the merged `material`/
// `cbu` groups (each option carries `code`+`description` — see
// CbuFilterOption), while basePack still reads the separate
// basePackDescription group (confirmed against a real /cbus/filters
// response — `basePack` itself stayed a bare-code group, unlike material/cbu
// which merged). Selecting an option filters by whatever that source
// group's own `value` is.
const SOURCE_GROUP_FOR_FILTER: Record<MultiFilterId, CbuFilterGroupKey> = {
  bg: "bg",
  smallC: "smallC",
  format: "format",
  brand: "brand",
  materialCode: "material",
  cbuCode: "cbu",
  basePack: "basePackDescription",
};

interface FilterGroupPageState {
  options: CbuFilterOption[];
  totalCount: number;
  page: number;
  hasMore: boolean;
  loadingMore: boolean;
}

/** Mirrors FilterGroupPageState but for a single dropdown's active
 * POST /cbus/filters/search results (`query` is the searched text those
 * results are for — used to drop a stale response that lands after the
 * user has already typed something else). A dropdown with no entry here
 * has no active search, so getFilterOptionViews falls back to
 * filterGroupState (the GET /cbus/filters-sourced list) for it. */
interface FilterSearchState {
  query: string;
  options: CbuFilterOption[];
  totalCount: number;
  page: number;
  hasMore: boolean;
  loading: boolean;
  loadingMore: boolean;
}

/** Shared by getFilterOptionViews' two multi-select sources (an active
 * search's results, or the plain GET-sourced filterGroupState) — both are
 * "some loaded CbuFilterOptions plus the group's totalCount", turned into
 * the same "All" row + real-option FilterOption[] shape either way. */
function buildMultiSelectOptionViews(
  options: CbuFilterOption[],
  totalCount: number,
): FilterOption[] {
  return [
    { value: "All", label: "All", count: totalCount },
    ...options
      .filter((o) => !isAllSentinel(o.value))
      .map((o) => ({
        value: o.value,
        label: o.label || o.value,
        count: o.count,
        disabled: o.disabled,
      })),
  ];
}

export default function NationalDashboard() {
  const { navigate } = useNav();
  const dispatch = useAppDispatch();
  const { accounts } = useMsal();
  const userEmail = accounts?.[0]?.username ?? "test.user@example.com";

  const groupOrder = useAppSelector((s) => s.nationalDashboard.groupOrder);
  const colOrderByGroup = useAppSelector(
    (s) => s.nationalDashboard.colOrderByGroup,
  );
  const hiddenGroupsList = useAppSelector(
    (s) => s.nationalDashboard.hiddenGroups,
  );
  const hiddenColsList = useAppSelector((s) => s.nationalDashboard.hiddenCols);
  const sortCol = useAppSelector((s) => s.nationalDashboard.sortCol);
  const sortDir = useAppSelector((s) => s.nationalDashboard.sortDir);
  const page = useAppSelector((s) => s.nationalDashboard.page);
  const rowsPerPage = useAppSelector((s) => s.nationalDashboard.rowsPerPage);
  const search = useAppSelector((s) => s.nationalDashboard.search);
  const filterOrder = useAppSelector((s) => s.nationalDashboard.filterOrder);
  const visibleFiltersList = useAppSelector(
    (s) => s.nationalDashboard.visibleFilters,
  );
  const dropdownFilters = useAppSelector(
    (s) => s.nationalDashboard.dropdownFilters,
  );
  const showHighContributing = useAppSelector(
    (s) => s.nationalDashboard.showHighContributing,
  );
  const expandedSrNo = useAppSelector((s) => s.nationalDashboard.expandedSrNo);
  const selectedComponentsRaw = useAppSelector(
    (s) => s.nationalDashboard.selectedComponents,
  );

  // Debounce free-text search before it becomes part of the server query —
  // otherwise every keystroke would fire its own /api/v1/cbus request.
  const [debouncedSearch, setDebouncedSearch] = useState(search);
  useEffect(() => {
    const timer = setTimeout(() => setDebouncedSearch(search), 400);
    return () => clearTimeout(timer);
  }, [search]);

  /** Selected values are whatever getFilterOptionViews sourced the option's
   * `value` from — the raw code for bg/smallC/format/brand, but description
   * text for materialCode/cbuCode/basePack (see SOURCE_GROUP_FOR_FILTER) —
   * returns undefined when the selection is empty or ["All"]-only, else the
   * real (non-"All") selected values. */
  function toFilterParamValues(id: FilterId): string[] | undefined {
    const values = dropdownFilters[id]?.filter((v) => !isAllSentinel(v));
    return values && values.length > 0 ? values : undefined;
  }

  const cbuListParams = useMemo<CbuListQueryParams>(
    () => ({
      page,
      pageSize: rowsPerPage,
      search: debouncedSearch || undefined,
      material: toFilterParamValues("materialCode"),
      cbu: toFilterParamValues("cbuCode"),
      basePack: toFilterParamValues("basePack"),
      smallC: toFilterParamValues("smallC"),
      bg: toFilterParamValues("bg"),
      format: toFilterParamValues("format"),
      brand: toFilterParamValues("brand"),
      materialType:
        dropdownFilters.materialType[0] === "ALL"
          ? undefined
          : dropdownFilters.materialType[0],
      uom: toApiUom(dropdownFilters.uom[0] as UomFilter),
      highContributing: showHighContributing,
      sortBy: sortCol ? SORT_BY_FIELD_MAP[sortCol] : undefined,
      sortOrder: sortCol && SORT_BY_FIELD_MAP[sortCol] ? sortDir : undefined,
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [page, rowsPerPage, debouncedSearch, dropdownFilters, showHighContributing, sortCol, sortDir],
  );

  // expandedSrNo tracks a row by srNo, but srNo is only the row's rank
  // within the *current* filtered/paginated/sorted result set — not a
  // stable per-CBU id (see fetchCbuByCode's comment in cbuApi.ts for the
  // same caveat elsewhere). Once search, sort, or the page actually
  // changes, whatever unrelated CBU now lands on that same rank would
  // otherwise render as expanded in its place, so this collapses it.
  // Deliberately narrower than cbuListParams as a whole: showHighContributing
  // and the dropdown filters are excluded because toggling/filtering is
  // meant to refresh the still-expanded row's own contents in place (e.g.
  // switching in its High Contributing section), not collapse it.
  useEffect(() => {
    dispatch(setExpandedSrNo(null));
  }, [dispatch, page, debouncedSearch, sortCol, sortDir]);

  const filtersQueryParams = useMemo<CbuFiltersQueryParams>(
    () => ({
      bg: toFilterParamValues("bg"),
      smallC: toFilterParamValues("smallC"),
      format: toFilterParamValues("format"),
      brand: toFilterParamValues("brand"),
      materialCode: toFilterParamValues("materialCode"),
      cbuCode: toFilterParamValues("cbuCode"),
      basePack: toFilterParamValues("basePack"),
      page: 1,
      pageSize: FILTER_OPTIONS_PAGE_SIZE,
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [dropdownFilters],
  );

  // /cbus/filters is slow — debounce it separately from the checkbox UI
  // (which stays instant, reading straight off dropdownFilters/Redux) so
  // multi-selecting several options in a row fires one request instead of
  // one per click. FILTERS_GC_TIME_MS (cbuQueries.ts) then keeps already-seen
  // combinations cached, so toggling back to one is instant either way.
  const [debouncedFiltersQueryParams, setDebouncedFiltersQueryParams] =
    useState(filtersQueryParams);
  useEffect(() => {
    const timer = setTimeout(
      () => setDebouncedFiltersQueryParams(filtersQueryParams),
      400,
    );
    return () => clearTimeout(timer);
  }, [filtersQueryParams]);

  const {
    data: cbuListResult,
    isLoading: isCbuListLoading,
    isError: isCbuListError,
    error: cbuListError,
    isFetching: isCbuListFetching,
    refetch: refetchCbuList,
  } = useCbuListPagedQuery(cbuListParams, {
    refetchInterval: DASHBOARD_REFETCH_INTERVAL_MS,
  });
  const cbuData = useMemo(() => cbuListResult?.rows ?? [], [cbuListResult]);
  const totalCbuCount = cbuListResult?.count ?? 0;

  // Fetched on page load and refetched (debounced) on every filter
  // selection change. Filter options come from the API; while it is loading
  // or if it fails, getFilterOptionViews exposes only the neutral All option.
  // isFetching (not isLoading) drives the toolbar's "updating" indicator so
  // it also lights up on sibling-narrowing refetches, not just the first
  // load — placeholderData: keepPreviousData means isLoading is only ever
  // true once, on the very first request.
  const { data: cbuFilters, isFetching: isCbuFiltersFetching } =
    useCbuFiltersQuery(debouncedFiltersQueryParams);

  // Per-group (per-dropdown) accumulated option pages — seeded/reset from
  // cbuFilters' page-1 response below, then extended independently by
  // loadMoreFilterOptions as each dropdown is scrolled. Kept apart from
  // cbuFilters/react-query because a scroll-triggered next-page fetch must
  // *append* to one group's options rather than replace the whole
  // 8-group response the way a react-query refetch would.
  const [filterGroupState, setFilterGroupState] = useState<
    Partial<Record<FilterId, FilterGroupPageState>>
  >({});

  // Active per-dropdown POST /cbus/filters/search results, keyed the same
  // way as filterGroupState — a dropdown present here has real search text
  // typed into it right now; getFilterOptionViews prefers this over
  // filterGroupState whenever it's set. See searchFilterOptions/
  // handleFilterSearch below and FilterDropdown's onSearch.
  const [filterSearchState, setFilterSearchState] = useState<
    Partial<Record<FilterId, FilterSearchState>>
  >({});

  // Whenever a fresh page-1 combination lands (first load, or the sibling
  // selection changed and re-narrowed every group), reset every group's
  // accumulated pages back to just that page-1 response — any pages loaded
  // via scrolling the *previous* combination are no longer valid. Any active
  // per-dropdown search is invalidated the same way — it was run against the
  // *previous* sibling selections, so it's cleared here too rather than left
  // showing results for a selection combination that no longer applies; the
  // search box itself (FilterDropdown's own `search` state) is untouched, so
  // the user's typed text stays put and simply re-searches on their next
  // keystroke (or can be left as-is with the GET-sourced list showing).
  useEffect(() => {
    if (!cbuFilters) return;
    const next: Partial<Record<FilterId, FilterGroupPageState>> = {};
    for (const id of MULTI_SELECT_FILTER_IDS) {
      const group = cbuFilters[SOURCE_GROUP_FOR_FILTER[id as MultiFilterId]];
      if (!group) continue;
      next[id] = {
        options: group.options,
        totalCount: group.totalCount,
        page: group.page,
        hasMore: group.hasMore,
        loadingMore: false,
      };
    }
    setFilterGroupState(next);
    setFilterSearchState({});
  }, [cbuFilters]);

  /** Fetches the next 100 options for a single dropdown's group and appends
   * them to its already-loaded options — called once the dropdown's option
   * list is scrolled near its bottom (see FilterDropdown's onLoadMore).
   * Resends the current sibling filter selections (same as the page-1
   * request) plus the next page number, and merges in only the group being
   * scrolled, leaving every other dropdown's loaded options untouched. */
  async function loadMoreFilterOptions(id: FilterId) {
    const current = filterGroupState[id];
    if (!current || !current.hasMore || current.loadingMore) return;
    setFilterGroupState((prev) => {
      const entry = prev[id];
      return entry ? { ...prev, [id]: { ...entry, loadingMore: true } } : prev;
    });
    try {
      const response = await fetchCbuFilters({
        ...debouncedFiltersQueryParams,
        page: current.page + 1,
        pageSize: FILTER_OPTIONS_PAGE_SIZE,
      });
      const group = response[SOURCE_GROUP_FOR_FILTER[id as MultiFilterId]];
      setFilterGroupState((prev) => {
        const entry = prev[id];
        if (!entry || !group) return prev;
        return {
          ...prev,
          [id]: {
            options: [...entry.options, ...group.options],
            totalCount: group.totalCount,
            page: group.page,
            hasMore: group.hasMore,
            loadingMore: false,
          },
        };
      });
    } catch {
      setFilterGroupState((prev) => {
        const entry = prev[id];
        return entry ? { ...prev, [id]: { ...entry, loadingMore: false } } : prev;
      });
    }
  }

  /** The full current multi-select state as POST /cbus/filters/search's
   * `selections` wants it — every CbuFilterGroupKey present with an empty
   * array for "All"/unselected, same sentinel-filtering as
   * toFilterParamValues. basePackDescription has no Redux selection of its
   * own (the Base Pack toolbar dropdown's selection lives under `basePack`
   * — see SOURCE_GROUP_FOR_FILTER) and GET /cbus/filters never sends it as a
   * request param either, so it's always sent empty here too. */
  function buildFilterSelections(): Record<CbuFilterGroupKey, string[]> {
    return {
      bg: toFilterParamValues("bg") ?? [],
      smallC: toFilterParamValues("smallC") ?? [],
      format: toFilterParamValues("format") ?? [],
      brand: toFilterParamValues("brand") ?? [],
      material: toFilterParamValues("materialCode") ?? [],
      cbu: toFilterParamValues("cbuCode") ?? [],
      basePack: toFilterParamValues("basePack") ?? [],
      basePackDescription: [],
    };
  }

  /** Runs a page-1 POST /cbus/filters/search for one dropdown once the user
   * has typed real search text into it (FilterDropdown debounces the raw
   * keystrokes before calling this) — clears that dropdown's search state
   * entirely on an empty/whitespace query, which makes getFilterOptionViews
   * fall back to filterGroupState (GET /cbus/filters) again. Guards every
   * state update against a newer query having landed first (the user kept
   * typing while this request was in flight), so a slow stale response can
   * never clobber what's currently being searched for. */
  async function searchFilterOptions(id: FilterId, query: string) {
    const trimmed = query.trim();
    if (!trimmed) {
      setFilterSearchState((prev) => {
        if (!(id in prev)) return prev;
        const next = { ...prev };
        delete next[id];
        return next;
      });
      return;
    }
    setFilterSearchState((prev) => ({
      ...prev,
      [id]: {
        query: trimmed,
        options: [],
        totalCount: 0,
        page: 1,
        hasMore: false,
        loading: true,
        loadingMore: false,
      },
    }));
    try {
      const response = await searchCbuFilters({
        filter_name: SOURCE_GROUP_FOR_FILTER[id as MultiFilterId],
        search: trimmed,
        selections: buildFilterSelections(),
        page: 1,
        pageSize: FILTER_OPTIONS_PAGE_SIZE,
      });
      setFilterSearchState((prev) =>
        prev[id]?.query === trimmed
          ? {
              ...prev,
              [id]: {
                query: trimmed,
                options: response.options,
                totalCount: response.total_count,
                page: response.page,
                hasMore: response.has_more,
                loading: false,
                loadingMore: false,
              },
            }
          : prev,
      );
    } catch {
      setFilterSearchState((prev) => {
        const entry = prev[id];
        if (entry?.query !== trimmed) return prev;
        return { ...prev, [id]: { ...entry, loading: false } };
      });
    }
  }

  /** Fetches the next page of an active search's results and appends them —
   * the search equivalent of loadMoreFilterOptions, used by handleLoadMore
   * once a dropdown has real search text typed into it. */
  async function loadMoreFilterSearchResults(id: FilterId) {
    const current = filterSearchState[id];
    if (!current || !current.hasMore || current.loadingMore) return;
    setFilterSearchState((prev) => {
      const entry = prev[id];
      return entry ? { ...prev, [id]: { ...entry, loadingMore: true } } : prev;
    });
    try {
      const response = await searchCbuFilters({
        filter_name: SOURCE_GROUP_FOR_FILTER[id as MultiFilterId],
        search: current.query,
        selections: buildFilterSelections(),
        page: current.page + 1,
        pageSize: FILTER_OPTIONS_PAGE_SIZE,
      });
      setFilterSearchState((prev) => {
        const entry = prev[id];
        if (entry?.query !== current.query) return prev;
        return {
          ...prev,
          [id]: {
            ...entry,
            options: [...entry.options, ...response.options],
            totalCount: response.total_count,
            page: response.page,
            hasMore: response.has_more,
            loadingMore: false,
          },
        };
      });
    } catch {
      setFilterSearchState((prev) => {
        const entry = prev[id];
        return entry ? { ...prev, [id]: { ...entry, loadingMore: false } } : prev;
      });
    }
  }

  function handleFilterSearch(id: FilterId, query: string) {
    searchFilterOptions(id, query);
  }

  /** Routes a dropdown's "scrolled near the bottom" trigger to whichever
   * pagination is actually active for it — its search results if it has
   * one in flight/loaded, otherwise the plain GET-sourced list. */
  function handleLoadMore(id: FilterId) {
    if (filterSearchState[id]) {
      loadMoreFilterSearchResults(id);
      return;
    }
    loadMoreFilterOptions(id);
  }

  // Per-component (RM/PM) breakdown is only fetched for the row the user has
  // actually expanded — not the whole page — since it's a per-CBU endpoint.
  const expandedRow = useMemo(
    () => cbuData.find((r) => r.srNo === expandedSrNo) ?? null,
    [cbuData, expandedSrNo],
  );
  const {
    data: expandedComponents,
    isLoading: isExpandedComponentsLoading,
    isError: isExpandedComponentsError,
    refetch: refetchExpandedComponents,
  } = useCbuComponentsQuery(expandedRow?.cbuCode);

  // Same per-CBU endpoint as above, filtered server-side via
  // contributionType=high-contributer — enabled only while the toggle is on,
  // so switching it on (or expanding a different row while it's already on)
  // triggers a fresh fetch instead of reusing whatever was last shown.
  const {
    data: expandedHighContributingComponents,
    isLoading: isExpandedHighContributingLoading,
    isError: isExpandedHighContributingError,
    refetch: refetchExpandedHighContributingComponents,
  } = useCbuHighContributingComponentsQuery(expandedRow?.cbuCode, showHighContributing);

  useEffect(() => {
    if (!isCbuListError) return;
    const detail =
      cbuListError instanceof CbuApiError && cbuListError.validation?.length
        ? ` (${cbuListError.message})`
        : "";
    toast.error(`${CBU_LIST_ERROR_TOAST}${detail}`, {
      id: "national-dashboard-cbu-list-error",
    });
  }, [isCbuListError, cbuListError]);

  useEffect(() => {
    if (isExpandedComponentsError) {
      toast.error(COMPONENT_BREAKDOWNS_ERROR_TOAST, {
        id: "national-dashboard-component-breakdowns-error",
      });
    }
  }, [isExpandedComponentsError]);

  useEffect(() => {
    if (isExpandedHighContributingError) {
      toast.error(COMPONENT_BREAKDOWNS_ERROR_TOAST, {
        id: "national-dashboard-high-contributing-error",
      });
    }
  }, [isExpandedHighContributingError]);

  const isRefreshing = isCbuListFetching;
  const handleRefresh = () => {
    dispatch(resetFilters());
    refetchCbuList();
    if (expandedRow) refetchExpandedComponents();
    if (expandedRow && showHighContributing) refetchExpandedHighContributingComponents();
  };

  const [isExporting, setIsExporting] = useState(false);
  /** GET /api/v1/cbus/export — same filters/search/sort as the table (minus
   * page/pageSize: the export is the whole matching result set, not just the
   * current page), downloaded as the .xlsx the response's Content-Disposition
   * header names. */
  async function handleExport() {
    if (isExporting) return;
    setIsExporting(true);
    try {
      const exportParams: CbuExportQueryParams = {
        search: cbuListParams.search,
        material: cbuListParams.material,
        cbu: cbuListParams.cbu,
        basePack: cbuListParams.basePack,
        smallC: cbuListParams.smallC,
        bg: cbuListParams.bg,
        format: cbuListParams.format,
        brand: cbuListParams.brand,
        materialType: cbuListParams.materialType,
        uom: cbuListParams.uom,
        highContributing: cbuListParams.highContributing,
        sortBy: cbuListParams.sortBy,
        sortOrder: cbuListParams.sortOrder,
      };
      const { blob, filename } = await fetchCbuExport(exportParams);
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch (err) {
      const detail =
        err instanceof CbuApiError && err.validation?.length
          ? ` (${err.message})`
          : "";
      toast.error(`${EXPORT_ERROR_TOAST}${detail}`, {
        id: "national-dashboard-export-error",
      });
    } finally {
      setIsExporting(false);
    }
  }

  const hiddenGroups = useMemo(
    () => new Set(hiddenGroupsList),
    [hiddenGroupsList],
  );
  const hiddenCols = useMemo(() => new Set(hiddenColsList), [hiddenColsList]);
  const visibleFilters = useMemo(
    () => new Set(visibleFiltersList),
    [visibleFiltersList],
  );
  const selectedComponents = useMemo(() => {
    const result: Record<number, Set<string>> = {};
    for (const [srNo, codes] of Object.entries(selectedComponentsRaw)) {
      result[Number(srNo)] = new Set(codes);
    }
    return result;
  }, [selectedComponentsRaw]);

  const componentCache = useMemo(() => {
    if (expandedSrNo == null || !expandedComponents) return {};
    return { [expandedSrNo]: expandedComponents };
  }, [expandedSrNo, expandedComponents]);

  const highContributingCache = useMemo(() => {
    if (expandedSrNo == null || !showHighContributing || !expandedHighContributingComponents) {
      return {};
    }
    // The contributionType=high-contributer endpoint still mixes in
    // components it tags "unique" alongside the actual high-contributing
    // ones — only "high-contributer"/"high-contributing" belongs in this
    // cache.
    return {
      [expandedSrNo]: expandedHighContributingComponents.filter((c) =>
        isHighContributingType(c.contributionType),
      ),
    };
  }, [expandedSrNo, showHighContributing, expandedHighContributingComponents]);

  // Latest POST /api/v1/cbus/recalculate/summary result for the expanded
  // row, fired every time the user toggles an RM/PM component (see
  // triggerRecalculate/toggleComp/toggleAll below) — DashboardTable renders
  // this in place of the client-side computeEffRmpm/getRowCoverResults
  // estimate once it arrives. null until the first toggle after a row
  // expands, or once a different row expands (reset below).
  const [recalculatedRow, setRecalculatedRow] = useState<CBURow | null>(null);
  useEffect(() => {
    setRecalculatedRow(null);
  }, [expandedSrNo]);
  const recalculateSummary = useRecalculateCbuSummaryMutation();

  /** Partitions a component population (the Unique or High Contributing
   * group's own codes — not the other group's) into selected/deselected
   * against `nextSelected`, matching the request shape POST
   * /api/v1/cbus/recalculate/summary expects. Deliberately ignores the
   * row's current RM/PM type filter (RM/PM/ALL) — that's a client-side
   * display narrowing, not a change to which components are actually
   * selected, so it shouldn't affect what's reported as selected/deselected. */
  function triggerRecalculate(
    srNo: number,
    contributionType: CbuRecalculateContributionType,
    nextSelected: Set<string>,
  ) {
    const row = paginatedRows.find((r) => r.srNo === srNo);
    if (!row) return;
    const population =
      contributionType === "high-contributing"
        ? highContributingCache[srNo] ?? []
        : componentCache[srNo] ?? [];
    const selectedRmpmCodes: string[] = [];
    const deselectedRmpmCodes: string[] = [];
    for (const c of population) {
      (nextSelected.has(c.componentCode) ? selectedRmpmCodes : deselectedRmpmCodes).push(
        c.componentCode,
      );
    }
    recalculateSummary.mutate(
      {
        cbuCode: row.cbuCode,
        selectedRmpmCodes,
        deselectedRmpmCodes,
        uom: toApiUom(uom),
        contributionType,
      },
      {
        onSuccess: (recalculated) => setRecalculatedRow(recalculated),
        onError: () =>
          toast.error(RECALCULATE_SUMMARY_ERROR_TOAST, {
            id: "national-dashboard-recalculate-summary-error",
          }),
      },
    );
  }

  const [demandModal, setDemandModal] = useState<{
    code: string;
    desc: string;
    period: "3tdp" | "6m" | "12m";
  } | null>(null);
  const [stockModal, setStockModal] = useState<{ kind: "dc" | "factory" | "transit"; row: CBURow } | null>(null);
  const [hasLoadedPreferences, setHasLoadedPreferences] = useState(false);
  const [savedColumnCustomization, setSavedColumnCustomization] = useState<{
    groupOrder: ColumnGroup[];
    colOrderByGroup: Record<ColumnGroup, string[]>;
    hiddenGroups: Set<ColumnGroup>;
    hiddenCols: Set<string>;
  } | null>(null);

  function buildCustomizationSnapshot() {
    return {
      groupOrder: [...groupOrder],
      colOrderByGroup: Object.fromEntries(
        Object.entries(colOrderByGroup).map(([group, cols]) => [group, [...cols]]),
      ) as Record<ColumnGroup, string[]>,
      hiddenGroups: new Set(hiddenGroups),
      hiddenCols: new Set(hiddenCols),
    };
  }

  useEffect(() => {
    if (!userEmail || hasLoadedPreferences) return;
    let cancelled = false;
    void (async () => {
      try {
        const preference = await fetchUserColumnPreferences(userEmail);
        if (cancelled) return;
        const nextHiddenCols = buildHiddenColsFromPreference(preference);
        const nextHiddenGroups = buildHiddenGroupsFromPreference(preference);
        dispatch(setHiddenCols(nextHiddenCols));
        dispatch(setHiddenGroups(nextHiddenGroups));
        setSavedColumnCustomization({
          ...buildCustomizationSnapshot(),
          hiddenGroups: new Set(nextHiddenGroups),
          hiddenCols: new Set(nextHiddenCols),
        });
      } catch {
        // Keep the existing default visibility when the preference lookup fails.
      } finally {
        if (!cancelled) setHasLoadedPreferences(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [dispatch, hasLoadedPreferences, userEmail]);

  async function handleSaveColumnPreferences() {
    if (!userEmail) return false;
    const payload = buildPreferencePayload(
      userEmail,
      groupOrder,
      colOrderByGroup,
      hiddenGroups,
      hiddenCols,
    );
    try {
      const result = await saveUserColumnPreferences(payload);
      // The endpoint has no success flag on the wire — a failed save throws
      // (via throwApiError) instead of resolving, so getting here means it
      // saved. Reconcile local state from the server's own echoed-back view
      // (result.data) rather than the pre-save snapshot, since the backend
      // may normalize visibility (e.g. enforcing requiredNames columns).
      if (result.data) {
        const nextHiddenCols = buildHiddenColsFromPreference(result.data, hiddenCols);
        const nextHiddenGroups = buildHiddenGroupsFromPreference(result.data);
        dispatch(setHiddenCols(nextHiddenCols));
        dispatch(setHiddenGroups(nextHiddenGroups));
        setSavedColumnCustomization({
          ...buildCustomizationSnapshot(),
          hiddenGroups: new Set(nextHiddenGroups),
          hiddenCols: new Set(nextHiddenCols),
        });
      } else {
        setSavedColumnCustomization(buildCustomizationSnapshot());
      }
      toast.success(result.message ?? "Column preferences saved", {
        id: "national-dashboard-column-preferences-save-success",
        style: {
          backgroundColor: "#ecfdf3",
          color: "#166534",
          border: "1px solid #86efac",
        },
      });
      return true;
    } catch (err) {
      const message = err instanceof Error ? err.message : "Unable to save column preferences";
      toast.error(message, { id: "national-dashboard-column-preferences-save-error" });
      return false;
    }
  }

  const orderedCols = buildOrderedCols(
    groupOrder,
    colOrderByGroup,
    hiddenGroups,
    hiddenCols,
  );
  const orderedMetaCols = useMemo(
    () => orderedCols.filter((col) => col.group === "meta"),
    [orderedCols],
  );
  const orderedDataCols = useMemo(
    () => orderedCols.filter((col) => col.group !== "meta"),
    [orderedCols],
  );
  const groupRuns = useMemo(
    () => computeGroupRuns(orderedDataCols),
    [orderedDataCols],
  );
  const metaWidth = metaColsWidth(orderedMetaCols);
  const tableMinWidth =
    W_SR +
    metaWidth +
    orderedDataCols.reduce((sum, col) => sum + col.minWidth, 0);
  const stickyColCount = 1 + orderedMetaCols.length;

  const uom = dropdownFilters.uom[0] as UomFilter;
  const typeFilter = dropdownFilters.materialType[0] as TypeFilter;

  function setUom(next: UomFilter) {
    dispatch(setDropdownFilter({ id: "uom", values: [next] }));
  }

  function setTypeFilter(next: TypeFilter) {
    dispatch(setDropdownFilter({ id: "materialType", values: [next] }));
  }

  /** Builds the option list a toolbar dropdown renders. For the 7 checkbox
   * multi-select filters: if the dropdown has real search text typed into
   * it (filterSearchState), sources from its POST /cbus/filters/search
   * results instead — otherwise sources from the accumulated paginated
   * state for that group (filterGroupState — seeded/reset from cbuFilters'
   * page-1 response and extended by loadMoreFilterOptions on scroll; see
   * SOURCE_GROUP_FOR_FILTER for the 3 that read a different wire group than
   * their own id) — using each option's own `value`/`label` and
   * `count`/`disabled` — prepending a canonical "All" row (the API may or
   * may not send its own, in whatever casing; this defensively filters any
   * equivalent out so it's never duplicated, same as the old
   * withAllOption()/isAllSentinel() did). Falls back to the mock/static
   * option lists while cbuFilters is still loading. */
  function getFilterOptionViews(id: FilterId): FilterOption[] {
    if (id === "materialType") {
      return MATERIAL_TYPE_FILTER_OPTIONS.map((v) => ({ value: v, label: v }));
    }
    if (id === "uom") {
      return UOM_FILTER_OPTIONS.map((v) => ({ value: v, label: v }));
    }
    if (MULTI_SELECT_FILTER_IDS.has(id)) {
      const activeSearch = filterSearchState[id];
      if (activeSearch) {
        return buildMultiSelectOptionViews(activeSearch.options, activeSearch.totalCount);
      }
      const paged = filterGroupState[id];
      if (paged) {
        return buildMultiSelectOptionViews(paged.options, paged.totalCount);
      }
    }
    return [{ value: "All", label: "All" }];
  }

  const toolbarFilters = filterOrder.filter((id) => visibleFilters.has(id));

  /** Whether a filter currently narrows anything, i.e. isn't at its default —
   * used to badge "More Filters" entries hidden from the toolbar and to gate
   * the page-level "Clear filters" button. */
  function isFilterActive(id: FilterId): boolean {
    const values = dropdownFilters[id];
    if (id === "uom") return values[0] !== "EA";
    if (id === "materialType") return values[0] !== "ALL";
    return !(values.length === 0 || (values.length === 1 && values[0] === "All"));
  }

  const activeHiddenFilterCount = filterOrder.filter(
    (id) => !visibleFilters.has(id) && isFilterActive(id),
  ).length;

  // Scoped to exactly what resetFilters() clears (search + dropdownFilters) —
  // showHighContributing lives in its own toggle in row 1, so it's tracked
  // separately in hasActiveFilters below rather than folded in here.
  const hasActiveDropdownFilters =
    search !== "" || filterOrder.some((id) => isFilterActive(id));

  const hasActiveFilters = hasActiveDropdownFilters || showHighContributing;

  // Filtering, sorting (for API-known columns), and pagination now all
  // happen server-side (see cbuListParams above) — cbuData is already just
  // the current page. This local sort remains only so columns backed by the
  // still-mocked component-breakdown data (which the API doesn't sort by)
  // can still be ordered within that page.
  //
  // Deliberately NOT re-run on componentCache/selectedComponents/
  // highContributingCache/showHighContributing — those change on every
  // row expand/collapse, component select/deselect, and High Contributing
  // toggle, and re-sorting on each would reshuffle row order out from under
  // the user mid-interaction. The order stays exactly as last computed
  // (from whatever cbuData/sortCol/sortDir/typeFilter were then) until one
  // of those actually changes — i.e. until a real sort/search/page/filter
  // round-trip happens — even though the closure below still reads the
  // latest cache/selection values whenever it does re-run.
  const sortedRows = useMemo(() => {
    // API-backed columns are already sorted across the complete result set.
    // Sorting them again here would reorder only the current API page using
    // client-side/mock-derived values, which makes rows appear to mismatch
    // when the user changes page or sort direction.
    if (!sortCol || SORT_BY_FIELD_MAP[sortCol]) return cbuData;
    const copy = [...cbuData];
    copy.sort((a, b) =>
      compareSortValues(
        getRowSortValue(
          a,
          sortCol,
          typeFilter,
          componentCache,
          selectedComponents,
          highContributingCache,
          showHighContributing,
        ),
        getRowSortValue(
          b,
          sortCol,
          typeFilter,
          componentCache,
          selectedComponents,
          highContributingCache,
          showHighContributing,
        ),
        sortDir,
      ),
    );
    return copy;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cbuData, sortCol, sortDir, typeFilter]);

  // The server already returns just one page, sized to rowsPerPage — no
  // client-side slicing needed.
  const activeRowCount = totalCbuCount;
  const totalPages = Math.max(1, Math.ceil(totalCbuCount / rowsPerPage));
  const safePage = Math.min(page, totalPages);
  const paginatedRows = sortedRows;

  useEffect(() => {
    if (page > totalPages) dispatch(setPage(totalPages));
  }, [dispatch, page, totalPages]);

  function handleSort(colId: string) {
    dispatch(setSort(colId));
  }

  function handleCBUClick(row: CBURow) {
    if (expandedSrNo === row.srNo) {
      dispatch(setExpandedSrNo(null));
      return;
    }
    dispatch(setExpandedSrNo(row.srNo));
  }

  // Defaults a freshly-expanded row's component selection to "all selected"
  // once its components have actually loaded — componentCache is now
  // populated asynchronously (fetched on expand, see useCbuComponentsQuery
  // above), so this can no longer be done synchronously inside
  // handleCBUClick the way it was when every row's components were already
  // preloaded. Also covers the High Contributing set arriving *after* that
  // initial default already ran (e.g. the toggle is switched on once the row
  // is already expanded) — any of its codes not seen before are folded in as
  // selected-by-default too, without touching codes the user already has an
  // explicit (possibly deselected) choice for.
  //
  // "Not seen before" is tracked against knownComponentCodesByRowRef (codes
  // this row's API responses have ever contained), NOT against the current
  // selection. Comparing against the selection instead — as this used to —
  // meant a user unchecking a box removed its code from selectedComponents,
  // which this effect (watching selectedComponentsRaw) then saw as a
  // "newly appeared" code and immediately re-selected, so deselecting never
  // stuck. selectedComponentsRaw is intentionally left out of the dependency
  // list so toggling a checkbox doesn't re-trigger this effect at all.
  const knownComponentCodesByRowRef = useRef<Record<number, Set<string>>>({});
  useEffect(() => {
    if (expandedSrNo == null) return;
    const comps = componentCache[expandedSrNo] ?? [];
    const highComps = highContributingCache[expandedSrNo] ?? [];
    const knownCodes = [
      ...new Set([...comps.map((c) => c.componentCode), ...highComps.map((c) => c.componentCode)]),
    ];
    if (knownCodes.length === 0) return;

    const previouslyKnown = knownComponentCodesByRowRef.current[expandedSrNo] ?? new Set<string>();
    const newlyAppeared = knownCodes.filter((code) => !previouslyKnown.has(code));
    knownComponentCodesByRowRef.current[expandedSrNo] = new Set(knownCodes);
    if (newlyAppeared.length === 0) return;

    const existing = selectedComponentsRaw[expandedSrNo];
    if (!existing) {
      dispatch(setSelectedComponentsForRow({ srNo: expandedSrNo, codes: knownCodes }));
      return;
    }
    dispatch(
      setSelectedComponentsForRow({
        srNo: expandedSrNo,
        codes: [...existing, ...newlyAppeared],
      }),
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [expandedSrNo, componentCache, highContributingCache, dispatch]);

  function toggleComp(
    srNo: number,
    code: string,
    contributionType: CbuRecalculateContributionType,
  ) {
    dispatch(toggleSelectedComponent({ srNo, code }));

    const currentCodes =
      selectedComponentsRaw[srNo] ?? [
        ...(componentCache[srNo]?.map((c) => c.componentCode) ?? []),
        ...(highContributingCache[srNo]?.map((c) => c.componentCode) ?? []),
      ];
    const nextSelected = new Set(currentCodes);
    if (nextSelected.has(code)) nextSelected.delete(code);
    else nextSelected.add(code);
    triggerRecalculate(srNo, contributionType, nextSelected);
  }

  // `comps` is scoped to just the group whose header checkbox was clicked
  // (Unique Components or High Contributing — see componentGroupRows), so
  // the row's *other* group's selections must be preserved rather than
  // replaced wholesale: union this group's codes into the row's current
  // selection on select-all, or subtract only this group's codes on
  // deselect-all. Falls back to "everything currently known for this row"
  // (same default componentGroupRows/DashboardTable use) when nothing has
  // been recorded in Redux for it yet.
  function toggleAll(
    srNo: number,
    comps: AggregatedComponent[],
    allSel: boolean,
    contributionType: CbuRecalculateContributionType,
  ) {
    const currentCodes =
      selectedComponentsRaw[srNo] ?? [
        ...(componentCache[srNo]?.map((c) => c.componentCode) ?? []),
        ...(highContributingCache[srNo]?.map((c) => c.componentCode) ?? []),
      ];
    const next = new Set(currentCodes);
    for (const c of comps) {
      if (allSel) next.delete(c.componentCode);
      else next.add(c.componentCode);
    }
    dispatch(setSelectedComponentsForRow({ srNo, codes: Array.from(next) }));
    triggerRecalculate(srNo, contributionType, next);
  }

  function renderCbuTableSection() {
    if (isCbuListLoading) {
      return (
        <div className="flex-1 overflow-auto p-3" aria-busy="true" aria-label={LOADING_TEXT}>
          <TableSkeleton
            columns={stickyColCount + orderedDataCols.length}
            rows={Math.min(rowsPerPage, 12)}
          />
        </div>
      );
    }

    if (isCbuListError) {
      return (
        <div className="flex-1 flex flex-col items-center justify-center gap-2">
          <AlertTriangle size={24} style={{ color: "#dc2626" }} />
          <p className="text-sm" style={{ color: "#64748b" }}>{ERROR_TEXT}</p>
        </div>
      );
    }

    if (activeRowCount === 0 && !hasActiveFilters) {
      return (
        <div className="flex-1 flex flex-col items-center justify-center gap-2">
          <Search size={24} style={{ color: "#94a3b8" }} />
          <p className="text-sm italic" style={{ color: "#64748b" }}>{NO_CBU_DATA_MESSAGE}</p>
        </div>
      );
    }

    if (activeRowCount === 0) {
      return (
        <div className="flex-1 flex flex-col items-center justify-center gap-2">
          <Search size={24} style={{ color: "#94a3b8" }} />
          <p className="text-sm italic" style={{ color: "#64748b" }}>{NO_SEARCH_RESULTS_MESSAGE}</p>
          <button
            type="button"
            onClick={() => dispatch(resetFilters())}
            className="text-xs font-semibold cursor-pointer bg-blue-600"
            style={{ color: "#ffffff" }}
          >
            {CLEAR_FILTERS_LABEL}
          </button>
        </div>
      );
    }

    return (
      <>
        <DashboardTable
          orderedMetaCols={orderedMetaCols}
          orderedDataCols={orderedDataCols}
          groupRuns={groupRuns}
          tableMinWidth={tableMinWidth}
          stickyColCount={stickyColCount}
          sortCol={sortCol}
          sortDir={sortDir}
          onSort={handleSort}
          page={safePage}
          paginatedRows={paginatedRows}
          expandedSrNo={expandedSrNo}
          isExpandedComponentsLoading={isExpandedComponentsLoading}
          isExpandedHighContributingLoading={isExpandedHighContributingLoading}
          componentCache={componentCache}
          highContributingCache={highContributingCache}
          selectedComponents={selectedComponents}
          typeFilter={typeFilter}
          uom={uom}
          showHighContributing={showHighContributing}
          recalculatedRow={recalculatedRow}
          isRecalculating={recalculateSummary.isPending}
          onCbuClick={handleCBUClick}
          navigate={navigate}
          onToggleComp={toggleComp}
          onToggleAll={toggleAll}
          onDemandClick={(row, period) =>
            setDemandModal({ code: row.cbuCode, desc: row.cbuDescription, period })
          }
          onDcStockClick={(row) => setStockModal({ kind: "dc", row })}
          onFactoryStockClick={(row) => setStockModal({ kind: "factory", row })}
          onInTransitClick={(row) => setStockModal({ kind: "transit", row })}
        />

        <TablePagination
          page={safePage}
          rowsPerPage={rowsPerPage}
          totalRows={activeRowCount}
          onPageChange={(p) => dispatch(setPage(p))}
          onRowsPerPageChange={(n) => dispatch(setRowsPerPage(n))}
        />
      </>
    );
  }

  return (
    <>
      <div className="flex flex-col h-full overflow-hidden">
        <PageTabHeader active="inventory" />

        {/* ── Row 1: Search + UOM + Customise ── */}
        <div
          className="px-5 py-2 shrink-0 flex items-center gap-3 mt-2"
          style={{
            backgroundColor: "#ffffff",
            borderBottom: "1px solid #e5e7eb",
            borderTopLeftRadius: 8,
            borderTopRightRadius: 8,
          }}
        >
          <div className="relative" style={{ maxWidth: 300, flex: 1 }}>
            <Search
              size={13}
              className="absolute left-3 top-1/2 -translate-y-1/2"
              style={{ color: "#9ca3af" }}
            />
            <input
              type="text"
              placeholder={SEARCH_PLACEHOLDER}
              title={SEARCH_TOOLTIP}
              value={search}
              onChange={(e) => dispatch(setSearch(e.target.value))}
              className="w-full pl-8 pr-3 py-1.5 rounded-full text-xs focus:outline-none transition-all"
              style={{
                backgroundColor: "#f9fafb",
                borderWidth: 1,
                borderStyle: "solid",
                borderColor: "#d1d5db",
                color: "#111827",
                fontFamily: "'Plus Jakarta Sans', sans-serif",
              }}
              onFocus={(e) =>
                ((e.currentTarget as HTMLElement).style.borderColor =
                  "#1565C0")
              }
              onBlur={(e) =>
                ((e.currentTarget as HTMLElement).style.borderColor =
                  "#d1d5db")
              }
            />
          </div>

          <div className="ml-auto flex items-center gap-2">
            <button
              type="button"
              role="switch"
              aria-checked={showHighContributing}
              onClick={() => dispatch(toggleShowHighContributing())}
              title={highContributingToggleTitle(showHighContributing)}
              className="flex items-center gap-1.5 h-8 px-2.5 rounded-full text-xs font-medium leading-none whitespace-nowrap cursor-pointer transition-colors shrink-0"
              style={{
                backgroundColor: showHighContributing
                  ? "#EDF5FA"
                  : "#ffffff",
                borderWidth: 1,
                borderStyle: "solid",
                borderColor: showHighContributing ? "#1565C0" : "#d1d5db",
                color: "#374151",
              }}
            >
              <span
                className="relative w-7 h-[14px] rounded-full transition-colors shrink-0"
                style={{
                  backgroundColor: showHighContributing
                    ? "#1565C0"
                    : "#cbd5e1",
                }}
              >
                <span
                  className="absolute top-0.5 w-2.5 h-2.5 rounded-full bg-white transition-transform"
                  style={{ left: showHighContributing ? 14 : 2 }}
                />
              </span>
              {HIGH_CONTRIBUTING_LABEL}
            </button>
            <ColumnCustomizer
              groupOrder={groupOrder}
              setGroupOrder={toStateSetter(groupOrder, (next) =>
                dispatch(setGroupOrder(next)),
              )}
              colOrderByGroup={colOrderByGroup}
              setColOrderByGroup={toStateSetter(colOrderByGroup, (next) =>
                dispatch(setColOrderByGroup(next)),
              )}
              hiddenGroups={hiddenGroups}
              setHiddenGroups={toStateSetter(hiddenGroups, (next) =>
                dispatch(setHiddenGroups(Array.from(next))),
              )}
              hiddenCols={hiddenCols}
              setHiddenCols={toStateSetter(hiddenCols, (next) =>
                dispatch(setHiddenCols(Array.from(next))),
              )}
              onDone={handleSaveColumnPreferences}
              resetState={savedColumnCustomization ?? undefined}
            />
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              title={REFRESH_BUTTON_TITLE}
              onClick={handleRefresh}
              disabled={isRefreshing}
              className="flex items-center justify-center w-8 h-8 rounded-lg cursor-pointer transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
              style={{
                backgroundColor: "#EDF5FA",
                color: "#1565C0",
                border: "1px solid #d1d5db",
              }}
            >
              <RefreshCw size={14} className={isRefreshing ? "animate-spin" : undefined} />
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              title={EXPORT_BUTTON_TITLE}
              onClick={handleExport}
              disabled={isExporting}
              className="flex items-center justify-center w-8 h-8 rounded-lg cursor-pointer transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
              style={{
                backgroundColor: "#EDF5FA",
                color: "#1565C0",
                border: "1px solid #d1d5db",
              }}
            >
              <Download size={14} className={isExporting ? "animate-pulse" : undefined} />
            </motion.button>
          </div>
        </div>

        {/* ── Row 2: Filters dropdowns ── */}
        <div
          className="pl-5 pr-4 py-2 shrink-0 flex items-end min-w-0 gap-2"
          style={{
            backgroundColor: "#ffffff",
            borderBottom: "1px solid #e5e7eb",
            borderBottomLeftRadius: 8,
            borderBottomRightRadius: 8,
          }}
        >
          <div className="flex items-end flex-wrap gap-x-3 gap-y-2 flex-1 min-w-0">
            {toolbarFilters.map((filterId) => {
              const def = ALL_FILTER_DEFINITIONS.find((f) => f.id === filterId);
              if (!def) return null;

              if (def.kind === "toggle" && filterId === "materialType") {
                return (
                  <Fragment key={filterId}>
                    <FilterToggle
                      label={def.label}
                      value={typeFilter}
                      onChange={(v) => setTypeFilter(v as TypeFilter)}
                      activeColor="#1565C0"
                      options={MATERIAL_TYPE_TOGGLE_OPTIONS}
                    />
                  </Fragment>
                );
              }

              if (def.kind === "toggle" && filterId === "uom") {
                return (
                  <Fragment key={filterId}>
                    <FilterToggle
                      label={def.label}
                      value={uom}
                      onChange={(v) => setUom(v as UomFilter)}
                      activeColor="#1565C0"
                      options={UOM_TOGGLE_OPTIONS}
                    />
                  </Fragment>
                );
              }

              const activeSearch = filterSearchState[filterId];
              return (
                <Fragment key={filterId}>
                  <FilterDropdown
                    label={def.label}
                    values={dropdownFilters[filterId]}
                    options={getFilterOptionViews(filterId)}
                    loading={activeSearch ? activeSearch.loading : isCbuFiltersFetching}
                    hasMore={
                      activeSearch
                        ? activeSearch.hasMore
                        : filterGroupState[filterId]?.hasMore ?? false
                    }
                    loadingMore={
                      activeSearch
                        ? activeSearch.loadingMore
                        : filterGroupState[filterId]?.loadingMore ?? false
                    }
                    onLoadMore={
                      MULTI_SELECT_FILTER_IDS.has(filterId)
                        ? () => handleLoadMore(filterId)
                        : undefined
                    }
                    onSearch={
                      MULTI_SELECT_FILTER_IDS.has(filterId)
                        ? (query) => handleFilterSearch(filterId, query)
                        : undefined
                    }
                    onChange={(values) =>
                      dispatch(setDropdownFilter({ id: filterId, values }))
                    }
                  />
                </Fragment>
              );
            })}
          </div>

          {hasActiveDropdownFilters && (
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              type="button"
              title={CLEAR_FILTERS_LABEL}
              onClick={() => dispatch(resetFilters())}
              className="flex items-center justify-center w-8 h-8 rounded-lg cursor-pointer transition-colors shrink-0"
              style={{
                backgroundColor: "#EDF5FA",
                color: "#1565C0",
                border: "1px solid #d1d5db",
              }}
            >
              <FilterX size={14} />
            </motion.button>
          )}

          <MoreFiltersPanel
            filterOrder={filterOrder}
            setFilterOrder={toStateSetter(filterOrder, (next) =>
              dispatch(setFilterOrder(next)),
            )}
            visibleFilters={visibleFilters}
            setVisibleFilters={toStateSetter(visibleFilters, (next) =>
              dispatch(setVisibleFilters(Array.from(next))),
            )}
            activeHiddenCount={activeHiddenFilterCount}
          />
        </div>

        {/* ── Row 3: Info bar ── */}
        <TableHintsBar />

        {renderCbuTableSection()}
      </div>

      {demandModal && (
        <Suspense fallback={MODAL_LOADER_FALLBACK}>
          <DemandModal
            cbuCode={demandModal.code}
            cbuDescription={demandModal.desc}
            period={demandModal.period}
            uom={uom}
            onClose={() => setDemandModal(null)}
          />
        </Suspense>
      )}

      {stockModal && (
        <Suspense fallback={MODAL_LOADER_FALLBACK}>
          <StockLocationBreakdownModal
            kind={stockModal.kind}
            row={stockModal.row}
            uom={uom}
            onClose={() => setStockModal(null)}
          />
        </Suspense>
      )}
    </>
  );
}
