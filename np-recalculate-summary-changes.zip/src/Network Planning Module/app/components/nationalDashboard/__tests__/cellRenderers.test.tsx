import { render, screen, fireEvent } from "@testing-library/react";
import { metaCell, mainCell, compCell, componentGroupRows } from "../cellRenderers";
import { ALL_COLS } from "../../../constants/nationalDashboard";
import type { CBURow, AggregatedComponent } from "../../data";
import type { ColDef, EffRmpm, CoverResult } from "../types";

function makeRow(overrides: Partial<CBURow> = {}): CBURow {
  return {
    srNo: 1,
    cbuCode: "TESTCODE",
    cbuDescription: "Test CBU 200ML",
    weightKg: 0.2,
    fg: { dcStock: 100, factoryStock: 50, inTransitStock: 20, totalStock: 170 },
    rmpm: {
      physicalStock: 40,
      qualityStock: 10,
      openPOStock: 5,
      totalStock: 55,
      blockedStock: 0,
      supplierInventory: 0,
      inTransitStock: 0,
    },
    rmpmMin: {
      physicalStock: 40,
      qualityStock: 10,
      openPOStock: 5,
      totalStock: 55,
      blockedStock: 0,
      supplierInventory: 0,
      inTransitStock: 0,
    },
    rmpmMax: {
      physicalStock: 40,
      qualityStock: 10,
      openPOStock: 5,
      totalStock: 55,
      blockedStock: 0,
      supplierInventory: 0,
      inTransitStock: 0,
    },
    demand: { sumNext3TDP: 30, next6Months: 100, next12Months: 200 },
    totalFG: 170,
    cover: { fgCoverDate: "N/A", totalCoverDate: "N/A", coverExclOpenPO: "N/A" },
    ...overrides,
  };
}

function makeComponent(overrides: Partial<AggregatedComponent> = {}): AggregatedComponent {
  return {
    componentCode: "C1",
    componentMaterialType: "1002",
    unrestrictedStock: 10,
    qualityStock: 2,
    blockedStock: 0,
    totalStock: 12,
    openPOStock: 3,
    ...overrides,
  };
}

const cbuCodeCol = ALL_COLS.find((c) => c.id === "cbuCode") as ColDef;
const cbuDescriptionCol = ALL_COLS.find((c) => c.id === "cbuDescription") as ColDef;
const smallCCol = ALL_COLS.find((c) => c.id === "smallC") as ColDef;

function renderCell(node: React.ReactNode) {
  return render(
    <table>
      <tbody>
        <tr>{node}</tr>
      </tbody>
    </table>,
  );
}

function renderRows(node: React.ReactNode) {
  return render(
    <table>
      <tbody>{node}</tbody>
    </table>,
  );
}

const zeroEff: EffRmpm = {
  physicalStock: 0,
  qualityStock: 0,
  stvStock: 0,
  openPOStock: 0,
  totalStock: 0,
  blockedStock: 0,
  supplierInventory: 0,
  inTransitStock: 0,
};

const noCover: CoverResult = { days: null, date: "-" };

function baseMainCellParams(overrides: Partial<Parameters<typeof mainCell>[0]> = {}) {
  return {
    colId: "fg_total",
    row: makeRow(),
    effMax: zeroEff,
    effMin: zeroEff,
    uom: "EA" as const,
    groupBoundaryColIds: new Set<string>(),
    totalFGMax: 0,
    totalFGMin: 0,
    fgCov: noCover,
    totCovMax: noCover,
    totCovMin: noCover,
    exclCovMax: noCover,
    exclCovMin: noCover,
    onDemand: jest.fn(),
    onDcStockClick: jest.fn(),
    onFactoryStockClick: jest.fn(),
    onInTransitClick: jest.fn(),
    ...overrides,
  };
}

describe("metaCell", () => {
  it("renders a collapsed chevron for the cbuCode column when not expanded and calls onCbuClick", () => {
    const onCbuClick = jest.fn();
    const row = makeRow({ cbuCode: "AAA" });
    const { container } = renderCell(
      metaCell({
        col: cbuCodeCol,
        row,
        rowBg: "#ffffff",
        isExpanded: false,
        onCbuClick,
        navigate: jest.fn(),
        stickyLeft: 0,
        isDescriptionExpanded: false,
      }),
    );
    expect(container.querySelector(".lucide-chevron-right")).not.toBeNull();
    expect(container.querySelector(".lucide-chevron-down")).toBeNull();
    fireEvent.click(screen.getByText("AAA"));
    expect(onCbuClick).toHaveBeenCalledWith(row);
  });

  it("renders an expanded chevron for the cbuCode column when expanded", () => {
    const { container } = renderCell(
      metaCell({
        col: cbuCodeCol,
        row: makeRow(),
        rowBg: "#ffffff",
        isExpanded: true,
        onCbuClick: jest.fn(),
        navigate: jest.fn(),
        stickyLeft: 0,
        isDescriptionExpanded: false,
      }),
    );
    expect(container.querySelector(".lucide-chevron-down")).not.toBeNull();
  });

  it("navigates to cbu-detail when the description link is clicked, without expanding/collapsing the row", () => {
    const navigate = jest.fn();
    const row = makeRow({ cbuCode: "AAA", cbuDescription: "A description" });
    renderCell(
      metaCell({
        col: cbuDescriptionCol,
        row,
        rowBg: "#ffffff",
        isExpanded: false,
        onCbuClick: jest.fn(),
        navigate,
        stickyLeft: 0,
        isDescriptionExpanded: false,
      }),
    );
    fireEvent.click(screen.getByText("A description"));
    expect(navigate).toHaveBeenCalledWith({ page: "cbu-detail", cbuCode: "AAA" });
  });

  it("shows a disabled 'Coming Soon' scenario-simulation button next to the description", () => {
    renderCell(
      metaCell({
        col: cbuDescriptionCol,
        row: makeRow(),
        rowBg: "#ffffff",
        isExpanded: false,
        onCbuClick: jest.fn(),
        navigate: jest.fn(),
        stickyLeft: 0,
        isDescriptionExpanded: false,
      }),
    );
    const button = screen.getByTitle("Coming Soon");
    fireEvent.mouseEnter(button);
    expect((button as HTMLElement).style.backgroundColor).toBe("rgb(237, 245, 244)");
    fireEvent.mouseLeave(button);
    expect((button as HTMLElement).style.backgroundColor).toBe("transparent");
  });

  it("renders a generic meta column's value via getMetaColumnValue", () => {
    const row = makeRow({ smallC: "SC1" });
    renderCell(
      metaCell({
        col: smallCCol,
        row,
        rowBg: "#ffffff",
        isExpanded: false,
        onCbuClick: jest.fn(),
        navigate: jest.fn(),
        stickyLeft: 0,
        isDescriptionExpanded: false,
      }),
    );
    expect(screen.getByTitle("SC1")).toBeInTheDocument();
  });
});

describe("mainCell", () => {
  it("shows the no-stock tooltip instead of a click handler when DC/factory/in-transit stock is zero", () => {
    const row = makeRow({ fg: { dcStock: 0, factoryStock: 0, inTransitStock: 0, totalStock: 0 } });
    renderCell(mainCell(baseMainCellParams({ colId: "fg_dc", row })));
    expect(screen.getByTitle("No DC stock currently recorded.")).toBeInTheDocument();

    renderCell(mainCell(baseMainCellParams({ colId: "fg_factory", row })));
    expect(screen.getByTitle("No factory stock currently recorded.")).toBeInTheDocument();

    renderCell(mainCell(baseMainCellParams({ colId: "fg_intransit", row })));
    expect(screen.getByTitle("No stock currently in transit.")).toBeInTheDocument();
  });

  it("shows a DC/factory breakdown tooltip on fg_blocked when the API sends the split", () => {
    const row = makeRow({
      fg: {
        dcStock: 100,
        factoryStock: 50,
        inTransitStock: 20,
        totalStock: 170,
        blockedStock: 4042058,
        dcBlockedStock: 887498,
        factoryBlockedStock: 3154560,
      },
    });
    const { container } = renderCell(mainCell(baseMainCellParams({ colId: "fg_blocked", row })));
    expect(container.querySelector("td")?.getAttribute("title")).toBe(
      "DC Blocked Stock: 8,87,498\nFactory Blocked Stock: 31,54,560",
    );
  });

  it("omits the fg_blocked tooltip when the API sends no DC/factory split", () => {
    const row = makeRow({
      fg: { dcStock: 100, factoryStock: 50, inTransitStock: 20, totalStock: 170, blockedStock: 0 },
    });
    const { container } = renderCell(mainCell(baseMainCellParams({ colId: "fg_blocked", row })));
    expect(container.querySelector("td")?.getAttribute("title")).toBeNull();
  });

  it("calls onDcStockClick, onFactoryStockClick and onInTransitClick when stock is positive", () => {
    const row = makeRow({ fg: { dcStock: 100, factoryStock: 50, inTransitStock: 20, totalStock: 170 } });
    const onDcStockClick = jest.fn();
    const onFactoryStockClick = jest.fn();
    const onInTransitClick = jest.fn();

    renderCell(mainCell(baseMainCellParams({ colId: "fg_dc", row, onDcStockClick })));
    fireEvent.click(screen.getByText("100"));
    expect(onDcStockClick).toHaveBeenCalled();

    renderCell(mainCell(baseMainCellParams({ colId: "fg_factory", row, onFactoryStockClick })));
    fireEvent.click(screen.getByText("50"));
    expect(onFactoryStockClick).toHaveBeenCalled();

    renderCell(mainCell(baseMainCellParams({ colId: "fg_intransit", row, onInTransitClick })));
    fireEvent.click(screen.getByText("20"));
    expect(onInTransitClick).toHaveBeenCalled();
  });

  it("renders demand cells with a no-demand tooltip when zero and calls onDemand with the period when positive", () => {
    const zeroDemandRow = makeRow({ demand: { sumNext3TDP: 0, next6Months: 0, next12Months: 0 } });
    renderCell(mainCell(baseMainCellParams({ colId: "demand_3tdp", row: zeroDemandRow })));
    expect(screen.getByTitle("No demand data available.")).toBeInTheDocument();

    const onDemand = jest.fn();
    const row = makeRow({ demand: { sumNext3TDP: 5, next6Months: 15, next12Months: 200 } });
    renderCell(mainCell(baseMainCellParams({ colId: "demand_3tdp", row, onDemand })));
    fireEvent.click(screen.getByText("5"));
    expect(onDemand).toHaveBeenCalledWith(expect.anything(), "3tdp");

    renderCell(mainCell(baseMainCellParams({ colId: "demand_6m", row, onDemand })));
    fireEvent.click(screen.getByText("15"));
    expect(onDemand).toHaveBeenCalledWith(expect.anything(), "6m");
  });

  it("renders rmpm and rmpmMin numeric columns from effMax/effMin respectively", () => {
    const effMax: EffRmpm = { ...zeroEff, physicalStock: 11, qualityStock: 22, stvStock: 33, openPOStock: 44, supplierInventory: 55, blockedStock: 66, totalStock: 77 };
    const effMin: EffRmpm = { ...zeroEff, physicalStock: 111, qualityStock: 222, stvStock: 333, openPOStock: 444, supplierInventory: 555, blockedStock: 666, totalStock: 777 };

    const cases: Array<[string, string]> = [
      ["rmpm_physical", "11"],
      ["rmpm_quality", "22"],
      ["rmpm_stv", "33"],
      ["rmpm_openpo", "44"],
      ["rmpm_intransit", "—"],
      ["rmpm_supplier", "55"],
      ["rmpm_blocked", "66"],
      ["rmpm_total", "77"],
      ["rmpmMin_physical", "111"],
      ["rmpmMin_quality", "222"],
      ["rmpmMin_stv", "333"],
      ["rmpmMin_openpo", "444"],
      ["rmpmMin_intransit", "—"],
      ["rmpmMin_supplier", "555"],
      ["rmpmMin_blocked", "666"],
      ["rmpmMin_total", "777"],
    ];
    for (const [colId, expected] of cases) {
      const { unmount } = renderCell(mainCell(baseMainCellParams({ colId, effMax, effMin })));
      expect(screen.getByText(expected)).toBeInTheDocument();
      unmount();
    }
  });

  it("renders total_fg/total_fg_min from totalFGMax/totalFGMin", () => {
    renderCell(mainCell(baseMainCellParams({ colId: "total_fg", totalFGMax: 123 })));
    expect(screen.getByText("123")).toBeInTheDocument();

    renderCell(mainCell(baseMainCellParams({ colId: "total_fg_min", totalFGMin: 456 })));
    expect(screen.getByText("456")).toBeInTheDocument();
  });

  it("renders every cover column from its corresponding CoverResult", () => {
    const excess: CoverResult = { days: null, date: "Excess Stock" };
    renderCell(mainCell(baseMainCellParams({ colId: "cover_fg", fgCov: excess })));
    expect(screen.getByText("Excess Stock")).toBeInTheDocument();

    renderCell(mainCell(baseMainCellParams({ colId: "cover_total", totCovMax: excess })));
    expect(screen.getAllByText("Excess Stock").length).toBeGreaterThan(0);

    renderCell(mainCell(baseMainCellParams({ colId: "cover_excl", exclCovMax: excess })));
    expect(screen.getAllByText("Excess Stock").length).toBeGreaterThan(0);

    renderCell(mainCell(baseMainCellParams({ colId: "cover_total_min", totCovMin: excess })));
    expect(screen.getAllByText("Excess Stock").length).toBeGreaterThan(0);

    renderCell(mainCell(baseMainCellParams({ colId: "cover_excl_min", exclCovMin: excess })));
    expect(screen.getAllByText("Excess Stock").length).toBeGreaterThan(0);
  });

  it("renders an empty cell for an unknown column id", () => {
    const { container } = renderCell(mainCell(baseMainCellParams({ colId: "not-a-real-col" })));
    const td = container.querySelector("td");
    expect(td).not.toBeNull();
    expect(td?.textContent).toBe("");
  });
});

describe("compCell", () => {
  const row = makeRow();
  const comp = makeComponent({
    unrestrictedStock: 10,
    qualityStock: 5,
    openPOStock: 3,
    blockedStock: 1,
  });

  it("renders unrestrictedStock for rmpm_physical/rmpmMin_physical", () => {
    renderCell(compCell("rmpm_physical", comp, row, "EA", new Set<string>()));
    expect(screen.getByText("10")).toBeInTheDocument();
  });

  it("renders qualityStock for rmpm_quality/rmpmMin_quality", () => {
    renderCell(compCell("rmpmMin_quality", comp, row, "EA", new Set<string>()));
    expect(screen.getByText("5")).toBeInTheDocument();
  });

  it("renders openPOStock for rmpm_openpo/rmpmMin_openpo", () => {
    renderCell(compCell("rmpmMin_openpo", comp, row, "EA", new Set<string>()));
    expect(screen.getByText("3")).toBeInTheDocument();
  });

  it("renders blockedStock for rmpm_blocked/rmpmMin_blocked", () => {
    renderCell(compCell("rmpm_blocked", comp, row, "EA", new Set<string>()));
    expect(screen.getByText("1")).toBeInTheDocument();
  });

  it("renders the sum of unrestricted+quality+openPO for rmpm_total/total_fg", () => {
    renderCell(compCell("rmpm_total", comp, row, "EA", new Set<string>()));
    expect(screen.getByText("18")).toBeInTheDocument();
  });

  it("renders a blank cell for columns with no per-component figure", () => {
    for (const colId of ["fg_dc", "fg_factory", "fg_intransit", "fg_total", "rmpm_stv", "rmpmMin_stv", "rmpm_intransit", "rmpm_supplier", "demand_3tdp", "cover_fg"]) {
      const { container, unmount } = renderCell(compCell(colId, comp, row, "EA", new Set<string>()));
      const td = container.querySelector("td");
      expect(td?.textContent).toBe("");
      unmount();
    }
  });

  it("renders cover_total/cover_total_min and cover_excl/cover_excl_min from calcCover", () => {
    const highRow = makeRow({ demand: { sumNext3TDP: 1, next6Months: 1, next12Months: 0 } });
    renderCell(compCell("cover_total", comp, highRow, "EA", new Set<string>()));
    expect(screen.getByText("Excess Stock")).toBeInTheDocument();

    renderCell(compCell("cover_excl", comp, highRow, "EA", new Set<string>()));
    expect(screen.getAllByText("Excess Stock").length).toBeGreaterThan(0);
  });

  it("renders a blank cell for an unrecognized column id", () => {
    const { container } = renderCell(compCell("not-a-real-col", comp, row, "EA", new Set<string>()));
    const td = container.querySelector("td");
    expect(td?.textContent).toBe("");
  });
});

describe("componentGroupRows", () => {
  const row = makeRow({ srNo: 1 });

  function baseParams(overrides: Partial<Parameters<typeof componentGroupRows>[0]> = {}) {
    return {
      comps: [] as AggregatedComponent[],
      keyPrefix: "main",
      label: <>Unique Components</>,
      headerBg: "#EDF5F4",
      emptyMessage: "No component data for this CBU",
      isLoading: false,
      row,
      selected: new Set<string>(),
      effectiveMetaCols: [cbuCodeCol, cbuDescriptionCol],
      orderedDataCols: [],
      groupBoundaryColIds: new Set<string>(),
      stickyColCount: 3,
      uom: "EA" as const,
      contributionType: "unique" as const,
      onToggleAll: jest.fn(),
      onToggleComp: jest.fn(),
      ...overrides,
    };
  }

  it("shows the loading message instead of the empty message while loading", () => {
    renderRows(
      componentGroupRows(baseParams({ isLoading: true })) as React.ReactNode,
    );
    expect(screen.getByText("Loading components…")).toBeInTheDocument();
    expect(screen.queryByText("No component data for this CBU")).not.toBeInTheDocument();
  });

  it("shows the empty message when there are no components and it isn't loading", () => {
    renderRows(componentGroupRows(baseParams()) as React.ReactNode);
    expect(screen.getByText("No component data for this CBU")).toBeInTheDocument();
  });

  it("renders an RM badge, the component code, and calls onToggleComp when a component row is clicked", () => {
    const onToggleComp = jest.fn();
    const comps = [makeComponent({ componentCode: "COMP1", componentMaterialType: "1001" })];
    renderRows(
      componentGroupRows(
        baseParams({ comps, selected: new Set(["COMP1"]), onToggleComp }),
      ) as React.ReactNode,
    );
    expect(screen.getByText("RM")).toBeInTheDocument();
    expect(screen.getByText("COMP1")).toBeInTheDocument();
    fireEvent.click(screen.getByText("COMP1"));
    expect(onToggleComp).toHaveBeenCalledWith(1, "COMP1", "unique");
  });

  it("renders a PM badge for PM components", () => {
    const comps = [makeComponent({ componentCode: "COMP2", componentMaterialType: "1002" })];
    renderRows(
      componentGroupRows(baseParams({ comps, selected: new Set(["COMP2"]) })) as React.ReactNode,
    );
    expect(screen.getByText("PM")).toBeInTheDocument();
  });

  it("renders an SFG badge for 1003 components", () => {
    const comps = [makeComponent({ componentCode: "COMP4", componentMaterialType: "1003" })];
    renderRows(
      componentGroupRows(baseParams({ comps, selected: new Set(["COMP4"]) })) as React.ReactNode,
    );
    expect(screen.getByText("SFG")).toBeInTheDocument();
  });

  it("shows the contribution percentage badge when contributionPct is set", () => {
    const comps = [
      makeComponent({ componentCode: "COMP3", contributionPct: 42 }),
    ];
    renderRows(
      componentGroupRows(baseParams({ comps, selected: new Set(["COMP3"]) })) as React.ReactNode,
    );
    expect(screen.getByText("42%")).toBeInTheDocument();
  });

  it("calls onToggleAll with the current all-selected state when the group checkbox is toggled", () => {
    const onToggleAll = jest.fn();
    const comps = [
      makeComponent({ componentCode: "COMP1" }),
      makeComponent({ componentCode: "COMP2" }),
    ];
    const { container } = renderRows(
      componentGroupRows(
        baseParams({ comps, selected: new Set(["COMP1", "COMP2"]), onToggleAll }),
      ) as React.ReactNode,
    );
    const groupCheckbox = container.querySelector('input[type="checkbox"]') as HTMLInputElement;
    expect(groupCheckbox.checked).toBe(true);
    fireEvent.click(groupCheckbox);
    expect(onToggleAll).toHaveBeenCalledWith(1, comps, true, "unique");
  });

  it("marks the group checkbox indeterminate when some but not all components are selected", () => {
    const comps = [
      makeComponent({ componentCode: "COMP1" }),
      makeComponent({ componentCode: "COMP2" }),
    ];
    const { container } = renderRows(
      componentGroupRows(
        baseParams({ comps, selected: new Set(["COMP1"]) }),
      ) as React.ReactNode,
    );
    const groupCheckbox = container.querySelector('input[type="checkbox"]') as HTMLInputElement;
    expect(groupCheckbox.indeterminate).toBe(true);
    expect(groupCheckbox.checked).toBe(false);
  });
});
