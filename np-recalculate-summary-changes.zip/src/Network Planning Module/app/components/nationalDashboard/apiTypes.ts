// ─────────────────────────────────────────────────────────────────────────────
// Confirmed wire contract for the National Dashboard (CBU Listing page) and
// its popups. Field names mirror the backend contract 1:1 — this file has no
// relationship to the internal UI types in ./types.ts. The mapper functions
// in api/cbuApi.ts translate these into CBURow / DcStockRow / etc. so the
// rest of the app never sees these shapes directly.
// ─────────────────────────────────────────────────────────────────────────────

// ─── GET /api/v1/cbus — query params ──────────────────────────────────────
export interface CbuListQueryParams {
  page?: number; // default 1
  pageSize?: number; // default 20
  search?: string;
  material?: string | string[];
  cbu?: string | string[];
  basePack?: string | string[];
  smallC?: string | string[];
  bg?: string | string[];
  format?: string | string[];
  brand?: string | string[];
  materialType?: string;
  uom?: "EA" | "TON"; // default "EA" — NOT "MT"; convert via toApiUom() first
  highContributing?: boolean; // default false
  sortBy?: string; // default "cbuCode"
  sortOrder?: "asc" | "desc"; // default "asc"
}

// ─── GET /api/v1/cbus/export — query params ────────────────────────────────
// Same filter/search/sort params as the list endpoint, but not paginated —
// exports the entire matching result set as an .xlsx file, so page/pageSize
// don't apply.
export type CbuExportQueryParams = Omit<CbuListQueryParams, "page" | "pageSize">;

// Row shape from the finalized sample response — now includes smallC/bg/
// format/brand/basepack/basepackDescription attributes at the row level (no
// per-component breakdown), and RMPM/totalFG/cover come as separate Min/Max
// pairs rather than one totals block. Numeric leaves come back null (not 0)
// when there's no data for that CBU/location — mapCbuListRowToCBURow's
// defaultFgStock/defaultRmpmStock default every one of them, since CBURow's
// equivalents are non-nullable.
export interface CbuListRowFgStock {
  uom: string;
  dcStock: number | null;
  factoryStock: number | null;
  inTransitStock: number | null;
  totalStock: number | null;
  // Not part of the confirmed contract yet — the API doesn't send this for
  // FG stock (unlike RMPM's blockedStock) — optional so defaultFgStock can
  // default it to null (rendered as "—") until the backend adds it.
  blockedStock?: number | null;
  // DC/factory split behind blockedStock, shown in the fg_blocked column's
  // tooltip.
  dcBlockedStock?: number | null;
  factoryBlockedStock?: number | null;
}

export interface CbuListRowRmpmStock {
  uom: string;
  physicalStock: number | null;
  qualityStock: number | null;
  openPOStock: number | null;
  blockedStock: number | null;
  supplierInventory: number | null;
  inTransitStock: number | null;
  totalStock: number | null;
  stvStock: number | null;
}

export interface CbuListRowDemand {
  sumNext3TDP: number | null;
  next6Months: number | null;
  next12Months: number | null;
}

export interface CbuListRowTotalFg {
  totalFG: number | null;
  totalFGDays: number | null;
}

export interface CbuListRowCover {
  fgCoverDate: string | null;
  totalCoverDate: string | null;
  coverExcludingOpenPO: string | null;
}

export interface CbuListRow {
  slNo: number;
  cbuCode: string;
  cbuDescription: string;
  weightKg: number | null;
  basepack: string | null;
  basepackDescription: string | null;
  smallC: string | null;
  bg: string | null;
  format: string | null;
  brand: string | null;
  fg: CbuListRowFgStock;
  rmpmMin: CbuListRowRmpmStock;
  rmpmMax: CbuListRowRmpmStock;
  demand: CbuListRowDemand;
  totalFGMin: CbuListRowTotalFg;
  totalFGMax: CbuListRowTotalFg;
  coverMin: CbuListRowCover;
  coverMax: CbuListRowCover;
}

// Top-level envelope — no totalPages field on the wire; derive it as
// Math.ceil(count / pageSize).
export interface CBUListResponse {
  count: number;
  page: number;
  pageSize: number;
  data: CbuListRow[];
}

// ─── Validation error (HTTP 422) ──────────────────────────────────────────
// Standard FastAPI request-validation error body, returned when query params
// (page/pageSize/uom/sortBy/... ) fail schema validation.
export interface CbuValidationErrorItem {
  loc: Array<string | number>;
  msg: string;
  type: string;
  input?: unknown;
  ctx?: Record<string, unknown>;
}

export interface CbuValidationErrorResponse {
  detail: CbuValidationErrorItem[];
}

// ─── GET /api/v1/cbus/filters ──────────────────────────────────────────────
// Conditional (sibling-aware faceted search) filter-dropdown option lists for
// the National Dashboard toolbar. Each group's `options` are computed from
// every *other* filter's current selection — the request must therefore
// resend the full current multi-select state on every call (see
// CbuFiltersQueryParams / fetchCbuFilters). Each option carries a `count`
// (matching rows) and `disabled` (no matches given current siblings); each
// group carries a `totalCount`/`allSelected` and is expected to include a
// synthetic "All" option — the UI defensively re-derives its own canonical
// "All" row regardless (see getFilterOptionViews in NationalDashboard.tsx),
// the same defensiveness the old withAllOption()/isAllSentinel() had.
// Each group is independently paginated (`page`/`pageSize`/`hasMore`) — the
// endpoint takes one request-wide `page`/`pageSize`, so scrolling a single
// dropdown to load its next 100 options means resending the full current
// multi-select state plus the next `page`, and merging just that group's
// returned `options` onto what's already loaded for it (see FilterDropdown's
// onLoadMore and NationalDashboard's loadMoreFilterOptions).
export interface CbuFilterOption {
  value: string;
  label: string;
  count: number;
  disabled: boolean;
  code: string;
  description: string;
}

export interface CbuFilterGroup {
  name: string;
  totalCount: number;
  allSelected: boolean;
  page: number;
  pageSize: number;
  hasMore: boolean;
  options: CbuFilterOption[];
}

// `material`/`cbu` each now carry both code and description on every option
// (`code`/`description` fields) instead of the old split materialCode/
// materialDescription and cbuCode/cbuDescription group pairs. basePack stays
// split from basePackDescription — the Base Pack toolbar dropdown still
// sources display options from basePackDescription (see
// SOURCE_GROUP_FOR_FILTER in NationalDashboard.tsx).
export type CbuFilterGroupKey =
  | "bg"
  | "smallC"
  | "format"
  | "brand"
  | "material"
  | "cbu"
  | "basePack"
  | "basePackDescription";

export type CbuFiltersResponse = Record<CbuFilterGroupKey, CbuFilterGroup>;

// The 7 checkbox multi-select dropdown ids — i.e. every CbuFiltersResponse
// group actually surfaced as a toolbar filter (excludes basePackDescription,
// and excludes materialType/uom, which are single-select toggles not present
// in this API at all). These are the toolbar-facing ids used throughout
// NationalDashboard.tsx/Redux — fetchCbuFilters maps materialCode/cbuCode to
// the wire's `material`/`cbu` query param names.
export type MultiFilterId =
  | "bg"
  | "smallC"
  | "format"
  | "brand"
  | "materialCode"
  | "cbuCode"
  | "basePack";

// Query params for GET /api/v1/cbus/filters — the full current multi-select
// state, one repeated param per selected value (?bg=BG1&bg=BG2), omitted
// entirely for a dimension left at "All". `page`/`pageSize` are request-wide
// (default to the endpoint's own page 1 / 100 when omitted) — used to fetch
// the next page of whichever single dropdown's group the caller cares about.
export type CbuFiltersQueryParams = Partial<Record<MultiFilterId, string[]>> & {
  page?: number;
  pageSize?: number;
};

// ─── POST /api/v1/cbus/filters/search ──────────────────────────────────────
// Server-side text search within a single filter dropdown's full option set
// — used once the user types into that dropdown's search box, in place of
// GET /cbus/filters (which only ever returns the unfiltered/paginated list).
// Still sibling-aware like GET /cbus/filters: `selections` carries every
// filter group's *current* selection (all 8 CbuFilterGroupKeys, each an
// empty array when that dimension is at "All"), and the result is itself
// paginated (page/pageSize in, total_count/has_more out) the same way a
// single GET /cbus/filters group is. `filter_name` is the one group being
// searched — a CbuFilterGroupKey, not a toolbar MultiFilterId (see
// SOURCE_GROUP_FOR_FILTER in NationalDashboard.tsx for the id -> group
// mapping, e.g. materialCode -> "material").
export interface CbuFiltersSearchRequest {
  filter_name: CbuFilterGroupKey;
  search: string;
  selections: Record<CbuFilterGroupKey, string[]>;
  page: number;
  pageSize: number;
}

// Response uses the same per-option shape as GET /cbus/filters
// (CbuFilterOption) but is flat (one group's results, not all 8) and
// snake_cased for the pagination fields.
export interface CbuFiltersSearchResponse {
  filter_name: string;
  search: string;
  total_count: number;
  page: number;
  page_size: number;
  has_more: boolean;
  options: CbuFilterOption[];
}

// ─── GET /api/v1/cbus/{cbu_code}/stock-breakdown ──────────────────────────
// (operationId get_stock_breakdown_api_v1_cbus__cbu_code__stock_breakdown_get)
// Backs the "FG Stock Across All Locations" popup (DC / Factory / In-Transit).
// One endpoint, discriminated by stock_type — the row shape (and which
// columns are meaningful) differs between IN_TRANSIT and the other two.
// Numeric fields come back as decimal-formatted strings (e.g. "477540.0000"),
// not JSON numbers — callers must parse them.
export type StockBreakdownType = "DC_STOCK" | "FACTORY_STOCK" | "IN_TRANSIT";
export type StockBreakdownUom = "EA" | "TON";

export interface StockBreakdownQueryParams {
  stock_type: StockBreakdownType;
  uom: StockBreakdownUom;
}

export interface DcStockBreakdownRow {
  stock_type: "DC_STOCK";
  dc_code: string;
  uom: string;
  unrestricted: string;
  quality: string;
  blocked: string;
  total_excl_in_transit: string;
}

// No FACTORY_STOCK sample was provided — inferred to mirror DC_STOCK's shape
// (same field names, including "dc_code") since the popup shows identical
// columns (Unrestricted/Quality/Blocked/Total Excl. In-Transit) for both.
// Verify against the backend before relying on this.
export interface FactoryStockBreakdownRow {
  stock_type: "FACTORY_STOCK";
  plant_code: string;
  uom: string;
  unrestricted: string;
  quality: string;
  blocked: string;
  total_excl_in_transit: string;
}

export interface InTransitBreakdownRow {
  stock_type: "IN_TRANSIT";
  route: string;
  source: string;
  destination: string;
  uom: string;
  total_in_transit: string;
}

export interface StockBreakdownSummary {
  total_stock: string;
  active_locations_count: number;
}

export interface StockBreakdownResponse<TRow> {
  cbu_code: string;
  stock_type: StockBreakdownType;
  uom: string;
  summary: StockBreakdownSummary;
  count: number;
  data: TRow[];
}

export type DcStockBreakdownResponse = StockBreakdownResponse<DcStockBreakdownRow>;
export type FactoryStockBreakdownResponse =
  StockBreakdownResponse<FactoryStockBreakdownRow>;
export type InTransitBreakdownResponse =
  StockBreakdownResponse<InTransitBreakdownRow>;

// ─── GET /api/v1/cbus/{cbu_code}/forecast-demand-breakdown ────────────────
// Backs the Demand modal (Next 3 TDP / Next 6 Months / Next 12 Months), one
// endpoint for all three windows, discriminated by demand_type. view_type
// (BOOK_MONTH vs MOC) only applies when demand_type is NEXT_6_MONTH or
// NEXT_12_MONTH — the toggle isn't shown in the UI for NEXT_3_TDP.
export type ForecastDemandType = "NEXT_3_TDP" | "NEXT_6_MONTH" | "NEXT_12_MONTH";
export type ForecastDemandUom = "EA" | "TON";
export type ForecastDemandViewType = "BOOK_MONTH" | "MOC";

export interface ForecastDemandQueryParams {
  demand_type: ForecastDemandType;
  uom: ForecastDemandUom;
  view_type: ForecastDemandViewType;
}

export interface ForecastDemandPeriod {
  period: string;
  demand: number;
}

export interface ForecastDemandBreakdownResponse {
  cbu_code: string;
  demand_type: ForecastDemandType;
  uom: ForecastDemandUom;
  total_demand: number;
  avg_demand: number;
  // Sample response types this as a number (unlike data[].period, which is a
  // string) — unconfirmed whether it's an index into data[] or a label typed
  // as int on the backend. Callers should prefer deriving the peak entry
  // from data[] (matching peak_demand) rather than relying on this field
  // for a display label.
  peak_demand_period: number | string;
  peak_demand: number;
  active_count: number;
  data: ForecastDemandPeriod[];
}

// ─── GET /api/v1/cbus/production-plan?cbuCode=...&plantCode=... ───────────
// Backs the CBU Detail page's Production Plan breakdown popup (StockTable's
// "Production plan" cell, per plant). Unlike the other per-CBU endpoints,
// this one takes cbuCode/plantCode as query params rather than a path segment.
export interface ProductionPlanWeekWire {
  week: number;
  label: string;
  production: number;
  isPeakWeek: boolean;
}

export interface ProductionPlanResponse {
  cbuCode: string;
  plantCode: string;
  totalProduction: number;
  // Prefer deriving the peak entry from weeklyProduction[].isPeakWeek (matching
  // peakWeekProductionValue) rather than this field for a display label —
  // same caution as ForecastDemandBreakdownResponse.peak_demand_period, whose
  // week-number-vs-index semantics were never confirmed against the backend.
  peakWeek: number;
  peakWeekProductionValue: number;
  avgWeek: number;
  activeWeeks: number;
  weeklyProduction: ProductionPlanWeekWire[];
}

// ─── GET /api/v1/plants ────────────────────────────────────────────────────
// Plant master list (code/name/cluster). Flat array on the wire, no
// pagination envelope. Not consumed anywhere yet — the app currently derives
// plant→cluster via the hardcoded PLANT_CLUSTER_MAP in components/data.ts;
// this is the real source that mock is standing in for.
export interface PlantWire {
  code: string;
  name: string;
  cluster: string;
}

export type PlantsResponse = PlantWire[];

// ─── GET /api/v1/cbus/{cbu_code}/components ────────────────────────────────
// Per-component (RM/PM) stock breakdown for a single CBU, fetched on demand
// when a National Dashboard row is expanded. Flat array on the wire, no
// pagination envelope — mirrors AggregatedComponent (components/data.ts)
// almost 1:1, plus a componentDescription the mock data derived client-side.
export interface CbuComponentWire {
  componentCode: string;
  componentMaterialType: string;
  componentDescription: string;
  unrestrictedStock: number;
  qualityStock: number;
  blockedStock: number;
  totalStock: number;
  openPOStock: number;
  totalFGCover: any;
  excludeOpenPO: any;
  // Tags whether this component belongs to the "High Contributing" set.
  // Present as "unique" (not "high-contributer"/"high-contributing") on
  // plenty of entries from *both* endpoints — including the
  // contributionType=high-contributer call, which doesn't exclusively
  // return high-contributing rows despite the param name — so only
  // "high-contributer"/"high-contributing" should ever be treated as such
  // (see isHighContributingType in components/data.ts); every other value
  // (including "unique") is a standard breakdown entry.
  contribution_type?: "high-contributer" | "high-contributing" | "unique" | null;
}

export type CbuComponentsResponse = CbuComponentWire[];

// ─── GET /api/v1/cbus/{cbu_code}/components-by-plant ───────────────────────
// Per-plant, per-component (RM/PM) stock breakdown for a single CBU, backing
// the CBU Detail page's Plant view (replaces the mock getComponentsByPlant
// generator in components/data.ts). demand12M is always sent as 0 — the
// backend pre-computes required/isSurplus itself, unlike the mock generator
// this replaces, which derived required from a demand12M passed in.
export interface ComponentsByPlantQueryParams {
  demand12M: 0;
}

export interface ComponentsByPlantRowWire {
  plantco: string;
  componentCode: string;
  // Sent as the display type directly ("RM"/"PM"/"SFG"), not the old
  // numeric codes — see getComponentTypeCode (components/data.ts).
  componentMaterialType: string;
  materialDescription?: string | null;
  conversionFactor: number | null;
  onHandStock: number | null;
  unrestrictedStock: number | null;
  qualityStock: number | null;
  stvStock: number | null;
  blockedStock: number | null;
  openPOStock: number | null;
  inTransitStock: number | null;
  supplierInventory: number | null;
  fgPhysicalStock: number | null;
  fgOpenPOStock: number | null;
  fgUnrestrictedStock: number | null;
  fgQualityStock: number | null;
  fgStvStock: number | null;
  fgBlockedStock: number | null;
  required: number | null;
  isSurplus: boolean;
  // This component's own FG cover date at this plant — distinct from the
  // fgCoverDateOnHandOnlyMin/Max and fgCoverDateOnHandPlusOpenPOMin/Max
  // fields below, which are plant-level (denormalized onto every row for
  // that plant) rather than per-component.
  fgCoverDate?: string | null;
  // True when this component is already counted among the CBU's
  // high-contributing components (see ComponentsByPlantResponse's
  // highContributingComponents) — used to exclude it from the unique RM/PM
  // component count/list so it isn't double-counted.
  isHighContributor?: boolean;
  // Share of this CBU's demand this component accounts for — only ever set
  // for high-contributing rows, and not always present even then (the
  // backend's criticality analysis doesn't uniformly return it). When
  // absent, the UI falls back to a plain "High Contributor" tag instead of
  // a percentage badge.
  contributionPct?: number | null;
  // Plant-level figures, denormalized onto every component row for that
  // plant (every row sharing a plantco carries the same values here).
  totalFGAtPlant: number | null;
  productionPlan: number | null;
  fgCoverDateOnHandOnlyMin: string | null;
  fgCoverDateOnHandOnlyMax: string | null;
  fgCoverDateOnHandPlusOpenPOMin: string | null;
  fgCoverDateOnHandPlusOpenPOMax: string | null;
  // The backend's own FG-equivalent on-hand+openPO+inTransit+supplier total
  // for this component/plant — preferred over re-deriving it client-side
  // (see plantFgMetrics in cbuDetails/utils.ts) so the two can't drift.
  totalFGEquivalentRMPMStock?: number | null;
}

export interface ComponentsByPlantResponse {
  plants: string[];
  rows: ComponentsByPlantRowWire[];
  // CBU-level KPI counts — not derivable from `rows` alone (e.g.
  // highContributingComponents comes from a separate criticality analysis).
  uniqueRMComponents: number;
  uniquePMComponents: number;
  highContributingComponents: number;
}

// ─── POST /api/v1/cbus/recalculate/summary ─────────────────────────────────
// Recalculates a single CBU dashboard row's RMPM FG-equivalent stock, FG
// summary, and cover dates after the user selects/deselects specific RMPM
// codes in the National Dashboard's expanded-row component checkboxes (see
// selectedComponents/toggleComp in pages/NationalDashboard.tsx) — a
// server-side counterpart to the client-side computeEffRmpm
// (nationalDashboard/utils.ts). Per the endpoint's own description, it
// recalculates:
//  - RMPM FG-Equivalent Stock (Min/Max) per stock type
//  - FG Summary Min/Max (FG Total + RMPM Total)
//  - Cover Days/Dates via TDP-walk for Total FG Cover and Excl. Open PO
// Cover-day algorithm: walk TDP periods starting from the current period,
// consuming FG inventory against per_day_forecast * remaining_days per
// period; returns the total days once inventory is exhausted, or caps at the
// entire TDP planning horizon if it never is.
export type CbuRecalculateContributionType = "high-contributing" | "unique";

export interface CbuRecalculateSummaryRequest {
  cbuCode: string;
  selectedRmpmCodes: string[];
  deselectedRmpmCodes: string[];
  uom: "EA" | "TON";
  contributionType: CbuRecalculateContributionType;
}

// Confirmed against a live response: identical to CbuListRow, the same row
// shape GET /api/v1/cbus returns per CBU — this endpoint really does hand
// back the complete recalculated dashboard row (fg/rmpmMin/rmpmMax/demand/
// totalFGMin/totalFGMax/coverMin/coverMax, plus the row's own identity/attribute
// fields), not just the narrower RMPM/FG-summary/cover slice its description
// focuses on. mapCbuListRowToCBURow (api/cbuApi.ts) maps it into a CBURow the
// same way it already does for the list endpoint.
export type CbuRecalculateSummaryResponse = CbuListRow;
